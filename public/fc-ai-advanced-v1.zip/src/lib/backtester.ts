/**
 * FC AI ADVANCED - QUANTITATIVE STRATEGY BACKTESTER (MODULE 04)
 * Strict closed-candle execution without look-ahead bias.
 * Complete parameter customization, in-sample/out-of-sample split, and trade-by-trade audit.
 */

import {
  OHLCVCandle,
  BacktestParameters,
  BacktestResult,
  BacktestTrade,
  OrderSide,
} from '../types/market';
import {
  calculateSMA,
  calculateEMA,
  calculateRSI,
  calculateMACD,
  calculateBollingerBands,
  calculateATR,
} from './indicators';

export function runBacktest(
  candles: OHLCVCandle[],
  params: BacktestParameters
): BacktestResult {
  const {
    strategyName,
    symbol,
    timeframe,
    initialCapital,
    fastPeriod,
    slowPeriod,
    signalPeriod = 9,
    rsiPeriod = 14,
    rsiOversold = 30,
    rsiOverbought = 70,
    stopLossPercent,
    takeProfitPercent,
    slippageBps,
    feeBps,
    inSampleRatio = 0.7,
  } = params;

  if (candles.length < Math.max(slowPeriod, 30)) {
    throw new Error(`Insufficient historical candles (${candles.length}) for backtesting strategy ${strategyName}`);
  }

  const closes = candles.map(c => c.close);
  const opens = candles.map(c => c.open);
  const highs = candles.map(c => c.high);
  const lows = candles.map(c => c.low);
  const timestamps = candles.map(c => c.timestamp);

  // Pre-calculate canonical indicators
  const smaFast = calculateSMA(closes, fastPeriod);
  const smaSlow = calculateSMA(closes, slowPeriod);
  const emaFast = calculateEMA(closes, fastPeriod);
  const emaSlow = calculateEMA(closes, slowPeriod);
  const rsi = calculateRSI(closes, rsiPeriod);
  const macdData = calculateMACD(closes, fastPeriod, slowPeriod, signalPeriod);
  const bbData = calculateBollingerBands(closes, fastPeriod, 2.0);
  const atrData = calculateATR(candles, 14);

  // In-sample boundary
  const splitIndex = Math.floor(candles.length * inSampleRatio);

  let currentCapital = initialCapital;
  let peakCapital = initialCapital;
  let maxDrawdownAmt = 0;
  let maxDrawdownPct = 0;

  const trades: BacktestTrade[] = [];
  const equityCurve: { timestamp: number; equity: number; drawdownPercent: number }[] = [
    { timestamp: timestamps[0], equity: initialCapital, drawdownPercent: 0 }
  ];

  let inTrade = false;
  let tradeSide: OrderSide = 'BUY';
  let entryPrice = 0;
  let entryIndex = 0;
  let quantity = 0;
  let tradeMaxPrice = 0;
  let tradeMinPrice = 0;

  // We start after the longest indicator warm-up period
  const startIndex = Math.max(slowPeriod + 2, 28);

  for (let i = startIndex; i < candles.length; i++) {
    const currentClose = closes[i];
    const prevClose = closes[i - 1];
    const currentHigh = highs[i];
    const currentLow = lows[i];

    // Check stop-loss / take-profit for active position
    if (inTrade) {
      let exitReason: 'STOP_LOSS' | 'TAKE_PROFIT' | 'SIGNAL_REVERSAL' | null = null;
      let rawExitPrice = currentClose;

      if (tradeSide === 'BUY') {
        const slPrice = entryPrice * (1 - stopLossPercent / 100);
        const tpPrice = entryPrice * (1 + takeProfitPercent / 100);

        if (currentLow <= slPrice) {
          exitReason = 'STOP_LOSS';
          rawExitPrice = slPrice;
        } else if (currentHigh >= tpPrice) {
          exitReason = 'TAKE_PROFIT';
          rawExitPrice = tpPrice;
        }
      } else {
        const slPrice = entryPrice * (1 + stopLossPercent / 100);
        const tpPrice = entryPrice * (1 - takeProfitPercent / 100);

        if (currentHigh >= slPrice) {
          exitReason = 'STOP_LOSS';
          rawExitPrice = slPrice;
        } else if (currentLow <= tpPrice) {
          exitReason = 'TAKE_PROFIT';
          rawExitPrice = tpPrice;
        }
      }

      // Check signal reversal if no SL/TP triggered
      if (!exitReason) {
        const reversal = checkExitSignal(i - 1, tradeSide);
        if (reversal) {
          exitReason = 'SIGNAL_REVERSAL';
          rawExitPrice = opens[i]; // executed at open of bar i based on signal at i-1
        }
      }

      // Execute exit
      if (exitReason) {
        const slipMult = tradeSide === 'BUY' ? (1 - slippageBps / 10000) : (1 + slippageBps / 10000);
        const finalExitPrice = rawExitPrice * slipMult;

        const feeRate = (feeBps / 10000) * 2; // entry + exit
        const tradeValue = quantity * entryPrice;
        const totalFees = tradeValue * feeRate;
        const slippageCost = Math.abs(finalExitPrice - rawExitPrice) * quantity;

        const grossPnL = tradeSide === 'BUY'
          ? (finalExitPrice - entryPrice) * quantity
          : (entryPrice - finalExitPrice) * quantity;

        const netPnL = grossPnL - totalFees;
        currentCapital += netPnL;

        if (currentCapital > peakCapital) {
          peakCapital = currentCapital;
        }
        const currentDDAmount = peakCapital - currentCapital;
        const currentDDPct = (currentDDAmount / peakCapital) * 100;
        if (currentDDAmount > maxDrawdownAmt) maxDrawdownAmt = currentDDAmount;
        if (currentDDPct > maxDrawdownPct) maxDrawdownPct = currentDDPct;

        // Trade drawdown during holding
        const maxAdverse = tradeSide === 'BUY'
          ? ((entryPrice - tradeMinPrice) / entryPrice) * 100
          : ((tradeMaxPrice - entryPrice) / entryPrice) * 100;

        trades.push({
          tradeNumber: trades.length + 1,
          entryTimestamp: timestamps[entryIndex],
          exitTimestamp: timestamps[i],
          side: tradeSide,
          entryPrice: Number(entryPrice.toFixed(4)),
          exitPrice: Number(finalExitPrice.toFixed(4)),
          quantity: Number(quantity.toFixed(4)),
          grossPnL: Number(grossPnL.toFixed(2)),
          fees: Number(totalFees.toFixed(2)),
          slippage: Number(slippageCost.toFixed(2)),
          netPnL: Number(netPnL.toFixed(2)),
          returnPercent: Number(((netPnL / tradeValue) * 100).toFixed(2)),
          holdingCandles: i - entryIndex,
          exitReason,
          drawdownDuringTradePercent: Number(Math.max(0, maxAdverse).toFixed(2)),
          isOutOfSample: entryIndex >= splitIndex,
        });

        inTrade = false;
        equityCurve.push({
          timestamp: timestamps[i],
          equity: Number(currentCapital.toFixed(2)),
          drawdownPercent: Number(currentDDPct.toFixed(2)),
        });
      } else {
        // Position still open - update excursion
        if (currentHigh > tradeMaxPrice) tradeMaxPrice = currentHigh;
        if (currentLow < tradeMinPrice) tradeMinPrice = currentLow;
      }
    }

    // Check Entry Signal on closed bar (i - 1)
    if (!inTrade && i < candles.length - 1) {
      const entrySignal = checkEntrySignal(i - 1);
      if (entrySignal) {
        // Execute entry at open of bar i
        tradeSide = entrySignal;
        const slipMult = tradeSide === 'BUY' ? (1 + slippageBps / 10000) : (1 - slippageBps / 10000);
        entryPrice = opens[i] * slipMult;
        entryIndex = i;

        // Position sizing: allocate 95% of available capital
        const allocatedCapital = currentCapital * 0.95;
        quantity = allocatedCapital / entryPrice;

        tradeMaxPrice = entryPrice;
        tradeMinPrice = entryPrice;
        inTrade = true;
      }
    }
  }

  // Close any lingering open trade at final candle
  if (inTrade) {
    const finalCandleIdx = candles.length - 1;
    const finalPrice = closes[finalCandleIdx];
    const tradeValue = quantity * entryPrice;
    const feeRate = (feeBps / 10000) * 2;
    const totalFees = tradeValue * feeRate;
    const grossPnL = tradeSide === 'BUY'
      ? (finalPrice - entryPrice) * quantity
      : (entryPrice - finalPrice) * quantity;
    const netPnL = grossPnL - totalFees;
    currentCapital += netPnL;

    trades.push({
      tradeNumber: trades.length + 1,
      entryTimestamp: timestamps[entryIndex],
      exitTimestamp: timestamps[finalCandleIdx],
      side: tradeSide,
      entryPrice: Number(entryPrice.toFixed(4)),
      exitPrice: Number(finalPrice.toFixed(4)),
      quantity: Number(quantity.toFixed(4)),
      grossPnL: Number(grossPnL.toFixed(2)),
      fees: Number(totalFees.toFixed(2)),
      slippage: 0,
      netPnL: Number(netPnL.toFixed(2)),
      returnPercent: Number(((netPnL / tradeValue) * 100).toFixed(2)),
      holdingCandles: finalCandleIdx - entryIndex,
      exitReason: 'END_OF_DATA',
      drawdownDuringTradePercent: 0,
      isOutOfSample: entryIndex >= splitIndex,
    });
  }

  // Helper signal functions
  function checkEntrySignal(idx: number): OrderSide | null {
    if (idx <= 1) return null;

    switch (strategyName) {
      case 'SMA_CROSSOVER': {
        const fastCurr = smaFast[idx];
        const fastPrev = smaFast[idx - 1];
        const slowCurr = smaSlow[idx];
        const slowPrev = smaSlow[idx - 1];
        if (fastCurr === null || fastPrev === null || slowCurr === null || slowPrev === null) return null;
        if (fastPrev <= slowPrev && fastCurr > slowCurr) return 'BUY';
        if (fastPrev >= slowPrev && fastCurr < slowCurr) return 'SELL';
        return null;
      }

      case 'EMA_CROSSOVER': {
        const fastCurr = emaFast[idx];
        const fastPrev = emaFast[idx - 1];
        const slowCurr = emaSlow[idx];
        const slowPrev = emaSlow[idx - 1];
        if (fastCurr === null || fastPrev === null || slowCurr === null || slowPrev === null) return null;
        if (fastPrev <= slowPrev && fastCurr > slowCurr) return 'BUY';
        if (fastPrev >= slowPrev && fastCurr < slowCurr) return 'SELL';
        return null;
      }

      case 'RSI_MEAN_REVERSION': {
        const rsiCurr = rsi[idx];
        const rsiPrev = rsi[idx - 1];
        if (rsiCurr === null || rsiPrev === null) return null;
        if (rsiPrev <= rsiOversold && rsiCurr > rsiOversold) return 'BUY';
        if (rsiPrev >= rsiOverbought && rsiCurr < rsiOverbought) return 'SELL';
        return null;
      }

      case 'MACD_CROSSOVER': {
        const curr = macdData[idx];
        const prev = macdData[idx - 1];
        if (curr.macd === null || curr.signal === null || prev.macd === null || prev.signal === null) return null;
        if (prev.macd <= prev.signal && curr.macd > curr.signal) return 'BUY';
        if (prev.macd >= prev.signal && curr.macd < curr.signal) return 'SELL';
        return null;
      }

      case 'BOLLINGER_REVERSION': {
        const bb = bbData[idx];
        const prevBB = bbData[idx - 1];
        const c = closes[idx];
        const pc = closes[idx - 1];
        if (!bb.lower || !bb.upper || !prevBB.lower || !prevBB.upper) return null;
        if (pc < prevBB.lower && c > bb.lower) return 'BUY';
        if (pc > prevBB.upper && c < bb.upper) return 'SELL';
        return null;
      }

      case 'DONCHIAN_BREAKOUT': {
        const lookback = fastPeriod;
        if (idx < lookback) return null;
        let highChannel = -Infinity;
        let lowChannel = Infinity;
        for (let j = idx - lookback; j < idx; j++) {
          if (highs[j] > highChannel) highChannel = highs[j];
          if (lows[j] < lowChannel) lowChannel = lows[j];
        }
        if (closes[idx] > highChannel) return 'BUY';
        if (closes[idx] < lowChannel) return 'SELL';
        return null;
      }

      case 'TREND_FOLLOWING': {
        const e9 = emaFast[idx];
        const e21 = emaSlow[idx];
        const atr = atrData[idx];
        const rsiVal = rsi[idx];
        if (e9 === null || e21 === null || atr === null || rsiVal === null) return null;
        if (e9 > e21 && closes[idx] > e9 && rsiVal > 52 && rsiVal < 68) return 'BUY';
        if (e9 < e21 && closes[idx] < e9 && rsiVal < 48 && rsiVal > 32) return 'SELL';
        return null;
      }

      default:
        return null;
    }
  }

  function checkExitSignal(idx: number, side: OrderSide): boolean {
    if (idx <= 1) return false;
    if (strategyName === 'SMA_CROSSOVER') {
      const f = smaFast[idx];
      const s = smaSlow[idx];
      if (f === null || s === null) return false;
      return side === 'BUY' ? f < s : f > s;
    }
    if (strategyName === 'EMA_CROSSOVER') {
      const f = emaFast[idx];
      const s = emaSlow[idx];
      if (f === null || s === null) return false;
      return side === 'BUY' ? f < s : f > s;
    }
    if (strategyName === 'RSI_MEAN_REVERSION') {
      const r = rsi[idx];
      if (r === null) return false;
      return side === 'BUY' ? r >= 55 : r <= 45;
    }
    return false;
  }

  // Calculate aggregate metrics
  const totalTrades = trades.length;
  const winningTrades = trades.filter(t => t.netPnL > 0);
  const losingTrades = trades.filter(t => t.netPnL < 0);
  const winRate = totalTrades > 0 ? (winningTrades.length / totalTrades) * 100 : 0;

  const totalWinAmount = winningTrades.reduce((sum, t) => sum + t.netPnL, 0);
  const totalLossAmount = Math.abs(losingTrades.reduce((sum, t) => sum + t.netPnL, 0));
  const profitFactor = totalLossAmount > 0 ? totalWinAmount / totalLossAmount : totalWinAmount > 0 ? 99.9 : 0;

  const averageWin = winningTrades.length > 0 ? totalWinAmount / winningTrades.length : 0;
  const averageLoss = losingTrades.length > 0 ? totalLossAmount / losingTrades.length : 0;

  const totalNetPnL = currentCapital - initialCapital;
  const totalReturnPercent = (totalNetPnL / initialCapital) * 100;

  // Annualized return
  const totalMs = timestamps[timestamps.length - 1] - timestamps[0];
  const totalYears = Math.max(0.01, totalMs / (1000 * 60 * 60 * 24 * 365));
  const annualizedReturn = ((Math.pow(Math.max(0.01, currentCapital / initialCapital), 1 / totalYears) - 1) * 100);

  // Expectancy = (Win% * AvgWin) - (Loss% * AvgLoss)
  const winPct = winRate / 100;
  const lossPct = (100 - winRate) / 100;
  const expectancy = winPct * averageWin - lossPct * averageLoss;

  // Sharpe ratio (daily returns approx)
  const tradeReturns = trades.map(t => t.returnPercent / 100);
  const meanTradeReturn = tradeReturns.length > 0 ? tradeReturns.reduce((a, b) => a + b, 0) / tradeReturns.length : 0;
  const varianceReturns = tradeReturns.length > 1
    ? tradeReturns.reduce((sum, r) => sum + Math.pow(r - meanTradeReturn, 2), 0) / (tradeReturns.length - 1)
    : 0;
  const stdDevReturns = Math.sqrt(varianceReturns);
  const sharpeRatio = stdDevReturns > 0 ? (meanTradeReturn / stdDevReturns) * Math.sqrt(252) : 0;

  // Market Exposure %
  const totalHoldingCandles = trades.reduce((sum, t) => sum + t.holdingCandles, 0);
  const marketExposurePercent = Math.min(100, (totalHoldingCandles / candles.length) * 100);

  // Out of sample metrics
  const outOfSampleTrades = trades.filter(t => t.isOutOfSample);
  const inSampleTrades = trades.filter(t => !t.isOutOfSample);
  const oosWins = outOfSampleTrades.filter(t => t.netPnL > 0).length;
  const oosWinRate = outOfSampleTrades.length > 0 ? (oosWins / outOfSampleTrades.length) * 100 : 0;
  const oosNetPnL = outOfSampleTrades.reduce((sum, t) => sum + t.netPnL, 0);
  const oosReturnPct = (oosNetPnL / initialCapital) * 100;

  return {
    strategyName,
    symbol,
    timeframe,
    candleCount: candles.length,
    startDate: new Date(timestamps[0]).toISOString().split('T')[0],
    endDate: new Date(timestamps[timestamps.length - 1]).toISOString().split('T')[0],
    initialCapital,
    endingCapital: Number(currentCapital.toFixed(2)),
    totalNetPnL: Number(totalNetPnL.toFixed(2)),
    totalReturnPercent: Number(totalReturnPercent.toFixed(2)),
    annualizedReturnPercent: Number(annualizedReturn.toFixed(2)),
    totalTrades,
    winningTrades: winningTrades.length,
    losingTrades: losingTrades.length,
    winRate: Number(winRate.toFixed(2)),
    profitFactor: Number(profitFactor.toFixed(2)),
    averageWin: Number(averageWin.toFixed(2)),
    averageLoss: Number(averageLoss.toFixed(2)),
    maxDrawdownPercent: Number(maxDrawdownPct.toFixed(2)),
    maxDrawdownAmount: Number(maxDrawdownAmt.toFixed(2)),
    sharpeRatio: Number(sharpeRatio.toFixed(2)),
    expectancy: Number(expectancy.toFixed(2)),
    marketExposurePercent: Number(marketExposurePercent.toFixed(2)),
    inSampleTrades: inSampleTrades.length,
    outOfSampleTrades: outOfSampleTrades.length,
    outOfSampleWinRate: Number(oosWinRate.toFixed(2)),
    outOfSampleReturnPercent: Number(oosReturnPct.toFixed(2)),
    equityCurve,
    trades,
  };
}
