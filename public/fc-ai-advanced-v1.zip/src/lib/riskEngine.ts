/**
 * FC AI ADVANCED - PORTFOLIO RISK & SIZING ENGINE (MODULE 05)
 * Analyzes multi-asset exposure, asset allocation, correlation matrix,
 * 20% market shock stress testing, and quantitative position sizing.
 */

import {
  PaperPosition,
  PaperAccount,
  Instrument,
  PortfolioStressScenario,
} from '../types/market';

export interface AllocationSlice {
  label: string;
  value: number;
  percentage: number;
}

export interface PortfolioRiskReport {
  totalEquity: number;
  totalExposure: number;
  unrealizedPnL: number;
  portfolioLeverage: number;
  usedMargin: number;
  freeMargin: number;
  marginLevel: number;
  positionConcentration: AllocationSlice[];
  assetClassAllocation: AllocationSlice[];
  currencyConcentration: AllocationSlice[];
  correlationMatrix: {
    symbols: string[];
    matrix: number[][]; // correlation coefficients -1.0 to 1.0
  };
  stressScenarios: {
    scenarioName: string;
    description: string;
    simulatedPnLImpact: number;
    simulatedEquity: number;
    simulatedDrawdownPercent: number;
    marginCallRisk: boolean;
  }[];
  proposedRebalancing: {
    symbol: string;
    action: 'REDUCE' | 'MAINTAIN' | 'INCREASE' | 'HEDGE';
    reason: string;
    recommendedSizeChange: number;
    expectedCostOrFriction: string;
  }[];
  hedgingAlternatives: {
    hedgeStrategy: string;
    instrument: string;
    rationale: string;
    estimatedCost: string;
    limitations: string;
  }[];
}

export interface PositionSizeResult {
  recommendedQuantity: number;
  capitalAtRisk: number;
  riskPercentOfCapital: number;
  maxAllowableLoss: number;
  requiredMargin: number;
  effectiveLeverage: number;
  methodologyNotes: string;
}

/**
 * Calculate comprehensive Portfolio Risk Report
 */
export function calculatePortfolioRisk(
  positions: PaperPosition[],
  account: PaperAccount,
  instruments: Record<string, Instrument>
): PortfolioRiskReport {
  const equity = account.virtualEquity;
  const openPositions = positions.filter(p => p.status === 'OPEN');

  let totalExposure = 0;
  let totalUnrealized = 0;
  let totalUsedMargin = 0;

  const symbolExposureMap: Record<string, number> = {};
  const assetClassMap: Record<string, number> = {};
  const currencyMap: Record<string, number> = { [account.currency]: account.freeMargin };

  for (const pos of openPositions) {
    const inst = instruments[pos.symbol];
    const notional = pos.quantity * pos.currentPrice;
    totalExposure += notional;
    totalUnrealized += pos.unrealizedPnL;
    totalUsedMargin += pos.margin;

    // Symbol exposure
    symbolExposureMap[pos.symbol] = (symbolExposureMap[pos.symbol] || 0) + notional;

    // Asset Class
    const assetClass = inst?.assetClass || 'crypto';
    assetClassMap[assetClass] = (assetClassMap[assetClass] || 0) + notional;

    // Currency
    const quoteCur = inst?.quoteCurrency || 'USD';
    currencyMap[quoteCur] = (currencyMap[quoteCur] || 0) + notional;
  }

  const portfolioLeverage = equity > 0 ? totalExposure / equity : 0;
  const marginLevel = totalUsedMargin > 0 ? (equity / totalUsedMargin) * 100 : 999;

  // Build allocation slices
  const toSlices = (map: Record<string, number>, total: number): AllocationSlice[] => {
    return Object.entries(map).map(([label, value]) => ({
      label,
      value: Number(value.toFixed(2)),
      percentage: total > 0 ? Number(((value / total) * 100).toFixed(1)) : 0,
    })).sort((a, b) => b.value - a.value);
  };

  const positionConcentration = toSlices(symbolExposureMap, totalExposure || 1);
  const assetClassAllocation = toSlices(assetClassMap, totalExposure || 1);
  const currencyConcentration = toSlices(currencyMap, (totalExposure + account.freeMargin) || 1);

  // Correlation Matrix calculation across active open symbols
  const activeSymbols = Array.from(new Set(openPositions.map(p => p.symbol)));
  const matrix: number[][] = [];
  for (let i = 0; i < activeSymbols.length; i++) {
    const row: number[] = [];
    for (let j = 0; j < activeSymbols.length; j++) {
      if (i === j) {
        row.push(1.0);
      } else {
        const s1 = activeSymbols[i];
        const s2 = activeSymbols[j];
        const inst1 = instruments[s1];
        const inst2 = instruments[s2];
        // Calculate correlation based on asset class and quote
        if (inst1?.assetClass === inst2?.assetClass) {
          row.push(inst1?.assetClass === 'crypto' ? 0.78 : 0.65);
        } else if (
          (inst1?.assetClass === 'metals' && inst2?.assetClass === 'crypto') ||
          (inst1?.assetClass === 'crypto' && inst2?.assetClass === 'metals')
        ) {
          row.push(0.12); // low correlation between gold and crypto
        } else if (
          (inst1?.assetClass === 'metals' && inst2?.assetClass === 'indices') ||
          (inst1?.assetClass === 'indices' && inst2?.assetClass === 'metals')
        ) {
          row.push(-0.25); // negative hedge correlation
        } else {
          row.push(0.30);
        }
      }
    }
    matrix.push(row);
  }

  // Pre-defined stress scenarios with non-uniform asset class responses
  const scenarios: PortfolioStressScenario[] = [
    {
      name: 'Black Swan Market Shock (-20% Equity)',
      description: 'Global equity selloff with high crypto beta (-35%), Gold safe haven flight (+8%), and EUR/USD liquidity drop (-4%).',
      cryptoShock: -0.35,
      equitiesShock: -0.20,
      metalsShock: 0.08,
      forexShock: -0.04,
    },
    {
      name: 'Crypto Liquidity Crunch (-50%)',
      description: 'Severe deleveraging event in digital assets with minimal spillover into traditional macro assets.',
      cryptoShock: -0.50,
      equitiesShock: -0.05,
      metalsShock: 0.02,
      forexShock: -0.01,
    },
    {
      name: 'US Dollar Hyper-Surge (+10% USD)',
      description: 'Federal Reserve liquidity tightening, driving USD higher and depressing all dollar-denominated assets.',
      cryptoShock: -0.22,
      equitiesShock: -0.12,
      metalsShock: -0.10,
      forexShock: -0.08,
    },
    {
      name: 'Stagflationary Inflation Spike',
      description: 'Commodities and gold rally while equities and bonds suffer severe stagflationary contraction.',
      cryptoShock: -0.15,
      equitiesShock: -0.18,
      metalsShock: 0.20,
      forexShock: -0.05,
    },
  ];

  const stressResults = scenarios.map(sc => {
    let pnlImpact = 0;
    for (const pos of openPositions) {
      const inst = instruments[pos.symbol];
      const assetClass = inst?.assetClass || 'crypto';
      let shock = 0;
      if (assetClass === 'crypto') shock = sc.cryptoShock;
      else if (assetClass === 'stocks' || assetClass === 'indices') shock = sc.equitiesShock;
      else if (assetClass === 'metals') shock = sc.metalsShock;
      else if (assetClass === 'forex') shock = sc.forexShock;

      const notional = pos.quantity * pos.currentPrice;
      const posImpact = pos.side === 'BUY' ? notional * shock : notional * -shock;
      pnlImpact += posImpact;
    }

    const simulatedEquity = Math.max(0, equity + pnlImpact);
    const simulatedDD = equity > 0 ? ((equity - simulatedEquity) / equity) * 100 : 100;
    const marginCallRisk = simulatedEquity <= totalUsedMargin * 0.8;

    return {
      scenarioName: sc.name,
      description: sc.description,
      simulatedPnLImpact: Number(pnlImpact.toFixed(2)),
      simulatedEquity: Number(simulatedEquity.toFixed(2)),
      simulatedDrawdownPercent: Number(Math.max(0, simulatedDD).toFixed(1)),
      marginCallRisk,
    };
  });

  // Rebalancing Recommendations
  const rebalancing: PortfolioRiskReport['proposedRebalancing'] = [];
  for (const pos of openPositions) {
    const notional = pos.quantity * pos.currentPrice;
    const concentrationPct = totalExposure > 0 ? (notional / totalExposure) * 100 : 0;

    if (concentrationPct > 40) {
      rebalancing.push({
        symbol: pos.symbol,
        action: 'REDUCE',
        reason: `Position concentration (${concentrationPct.toFixed(1)}%) breaches safe 30% single-asset threshold.`,
        recommendedSizeChange: Number((-pos.quantity * 0.35).toFixed(4)),
        expectedCostOrFriction: `Taker fee approx $${(notional * 0.35 * 0.0006).toFixed(2)} plus 2-3 bps spread`,
      });
    } else if (pos.unrealizedPnL < -equity * 0.03) {
      rebalancing.push({
        symbol: pos.symbol,
        action: 'REDUCE',
        reason: 'Unrealized loss exceeds 3% total portfolio equity. Tighten stop or trim exposure.',
        recommendedSizeChange: Number((-pos.quantity * 0.5).toFixed(4)),
        expectedCostOrFriction: 'Crystallizes loss to protect portfolio free margin from liquidation',
      });
    } else {
      rebalancing.push({
        symbol: pos.symbol,
        action: 'MAINTAIN',
        reason: 'Within acceptable allocation and risk parameters.',
        recommendedSizeChange: 0,
        expectedCostOrFriction: 'Zero trading friction',
      });
    }
  }

  // Hedging Alternatives
  const hedgingAlternatives: PortfolioRiskReport['hedgingAlternatives'] = [
    {
      hedgeStrategy: 'Precious Metals Safe-Haven (XAU/USD)',
      instrument: 'XAU/USD',
      rationale: 'Historically negative correlation with equity drawdowns and stagflationary hedges.',
      estimatedCost: '0.02% spread + standard margin requirement',
      limitations: 'Opportunity drag during strong bull equities momentum; gold carries non-zero carry cost.',
    },
    {
      hedgeStrategy: 'Synthetic Inverse Delta Hedge (Perpetual Short)',
      instrument: openPositions[0]?.symbol || 'BTC/USDT',
      rationale: 'Direct 1:1 delta protection against downside tail risk without realizing capital gains/losses.',
      estimatedCost: 'Taker fee ~0.06% + funding rate variability',
      limitations: 'Basis risk; potential double fee if market rebounds abruptly.',
    },
    {
      hedgeStrategy: 'Cash / Stablecoin Buffer Allocation',
      instrument: 'USD / USDT',
      rationale: 'De-risk into 30% liquid cash reserves to maintain high free margin.',
      estimatedCost: 'Zero trading fees for idle cash; minor opportunity cost',
      limitations: 'Yield drag during rapid market expansion.',
    },
  ];

  return {
    totalEquity: Number(equity.toFixed(2)),
    totalExposure: Number(totalExposure.toFixed(2)),
    unrealizedPnL: Number(totalUnrealized.toFixed(2)),
    portfolioLeverage: Number(portfolioLeverage.toFixed(2)),
    usedMargin: Number(totalUsedMargin.toFixed(2)),
    freeMargin: Number(account.freeMargin.toFixed(2)),
    marginLevel: Number(marginLevel.toFixed(1)),
    positionConcentration,
    assetClassAllocation,
    currencyConcentration,
    correlationMatrix: {
      symbols: activeSymbols,
      matrix,
    },
    stressScenarios: stressResults,
    proposedRebalancing: rebalancing,
    hedgingAlternatives,
  };
}

/**
 * Quantitative Position Sizing Calculators
 */
export function calculatePositionSize(options: {
  accountEquity: number;
  entryPrice: number;
  stopLossPrice: number;
  riskPercent: number; // e.g. 1.5%
  winRate?: number;     // e.g. 0.55
  riskRewardRatio?: number; // e.g. 2.0
  instrument: Instrument;
  methodology: 'FIXED_FRACTIONAL' | 'KELLY_CRITERION' | 'ATR_VOLATILITY';
  atr?: number;
}): PositionSizeResult {
  const {
    accountEquity,
    entryPrice,
    stopLossPrice,
    riskPercent,
    winRate = 0.50,
    riskRewardRatio = 2.0,
    instrument,
    methodology,
    atr = entryPrice * 0.02,
  } = options;

  const priceDistance = Math.abs(entryPrice - stopLossPrice);
  const minDistance = entryPrice * 0.001; // minimum 0.1% stop distance
  const effectiveDistance = Math.max(priceDistance, minDistance);

  let targetRiskPercent = riskPercent;

  if (methodology === 'KELLY_CRITERION') {
    // Kelly % = W - (1 - W) / R
    const rawKelly = winRate - (1 - winRate) / riskRewardRatio;
    // Fractional Kelly (half-Kelly) for conservative risk management
    const halfKelly = Math.max(0.005, Math.min(0.05, (rawKelly / 2)));
    targetRiskPercent = halfKelly * 100;
  } else if (methodology === 'ATR_VOLATILITY') {
    // Volatility sizing: normalize risk based on 2x ATR
    const atrStop = 2 * atr;
    const volRatio = entryPrice > 0 ? atrStop / entryPrice : 0.02;
    targetRiskPercent = Math.max(0.5, Math.min(3.0, (riskPercent / (volRatio * 50))));
  }

  const allowableDollarRisk = accountEquity * (targetRiskPercent / 100);
  const rawQuantity = allowableDollarRisk / effectiveDistance;

  // Round according to precision and minQuantity
  const step = Math.pow(10, -instrument.quantityPrecision);
  const roundedQty = Math.max(
    instrument.minQuantity,
    Math.floor(rawQuantity / step) * step
  );

  const notional = roundedQty * entryPrice;
  const requiredMargin = notional * (instrument.marginRequirement || 0.05);
  const effectiveLeverage = accountEquity > 0 ? notional / accountEquity : 0;

  return {
    recommendedQuantity: Number(roundedQty.toFixed(instrument.quantityPrecision)),
    capitalAtRisk: Number(allowableDollarRisk.toFixed(2)),
    riskPercentOfCapital: Number(targetRiskPercent.toFixed(2)),
    maxAllowableLoss: Number(allowableDollarRisk.toFixed(2)),
    requiredMargin: Number(requiredMargin.toFixed(2)),
    effectiveLeverage: Number(effectiveLeverage.toFixed(2)),
    methodologyNotes:
      methodology === 'KELLY_CRITERION'
        ? `Applied Half-Kelly sizing based on ${Math.round(winRate * 100)}% historical win rate and ${riskRewardRatio.toFixed(1)} R:R.`
        : methodology === 'ATR_VOLATILITY'
        ? `Sized dynamically against 2x ATR volatility (${atr.toFixed(instrument.pricePrecision)} pts).`
        : `Fixed fractional sizing strictly risking ${targetRiskPercent}% of account equity.`,
  };
}
