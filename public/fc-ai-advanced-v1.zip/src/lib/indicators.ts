/**
 * FC AI ADVANCED - CANONICAL QUANTITATIVE CALCULATION LIBRARY
 * Single canonical calculation source for all modules.
 * Standardized indicator mathematical formulas.
 */

import { OHLCVCandle, TechnicalSummary, MarketRegimeType, MarketRegimeAnalysis, Timeframe } from '../types/market';

/**
 * Simple Moving Average (SMA)
 */
export function calculateSMA(data: number[], period: number): (number | null)[] {
  const result: (number | null)[] = new Array(data.length).fill(null);
  if (data.length < period || period <= 0) return result;

  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += data[i];
  }
  result[period - 1] = sum / period;

  for (let i = period; i < data.length; i++) {
    sum += data[i] - data[i - period];
    result[i] = sum / period;
  }
  return result;
}

/**
 * Exponential Moving Average (EMA)
 * Multiplier = 2 / (period + 1)
 */
export function calculateEMA(data: number[], period: number): (number | null)[] {
  const result: (number | null)[] = new Array(data.length).fill(null);
  if (data.length < period || period <= 0) return result;

  const multiplier = 2 / (period + 1);

  // Initial EMA is the SMA of the first 'period' elements
  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += data[i];
  }
  let prevEMA = sum / period;
  result[period - 1] = prevEMA;

  for (let i = period; i < data.length; i++) {
    const currentVal = data[i];
    const currentEMA = (currentVal - prevEMA) * multiplier + prevEMA;
    result[i] = currentEMA;
    prevEMA = currentEMA;
  }
  return result;
}

/**
 * Relative Strength Index (RSI - Wilder's smoothed method)
 */
export function calculateRSI(data: number[], period: number = 14): (number | null)[] {
  const result: (number | null)[] = new Array(data.length).fill(null);
  if (data.length <= period) return result;

  let gains = 0;
  let losses = 0;

  for (let i = 1; i <= period; i++) {
    const change = data[i] - data[i - 1];
    if (change > 0) gains += change;
    else losses += Math.abs(change);
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  result[period] = avgLoss === 0 ? 100 : 100 - (100 / (1 + avgGain / avgLoss));

  for (let i = period + 1; i < data.length; i++) {
    const change = data[i] - data[i - 1];
    const gain = change > 0 ? change : 0;
    const loss = change < 0 ? Math.abs(change) : 0;

    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;

    if (avgLoss === 0) {
      result[i] = 100;
    } else {
      const rs = avgGain / avgLoss;
      result[i] = 100 - (100 / (1 + rs));
    }
  }
  return result;
}

/**
 * Moving Average Convergence Divergence (MACD)
 */
export interface MACDPoint {
  macd: number | null;
  signal: number | null;
  histogram: number | null;
}

export function calculateMACD(
  data: number[],
  fastPeriod: number = 12,
  slowPeriod: number = 26,
  signalPeriod: number = 9
): MACDPoint[] {
  const length = data.length;
  const result: MACDPoint[] = Array.from({ length }, () => ({
    macd: null,
    signal: null,
    histogram: null,
  }));

  if (length < slowPeriod) return result;

  const fastEMA = calculateEMA(data, fastPeriod);
  const slowEMA = calculateEMA(data, slowPeriod);

  const macdLine: (number | null)[] = new Array(length).fill(null);
  const validMacdValues: number[] = [];
  const validIndices: number[] = [];

  for (let i = 0; i < length; i++) {
    const f = fastEMA[i];
    const s = slowEMA[i];
    if (f !== null && s !== null) {
      const val = f - s;
      macdLine[i] = val;
      validMacdValues.push(val);
      validIndices.push(i);
    }
  }

  if (validMacdValues.length < signalPeriod) {
    for (let i = 0; i < length; i++) {
      result[i].macd = macdLine[i];
    }
    return result;
  }

  const signalLineValues = calculateEMA(validMacdValues, signalPeriod);

  for (let j = 0; j < validIndices.length; j++) {
    const origIndex = validIndices[j];
    const m = macdLine[origIndex];
    const s = signalLineValues[j];
    result[origIndex].macd = m;
    result[origIndex].signal = s;
    if (m !== null && s !== null) {
      result[origIndex].histogram = m - s;
    }
  }

  return result;
}

/**
 * Bollinger Bands
 */
export interface BollingerBandsPoint {
  upper: number | null;
  middle: number | null;
  lower: number | null;
  bandwidth: number | null;
  percentB: number | null;
}

export function calculateBollingerBands(
  data: number[],
  period: number = 20,
  stdDevMultiplier: number = 2.0
): BollingerBandsPoint[] {
  const length = data.length;
  const result: BollingerBandsPoint[] = Array.from({ length }, () => ({
    upper: null,
    middle: null,
    lower: null,
    bandwidth: null,
    percentB: null,
  }));

  const sma = calculateSMA(data, period);

  for (let i = period - 1; i < length; i++) {
    const mid = sma[i];
    if (mid === null) continue;

    let varianceSum = 0;
    for (let j = i - period + 1; j <= i; j++) {
      const diff = data[j] - mid;
      varianceSum += diff * diff;
    }
    const stdDev = Math.sqrt(varianceSum / period);
    const upper = mid + stdDevMultiplier * stdDev;
    const lower = mid - stdDevMultiplier * stdDev;
    const bandwidth = mid > 0 ? (upper - lower) / mid : 0;
    const current = data[i];
    const percentB = upper !== lower ? (current - lower) / (upper - lower) : 0.5;

    result[i] = { upper, middle: mid, lower, bandwidth, percentB };
  }

  return result;
}

/**
 * Average True Range (ATR - Wilder's smoothed)
 */
export function calculateATR(candles: OHLCVCandle[], period: number = 14): (number | null)[] {
  const length = candles.length;
  const result: (number | null)[] = new Array(length).fill(null);
  if (length <= 1) return result;

  const trueRanges: number[] = new Array(length).fill(0);
  trueRanges[0] = candles[0].high - candles[0].low;

  for (let i = 1; i < length; i++) {
    const c = candles[i];
    const prevC = candles[i - 1].close;
    const tr1 = c.high - c.low;
    const tr2 = Math.abs(c.high - prevC);
    const tr3 = Math.abs(c.low - prevC);
    trueRanges[i] = Math.max(tr1, tr2, tr3);
  }

  if (length < period) return result;

  let sumTR = 0;
  for (let i = 0; i < period; i++) {
    sumTR += trueRanges[i];
  }
  let prevATR = sumTR / period;
  result[period - 1] = prevATR;

  for (let i = period; i < length; i++) {
    const currentATR = (prevATR * (period - 1) + trueRanges[i]) / period;
    result[i] = currentATR;
    prevATR = currentATR;
  }

  return result;
}

/**
 * Average Directional Index (ADX) & Directional Movement (+DI, -DI)
 */
export interface ADXPoint {
  adx: number | null;
  plusDI: number | null;
  minusDI: number | null;
}

export function calculateADX(candles: OHLCVCandle[], period: number = 14): ADXPoint[] {
  const length = candles.length;
  const result: ADXPoint[] = Array.from({ length }, () => ({
    adx: null,
    plusDI: null,
    minusDI: null,
  }));

  if (length < period * 2) return result;

  const tr: number[] = [0];
  const plusDM: number[] = [0];
  const minusDM: number[] = [0];

  for (let i = 1; i < length; i++) {
    const high = candles[i].high;
    const low = candles[i].low;
    const prevClose = candles[i - 1].close;
    const prevHigh = candles[i - 1].high;
    const prevLow = candles[i - 1].low;

    const trVal = Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose));
    tr.push(trVal);

    const upMove = high - prevHigh;
    const downMove = prevLow - low;

    if (upMove > downMove && upMove > 0) {
      plusDM.push(upMove);
    } else {
      plusDM.push(0);
    }

    if (downMove > upMove && downMove > 0) {
      minusDM.push(downMove);
    } else {
      minusDM.push(0);
    }
  }

  // Smooth TR, +DM, -DM using Wilder's smoothing
  let smoothTR = 0;
  let smoothPlusDM = 0;
  let smoothMinusDM = 0;

  for (let i = 0; i < period; i++) {
    smoothTR += tr[i];
    smoothPlusDM += plusDM[i];
    smoothMinusDM += minusDM[i];
  }

  const dxValues: number[] = [];
  const dxIndices: number[] = [];

  for (let i = period; i < length; i++) {
    smoothTR = smoothTR - smoothTR / period + tr[i];
    smoothPlusDM = smoothPlusDM - smoothPlusDM / period + plusDM[i];
    smoothMinusDM = smoothMinusDM - smoothMinusDM / period + minusDM[i];

    const plusDI = smoothTR !== 0 ? (smoothPlusDM / smoothTR) * 100 : 0;
    const minusDI = smoothTR !== 0 ? (smoothMinusDM / smoothTR) * 100 : 0;

    result[i].plusDI = plusDI;
    result[i].minusDI = minusDI;

    const diSum = plusDI + minusDI;
    const dx = diSum !== 0 ? (Math.abs(plusDI - minusDI) / diSum) * 100 : 0;
    dxValues.push(dx);
    dxIndices.push(i);
  }

  if (dxValues.length < period) return result;

  let sumDX = 0;
  for (let i = 0; i < period; i++) {
    sumDX += dxValues[i];
  }
  let prevADX = sumDX / period;
  result[dxIndices[period - 1]].adx = prevADX;

  for (let i = period; i < dxValues.length; i++) {
    prevADX = (prevADX * (period - 1) + dxValues[i]) / period;
    result[dxIndices[i]].adx = prevADX;
  }

  return result;
}

/**
 * Stochastic Oscillator (%K and %D)
 */
export interface StochasticPoint {
  k: number | null;
  d: number | null;
}

export function calculateStochastic(
  candles: OHLCVCandle[],
  kPeriod: number = 14,
  dPeriod: number = 3,
  smooth: number = 3
): StochasticPoint[] {
  const length = candles.length;
  const result: StochasticPoint[] = Array.from({ length }, () => ({ k: null, d: null }));
  if (length < kPeriod) return result;

  const rawK: (number | null)[] = new Array(length).fill(null);

  for (let i = kPeriod - 1; i < length; i++) {
    let highestHigh = -Infinity;
    let lowestLow = Infinity;

    for (let j = i - kPeriod + 1; j <= i; j++) {
      if (candles[j].high > highestHigh) highestHigh = candles[j].high;
      if (candles[j].low < lowestLow) lowestLow = candles[j].low;
    }

    const currentClose = candles[i].close;
    const range = highestHigh - lowestLow;
    rawK[i] = range === 0 ? 50 : ((currentClose - lowestLow) / range) * 100;
  }

  // Smooth %K
  const validK: number[] = [];
  const validIdx: number[] = [];
  for (let i = 0; i < length; i++) {
    if (rawK[i] !== null) {
      validK.push(rawK[i] as number);
      validIdx.push(i);
    }
  }

  const smoothedK = calculateSMA(validK, smooth);
  const finalK: (number | null)[] = new Array(length).fill(null);
  const kForD: number[] = [];
  const kForDIndices: number[] = [];

  for (let j = 0; j < validIdx.length; j++) {
    const orig = validIdx[j];
    const val = smoothedK[j];
    finalK[orig] = val;
    if (val !== null) {
      kForD.push(val);
      kForDIndices.push(orig);
    }
  }

  const smoothedD = calculateSMA(kForD, dPeriod);

  for (let j = 0; j < kForDIndices.length; j++) {
    const orig = kForDIndices[j];
    result[orig].k = finalK[orig];
    result[orig].d = smoothedD[j];
  }

  return result;
}

/**
 * Swing Highs and Swing Lows
 */
export interface SwingPoints {
  highs: { index: number; price: number; timestamp: number }[];
  lows: { index: number; price: number; timestamp: number }[];
}

export function detectSwingPoints(candles: OHLCVCandle[], lookback: number = 3): SwingPoints {
  const highs: { index: number; price: number; timestamp: number }[] = [];
  const lows: { index: number; price: number; timestamp: number }[] = [];

  if (candles.length < lookback * 2 + 1) return { highs, lows };

  for (let i = lookback; i < candles.length - lookback; i++) {
    const currentHigh = candles[i].high;
    const currentLow = candles[i].low;

    let isHigh = true;
    let isLow = true;

    for (let j = 1; j <= lookback; j++) {
      if (candles[i - j].high >= currentHigh || candles[i + j].high >= currentHigh) {
        isHigh = false;
      }
      if (candles[i - j].low <= currentLow || candles[i + j].low <= currentLow) {
        isLow = false;
      }
    }

    if (isHigh) {
      highs.push({ index: i, price: currentHigh, timestamp: candles[i].timestamp });
    }
    if (isLow) {
      lows.push({ index: i, price: currentLow, timestamp: candles[i].timestamp });
    }
  }

  return { highs, lows };
}

/**
 * Support & Resistance Cluster Extraction
 */
export function calculateSupportResistance(candles: OHLCVCandle[], count: number = 3): { supports: number[]; resistances: number[] } {
  if (candles.length === 0) return { supports: [], resistances: [] };
  const currentPrice = candles[candles.length - 1].close;
  const swings = detectSwingPoints(candles, 3);

  const rawSupports = swings.lows.map(s => s.price).filter(p => p < currentPrice);
  const rawResistances = swings.highs.map(s => s.price).filter(p => p > currentPrice);

  // Group into clusters within 0.75%
  const cluster = (prices: number[], isDesc: boolean) => {
    prices.sort((a, b) => (isDesc ? b - a : a - b));
    const clusters: number[] = [];
    for (const p of prices) {
      const match = clusters.find(c => Math.abs(c - p) / c < 0.0075);
      if (!match) {
        clusters.push(p);
      }
    }
    return clusters.slice(0, count);
  };

  const supports = cluster(rawSupports, true);
  const resistances = cluster(rawResistances, false);

  // Fallbacks if no swing detected
  if (supports.length === 0) {
    const minLow = Math.min(...candles.slice(-30).map(c => c.low));
    supports.push(minLow);
  }
  if (resistances.length === 0) {
    const maxHigh = Math.max(...candles.slice(-30).map(c => c.high));
    resistances.push(maxHigh);
  }

  return { supports, resistances };
}

/**
 * Candlestick Pattern Recognition
 */
export function detectCandlePattern(candles: OHLCVCandle[]): string {
  if (candles.length < 3) return 'Standard Candle';
  const c1 = candles[candles.length - 1]; // current/latest
  const c2 = candles[candles.length - 2]; // previous
  const c3 = candles[candles.length - 3]; // two back

  const body1 = Math.abs(c1.close - c1.open);
  const range1 = c1.high - c1.low;
  const upperWick1 = c1.high - Math.max(c1.close, c1.open);
  const lowerWick1 = Math.min(c1.close, c1.open) - c1.low;

  // Doji
  if (range1 > 0 && body1 / range1 < 0.1) {
    return 'Doji (Market Indecision)';
  }

  // Bullish Hammer
  if (range1 > 0 && lowerWick1 >= body1 * 2 && upperWick1 < body1 * 0.5 && c1.close >= c1.open) {
    return 'Hammer (Bullish Reversal Rejection)';
  }

  // Bearish Shooting Star
  if (range1 > 0 && upperWick1 >= body1 * 2 && lowerWick1 < body1 * 0.5 && c1.close <= c1.open) {
    return 'Shooting Star (Bearish Rejection)';
  }

  // Bullish Engulfing
  if (c2.close < c2.open && c1.close > c1.open && c1.open < c2.close && c1.close > c2.open) {
    return 'Bullish Engulfing';
  }

  // Bearish Engulfing
  if (c2.close > c2.open && c1.close < c1.open && c1.open > c2.close && c1.close < c2.open) {
    return 'Bearish Engulfing';
  }

  // Three White Soldiers
  if (c3.close > c3.open && c2.close > c2.open && c1.close > c1.open && c1.close > c2.close && c2.close > c3.close) {
    return 'Three White Soldiers (Strong Bullish Continuation)';
  }

  // Three Black Crows
  if (c3.close < c3.open && c2.close < c2.open && c1.close < c1.open && c1.close < c2.close && c2.close < c3.close) {
    return 'Three Black Crows (Strong Bearish Continuation)';
  }

  return c1.close >= c1.open ? 'Bullish Expansion Candle' : 'Bearish Expansion Candle';
}

/**
 * Comprehensive Technical Summary Builder
 */
export function buildTechnicalSummary(candles: OHLCVCandle[]): TechnicalSummary {
  if (candles.length === 0) {
    throw new Error('Cannot build technical summary with empty candle dataset');
  }

  const closes = candles.map(c => c.close);
  const currentPrice = closes[closes.length - 1];

  const rsiArr = calculateRSI(closes, 14);
  const latestRSI = rsiArr[rsiArr.length - 1] ?? 50;

  const macdArr = calculateMACD(closes, 12, 26, 9);
  const latestMACD = macdArr[macdArr.length - 1] ?? { macd: 0, signal: 0, histogram: 0 };
  const prevMACD = macdArr[macdArr.length - 2] ?? { macd: 0, signal: 0, histogram: 0 };

  let macdTrend: 'BULLISH' | 'BEARISH' | 'CROSSOVER_BULL' | 'CROSSOVER_BEAR' = 'BULLISH';
  const m = latestMACD.macd ?? 0;
  const s = latestMACD.signal ?? 0;
  const pm = prevMACD.macd ?? 0;
  const ps = prevMACD.signal ?? 0;

  if (pm <= ps && m > s) {
    macdTrend = 'CROSSOVER_BULL';
  } else if (pm >= ps && m < s) {
    macdTrend = 'CROSSOVER_BEAR';
  } else if (m >= s) {
    macdTrend = 'BULLISH';
  } else {
    macdTrend = 'BEARISH';
  }

  const sma20Arr = calculateSMA(closes, 20);
  const sma50Arr = calculateSMA(closes, 50);
  const sma200Arr = calculateSMA(closes, Math.min(200, closes.length));
  const ema9Arr = calculateEMA(closes, 9);
  const ema21Arr = calculateEMA(closes, 21);

  const sma20 = sma20Arr[sma20Arr.length - 1] ?? currentPrice;
  const sma50 = sma50Arr[sma50Arr.length - 1] ?? currentPrice;
  const sma200 = sma200Arr[sma200Arr.length - 1] ?? currentPrice;
  const ema9 = ema9Arr[ema9Arr.length - 1] ?? currentPrice;
  const ema21 = ema21Arr[ema21Arr.length - 1] ?? currentPrice;

  let maAlignment: 'STRONG_BULL' | 'MILD_BULL' | 'MILD_BEAR' | 'STRONG_BEAR' | 'MIXED' = 'MIXED';
  if (ema9 > ema21 && ema21 > sma50 && currentPrice > ema9) {
    maAlignment = 'STRONG_BULL';
  } else if (ema9 > ema21) {
    maAlignment = 'MILD_BULL';
  } else if (ema9 < ema21 && ema21 < sma50 && currentPrice < ema9) {
    maAlignment = 'STRONG_BEAR';
  } else if (ema9 < ema21) {
    maAlignment = 'MILD_BEAR';
  }

  const bbArr = calculateBollingerBands(closes, 20, 2);
  const latestBB = bbArr[bbArr.length - 1] ?? { upper: currentPrice, middle: currentPrice, lower: currentPrice, bandwidth: 0, percentB: 0.5 };

  const atrArr = calculateATR(candles, 14);
  const latestATR = atrArr[atrArr.length - 1] ?? (candles[candles.length - 1].high - candles[candles.length - 1].low);

  const adxArr = calculateADX(candles, 14);
  const latestADX = adxArr[adxArr.length - 1] ?? { adx: 20, plusDI: 20, minusDI: 20 };
  const adxVal = latestADX.adx ?? 20;

  const stochArr = calculateStochastic(candles, 14, 3, 3);
  const latestStoch = stochArr[stochArr.length - 1] ?? { k: 50, d: 50 };

  const sr = calculateSupportResistance(candles, 3);
  const swings = detectSwingPoints(candles, 3);
  const lastSwingHigh = swings.highs[swings.highs.length - 1]?.price;
  const lastSwingLow = swings.lows[swings.lows.length - 1]?.price;
  const pattern = detectCandlePattern(candles);

  return {
    rsi: Number(latestRSI.toFixed(2)),
    rsiState: latestRSI >= 70 ? 'OVERBOUGHT' : latestRSI <= 30 ? 'OVERSOLD' : 'NEUTRAL',
    macd: {
      macd: Number((latestMACD.macd ?? 0).toFixed(4)),
      signal: Number((latestMACD.signal ?? 0).toFixed(4)),
      histogram: Number((latestMACD.histogram ?? 0).toFixed(4)),
      trend: macdTrend,
    },
    sma20: Number(sma20.toFixed(4)),
    sma50: Number(sma50.toFixed(4)),
    sma200: Number(sma200.toFixed(4)),
    ema9: Number(ema9.toFixed(4)),
    ema21: Number(ema21.toFixed(4)),
    maAlignment,
    bollingerBands: {
      upper: Number((latestBB.upper ?? currentPrice).toFixed(4)),
      middle: Number((latestBB.middle ?? currentPrice).toFixed(4)),
      lower: Number((latestBB.lower ?? currentPrice).toFixed(4)),
      bandwidth: Number((latestBB.bandwidth ?? 0).toFixed(4)),
      percentB: Number((latestBB.percentB ?? 0.5).toFixed(4)),
    },
    atr: Number(latestATR.toFixed(4)),
    adx: {
      adx: Number(adxVal.toFixed(2)),
      plusDI: Number((latestADX.plusDI ?? 20).toFixed(2)),
      minusDI: Number((latestADX.minusDI ?? 20).toFixed(2)),
      strength: adxVal >= 35 ? 'STRONG_TREND' : adxVal >= 22 ? 'TRENDING' : 'WEAK_CHOPPY',
    },
    stochastic: {
      k: Number((latestStoch.k ?? 50).toFixed(2)),
      d: Number((latestStoch.d ?? 50).toFixed(2)),
    },
    supportLevels: sr.supports.map(s => Number(s.toFixed(4))),
    resistanceLevels: sr.resistances.map(r => Number(r.toFixed(4))),
    swingHigh: lastSwingHigh ? Number(lastSwingHigh.toFixed(4)) : undefined,
    swingLow: lastSwingLow ? Number(lastSwingLow.toFixed(4)) : undefined,
    priceActionPattern: pattern,
  };
}

/**
 * MODULE 11: Market Regime Detector
 * Classifies market conditions using ADX, ATR%, Trend Slope, Volatility & Price Action.
 */
export function detectMarketRegime(
  candles: OHLCVCandle[],
  symbol: string,
  timeframe: Timeframe = '1H'
): MarketRegimeAnalysis {
  if (candles.length < 20) {
    return {
      symbol,
      timeframe,
      regime: 'TRANSITIONAL',
      confidenceScore: 50,
      adxValue: 20,
      atrPercent: 1.0,
      trendSlope: 0,
      realizedVolatility: 0.15,
      evidence: ['Insufficient historical candles (<20) to confirm mature regime'],
      recommendedStrategy: 'Capital preservation / Wait for candle confirmation',
      unfavorableStrategy: 'Aggressive trend following',
      timestamp: Date.now(),
    };
  }

  const tech = buildTechnicalSummary(candles);
  const closes = candles.map(c => c.close);
  const currentPrice = closes[closes.length - 1];

  // ADX & DI
  const adx = tech.adx.adx;
  const plusDI = tech.adx.plusDI;
  const minusDI = tech.adx.minusDI;

  // Realized volatility over past 20 candles
  const returns: number[] = [];
  for (let i = closes.length - 20; i < closes.length; i++) {
    if (i > 0) {
      returns.push(Math.log(closes[i] / closes[i - 1]));
    }
  }
  const meanReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance = returns.reduce((sum, r) => sum + Math.pow(r - meanReturn, 2), 0) / returns.length;
  const realizedVol = Math.sqrt(variance) * Math.sqrt(365 * 24); // annualized approx

  const atrPct = (tech.atr / currentPrice) * 100;

  // Linear regression slope of close over last 15 candles
  const n = 15;
  const recentCloses = closes.slice(-n);
  let sumX = 0;
  let sumY = 0;
  let sumXY = 0;
  let sumX2 = 0;
  for (let i = 0; i < n; i++) {
    sumX += i;
    sumY += recentCloses[i];
    sumXY += i * recentCloses[i];
    sumX2 += i * i;
  }
  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  const normalizedSlope = (slope / currentPrice) * 100; // % per candle

  const evidence: string[] = [];
  let regime: MarketRegimeType = 'TRANSITIONAL';
  let confidence = 70;
  let recommended = 'Multi-timeframe wait';
  let unfavorable = 'High-leverage scalping';

  evidence.push(`ADX reading: ${adx.toFixed(1)} (${tech.adx.strength})`);
  evidence.push(`ATR volatility: ${atrPct.toFixed(2)}% of current asset price`);
  evidence.push(`Trend slope: ${normalizedSlope > 0 ? '+' : ''}${normalizedSlope.toFixed(3)}% per bar`);
  evidence.push(`MA Alignment: ${tech.maAlignment.replace('_', ' ')}`);

  if (adx >= 28 && plusDI > minusDI + 6 && normalizedSlope > 0.08) {
    regime = 'STRONG_UPTREND';
    confidence = Math.min(95, Math.round(adx * 1.5 + Math.abs(normalizedSlope) * 100));
    recommended = 'Trend continuation, pullbacks to 21 EMA, breakout expansions';
    unfavorable = 'Counter-trend shorting, aggressive mean reversion';
    evidence.push('+DI dominates -DI with steep positive slope across moving averages');
  } else if (adx >= 28 && minusDI > plusDI + 6 && normalizedSlope < -0.08) {
    regime = 'STRONG_DOWNTREND';
    confidence = Math.min(95, Math.round(adx * 1.5 + Math.abs(normalizedSlope) * 100));
    recommended = 'Trend following short, selling rallies to 21 EMA / 50 SMA';
    unfavorable = 'Knife catching, unhedged long positions';
    evidence.push('-DI dominates +DI with sharp negative price velocity');
  } else if (atrPct > 2.8 || tech.bollingerBands.bandwidth > 0.08 || realizedVol > 0.65) {
    regime = 'HIGH_VOLATILITY';
    confidence = 82;
    recommended = 'Reduced position sizes, wider stops, volatility breakout or straddles';
    unfavorable = 'Tight stop orders, heavy margin leverage';
    evidence.push('Bollinger bandwidth expansion and elevated ATR indicate extreme variance');
  } else if (adx < 20 && atrPct < 1.0 && Math.abs(normalizedSlope) < 0.04) {
    regime = 'RANGE_BOUND';
    confidence = 85;
    recommended = 'Bollinger band boundary fades, RSI overbought/oversold mean reversion';
    unfavorable = 'Breakout chasing without volume confirmation';
    evidence.push('ADX below 20 confirms absence of directional trend; price oscillating within S&R');
  } else if (atrPct < 0.6 && tech.bollingerBands.bandwidth < 0.03) {
    regime = 'LOW_VOLATILITY';
    confidence = 78;
    recommended = 'Prepare for volatility expansion; set alert at Bollinger extremes';
    unfavorable = 'Scalping inside microscopic ATR ranges';
    evidence.push('Volatility compression squeeze detected; consolidation preceding breakout');
  } else {
    regime = 'TRANSITIONAL';
    confidence = 65;
    recommended = 'Wait for daily candle close to validate regime transition';
    unfavorable = 'Premature high-conviction directional bets';
    evidence.push('Conflicting directional indicators; momentum re-aligning');
  }

  return {
    symbol,
    timeframe,
    regime,
    confidenceScore: confidence,
    adxValue: Number(adx.toFixed(1)),
    atrPercent: Number(atrPct.toFixed(2)),
    trendSlope: Number(normalizedSlope.toFixed(3)),
    realizedVolatility: Number(realizedVol.toFixed(2)),
    evidence,
    recommendedStrategy: recommended,
    unfavorableStrategy: unfavorable,
    timestamp: Date.now(),
  };
}
