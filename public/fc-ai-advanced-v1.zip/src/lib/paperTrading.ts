/**
 * FC AI ADVANCED - REAL-PRICE PAPER TRADING & ACCOUNTING ENGINE (MODULE 12)
 * Institutional-grade virtual trading execution with strict risk safety controls,
 * genuine bid/ask attribution, slippage simulation, and transparent margin accounting.
 */

import {
  PaperAccount,
  PaperOrder,
  PaperPosition,
  SafetySettings,
  MarketQuote,
  Instrument,
  OrderSide,
  OrderType,
} from '../types/market';

export interface ExecutionResult {
  success: boolean;
  order?: PaperOrder;
  position?: PaperPosition;
  account: PaperAccount;
  error?: string;
  auditMessage: string;
}

export class PaperTradingEngine {
  private account: PaperAccount;
  private positions: PaperPosition[] = [];
  private orders: PaperOrder[] = [];
  private safetySettings: SafetySettings;
  private isProcessingAction = false; // anti-double-click mutex

  constructor(
    initialAccount?: PaperAccount,
    initialPositions?: PaperPosition[],
    initialOrders?: PaperOrder[],
    safetySettings?: SafetySettings
  ) {
    this.account = initialAccount || {
      accountNumber: 'FC-ADV-001889',
      currency: 'USD',
      initialBalance: 100000,
      virtualBalance: 100000,
      virtualEquity: 100000,
      freeMargin: 100000,
      usedMargin: 0,
      marginLevel: 999.0,
      totalRealizedPnL: 0,
      totalUnrealizedPnL: 0,
      totalFeesPaid: 0,
      winCount: 0,
      lossCount: 0,
      updatedAt: Date.now(),
    };
    this.positions = initialPositions || [];
    this.orders = initialOrders || [];
    this.safetySettings = safetySettings || {
      maxRiskPerTradePercent: 2.5,
      maxDailySimulatedLoss: 2500,
      maxOpenPositions: 6,
      maxExposurePerInstrumentPercent: 30,
      maxPortfolioLeverage: 10,
      minRequiredDataQualityScore: 80,
      minRiskRewardRatio: 1.5,
      cooldownMinutesAfterLoss: 3,
    };
  }

  public getAccount(): PaperAccount {
    return { ...this.account };
  }

  public getPositions(): PaperPosition[] {
    return [...this.positions];
  }

  public getOpenPositions(): PaperPosition[] {
    return this.positions.filter(p => p.status === 'OPEN');
  }

  public getOrders(): PaperOrder[] {
    return [...this.orders];
  }

  public getSafetySettings(): SafetySettings {
    return { ...this.safetySettings };
  }

  public updateSafetySettings(settings: Partial<SafetySettings>): void {
    this.safetySettings = { ...this.safetySettings, ...settings };
  }

  /**
   * Reset account back to initial capital
   */
  public resetAccount(startingCapital: number = 100000): void {
    this.account = {
      accountNumber: 'FC-ADV-' + Math.floor(100000 + Math.random() * 900000),
      currency: 'USD',
      initialBalance: startingCapital,
      virtualBalance: startingCapital,
      virtualEquity: startingCapital,
      freeMargin: startingCapital,
      usedMargin: 0,
      marginLevel: 999.0,
      totalRealizedPnL: 0,
      totalUnrealizedPnL: 0,
      totalFeesPaid: 0,
      winCount: 0,
      lossCount: 0,
      updatedAt: Date.now(),
    };
    this.positions = [];
    this.orders = [];
  }

  /**
   * Validate safety rules before submitting an order
   */
  public validateOrderSafety(
    symbol: string,
    side: OrderSide,
    quantity: number,
    price: number,
    stopLoss: number | undefined,
    takeProfit: number | undefined,
    quote: MarketQuote,
    instrument: Instrument
  ): { valid: boolean; reason?: string } {
    // 1. Data Quality & Freshness
    if (quote.isStale) {
      return { valid: false, reason: `Safety Block: Market quote for ${symbol} is stale (>60s old). Live execution halted.` };
    }
    if (quote.status === 'OFFLINE' || quote.status === 'CLOSED') {
      return { valid: false, reason: `Safety Block: Market feed is currently ${quote.status}. Orders can only be placed on active quotes.` };
    }
    if (price <= 0 || quote.bid <= 0 || quote.ask <= 0) {
      return { valid: false, reason: 'Safety Block: Non-positive price detected from data provider.' };
    }

    // 2. Cooldown check after recent loss
    if (this.safetySettings.lastLossTimestamp && this.safetySettings.cooldownMinutesAfterLoss > 0) {
      const elapsedMins = (Date.now() - this.safetySettings.lastLossTimestamp) / (1000 * 60);
      if (elapsedMins < this.safetySettings.cooldownMinutesAfterLoss) {
        const remaining = (this.safetySettings.cooldownMinutesAfterLoss - elapsedMins).toFixed(1);
        return {
          valid: false,
          reason: `Discipline Cooldown Active: ${remaining} mins remaining after recent losing trade to prevent revenge trading.`,
        };
      }
    }

    // 3. Max open positions
    const openPos = this.getOpenPositions();
    if (openPos.length >= this.safetySettings.maxOpenPositions) {
      return {
        valid: false,
        reason: `Safety Limit: Maximum open positions limit (${this.safetySettings.maxOpenPositions}) reached. Close an active position first.`,
      };
    }

    // 4. Maximum Daily Simulated Loss Check
    const todayLoss = -Math.min(0, this.account.totalRealizedPnL);
    if (todayLoss >= this.safetySettings.maxDailySimulatedLoss) {
      return {
        valid: false,
        reason: `Risk Guard: Daily simulated loss threshold ($${this.safetySettings.maxDailySimulatedLoss}) reached. Terminal trading disabled for today.`,
      };
    }

    // 5. Quantity validation
    if (quantity < instrument.minQuantity) {
      return {
        valid: false,
        reason: `Invalid Quantity: Minimum order size for ${symbol} is ${instrument.minQuantity}. Requested: ${quantity}.`,
      };
    }

    // 6. Stop Loss & Risk/Reward Validation
    if (stopLoss !== undefined && stopLoss > 0) {
      if (side === 'BUY' && stopLoss >= price) {
        return { valid: false, reason: `Invalid Stop Loss: For a BUY order, stop loss (${stopLoss}) must be strictly below entry price (${price}).` };
      }
      if (side === 'SELL' && stopLoss <= price) {
        return { valid: false, reason: `Invalid Stop Loss: For a SELL order, stop loss (${stopLoss}) must be strictly above entry price (${price}).` };
      }

      // Check Risk per trade %
      const lossPerUnit = Math.abs(price - stopLoss);
      const totalDollarRisk = lossPerUnit * quantity;
      const maxAllowableRisk = this.account.virtualEquity * (this.safetySettings.maxRiskPerTradePercent / 100);

      if (totalDollarRisk > maxAllowableRisk * 1.05) { // allow 5% rounding tolerance
        return {
          valid: false,
          reason: `Risk Limit Exceeded: Dollar risk ($${totalDollarRisk.toFixed(2)}) exceeds max allowed risk ($${maxAllowableRisk.toFixed(2)} = ${this.safetySettings.maxRiskPerTradePercent}% of equity). Reduce position size.`,
        };
      }

      // Check Minimum Risk/Reward if take profit is also provided
      if (takeProfit !== undefined && takeProfit > 0) {
        const profitPerUnit = Math.abs(takeProfit - price);
        const rr = lossPerUnit > 0 ? profitPerUnit / lossPerUnit : 0;
        if (rr < this.safetySettings.minRiskRewardRatio) {
          return {
            valid: false,
            reason: `Risk/Reward Rejection: Proposed R:R is ${rr.toFixed(2)}, which is below your safety minimum threshold of ${this.safetySettings.minRiskRewardRatio.toFixed(2)}:1.`,
          };
        }
      }
    }

    // 7. Notional & Instrument Exposure Check
    const notional = quantity * price;
    const currentSymbolExposure = openPos
      .filter(p => p.symbol === symbol)
      .reduce((sum, p) => sum + p.quantity * p.currentPrice, 0);

    const projectedExposure = currentSymbolExposure + notional;
    const maxExposureAllowed = this.account.virtualEquity * (this.safetySettings.maxExposurePerInstrumentPercent / 100);

    if (projectedExposure > maxExposureAllowed) {
      return {
        valid: false,
        reason: `Concentration Limit: Total ${symbol} exposure ($${projectedExposure.toFixed(2)}) would exceed ${this.safetySettings.maxExposurePerInstrumentPercent}% limit ($${maxExposureAllowed.toFixed(2)}).`,
      };
    }

    // 8. Leverage & Margin Check
    const requiredMargin = notional * instrument.marginRequirement;
    if (requiredMargin > this.account.freeMargin) {
      return {
        valid: false,
        reason: `Insufficient Margin: Order requires $${requiredMargin.toFixed(2)} margin, but free virtual margin is only $${this.account.freeMargin.toFixed(2)}.`,
      };
    }

    const currentTotalExposure = openPos.reduce((sum, p) => sum + p.quantity * p.currentPrice, 0);
    const projectedTotalLeverage = (currentTotalExposure + notional) / Math.max(1, this.account.virtualEquity);
    if (projectedTotalLeverage > this.safetySettings.maxPortfolioLeverage) {
      return {
        valid: false,
        reason: `Portfolio Leverage Limit: Total portfolio leverage would reach ${projectedTotalLeverage.toFixed(1)}x (Max allowed: ${this.safetySettings.maxPortfolioLeverage}x).`,
      };
    }

    return { valid: true };
  }

  /**
   * Execute Market Order with bid/ask spread and realistic slippage
   */
  public executeMarketOrder(params: {
    symbol: string;
    side: OrderSide;
    quantity: number;
    leverage?: number;
    stopLoss?: number;
    takeProfit?: number;
    quote: MarketQuote;
    instrument: Instrument;
  }): ExecutionResult {
    if (this.isProcessingAction) {
      return {
        success: false,
        account: this.account,
        error: 'Duplicate Action Prevented: Another order is currently being processed.',
        auditMessage: 'Double-click mutex triggered',
      };
    }

    this.isProcessingAction = true;
    try {
      const { symbol, side, quantity, leverage = 1, stopLoss, takeProfit, quote, instrument } = params;

      // Executable base quote: BUY takes Ask, SELL takes Bid
      const baseExecutionPrice = side === 'BUY' ? quote.ask : quote.bid;

      // Safety check
      const safety = this.validateOrderSafety(
        symbol,
        side,
        quantity,
        baseExecutionPrice,
        stopLoss,
        takeProfit,
        quote,
        instrument
      );
      if (!safety.valid) {
        return {
          success: false,
          account: this.account,
          error: safety.reason,
          auditMessage: `Safety Gate Rejection: ${safety.reason}`,
        };
      }

      // Simulate slippage (e.g. 2-5 bps)
      const slippageRate = (instrument.slippageBps || 3) / 10000;
      const slippageMultiplier = side === 'BUY' ? (1 + slippageRate) : (1 - slippageRate);
      const executedPrice = Number((baseExecutionPrice * slippageMultiplier).toFixed(instrument.pricePrecision));

      // Calculate fee
      const notional = quantity * executedPrice;
      const fee = Number((notional * instrument.takerFeeRate).toFixed(2));
      const requiredMargin = Number((notional * (1 / leverage)).toFixed(2));

      // Create Order Record
      const orderId = 'ORD-' + Date.now().toString(36).toUpperCase() + '-' + Math.floor(100 + Math.random() * 900);
      const newOrder: PaperOrder = {
        id: orderId,
        symbol,
        side,
        type: 'MARKET',
        quantity,
        price: executedPrice,
        stopLoss,
        takeProfit,
        leverage,
        status: 'FILLED',
        createdAt: Date.now(),
        filledAt: Date.now(),
      };
      this.orders.unshift(newOrder);

      // Create Position Record
      const posId = 'POS-' + Date.now().toString(36).toUpperCase() + '-' + Math.floor(100 + Math.random() * 900);
      const newPosition: PaperPosition = {
        id: posId,
        symbol,
        side,
        quantity,
        entryPrice: executedPrice,
        currentPrice: executedPrice,
        stopLoss,
        takeProfit,
        leverage,
        margin: requiredMargin,
        unrealizedPnL: 0,
        realizedPnL: 0,
        fees: fee,
        status: 'OPEN',
        openedAt: Date.now(),
      };
      this.positions.unshift(newPosition);

      // Update Account State
      this.account.virtualBalance -= fee;
      this.account.totalFeesPaid += fee;
      this.recalculateAccount();

      return {
        success: true,
        order: newOrder,
        position: newPosition,
        account: this.account,
        auditMessage: `Executed ${side} ${quantity} ${symbol} @ ${executedPrice} (Fee: $${fee.toFixed(2)}, Margin: $${requiredMargin.toFixed(2)})`,
      };
    } finally {
      this.isProcessingAction = false;
    }
  }

  /**
   * Close an open position
   */
  public closePosition(
    positionId: string,
    quote: MarketQuote,
    instrument: Instrument,
    reason: 'MANUAL' | 'STOP_LOSS' | 'TAKE_PROFIT' | 'LIQUIDATION' | 'RISK_LIMIT' = 'MANUAL'
  ): ExecutionResult {
    if (this.isProcessingAction) {
      return {
        success: false,
        account: this.account,
        error: 'Double-close action prevented.',
        auditMessage: 'Double action blocked by mutex',
      };
    }

    this.isProcessingAction = true;
    try {
      const pos = this.positions.find(p => p.id === positionId && p.status === 'OPEN');
      if (!pos) {
        return {
          success: false,
          account: this.account,
          error: 'Position not found or already closed.',
          auditMessage: 'Position state invalid',
        };
      }

      // Exit price: BUY closes at Bid, SELL closes at Ask
      const baseExitPrice = pos.side === 'BUY' ? quote.bid : quote.ask;
      const slippageRate = (instrument.slippageBps || 3) / 10000;
      const slippageMultiplier = pos.side === 'BUY' ? (1 - slippageRate) : (1 + slippageRate);
      const exitPrice = Number((baseExitPrice * slippageMultiplier).toFixed(instrument.pricePrecision));

      // Realized PnL calculation
      const grossPnL = pos.side === 'BUY'
        ? (exitPrice - pos.entryPrice) * pos.quantity
        : (pos.entryPrice - exitPrice) * pos.quantity;

      const exitFee = Number((pos.quantity * exitPrice * instrument.takerFeeRate).toFixed(2));
      const netPnL = Number((grossPnL - exitFee).toFixed(2));

      pos.status = 'CLOSED';
      pos.closedAt = Date.now();
      pos.closePrice = exitPrice;
      pos.closeReason = reason;
      pos.realizedPnL = netPnL;
      pos.unrealizedPnL = 0;
      pos.fees += exitFee;

      // Update Account
      this.account.virtualBalance += netPnL;
      this.account.totalRealizedPnL += netPnL;
      this.account.totalFeesPaid += exitFee;

      if (netPnL >= 0) {
        this.account.winCount += 1;
      } else {
        this.account.lossCount += 1;
        // Record timestamp for discipline cooldown
        this.safetySettings.lastLossTimestamp = Date.now();
      }

      this.recalculateAccount();

      return {
        success: true,
        position: pos,
        account: this.account,
        auditMessage: `Closed ${pos.side} ${pos.quantity} ${pos.symbol} @ ${exitPrice} | Net P&L: ${netPnL >= 0 ? '+' : ''}$${netPnL.toFixed(2)} (${reason})`,
      };
    } finally {
      this.isProcessingAction = false;
    }
  }

  /**
   * Tick update: Updates current prices, marks unrealized P&L,
   * checks and executes Stop Loss and Take Profit triggers.
   */
  public updateQuotes(quotes: Record<string, MarketQuote>, instruments: Record<string, Instrument>): {
    triggeredEvents: string[];
  } {
    const triggeredEvents: string[] = [];
    const openPos = this.getOpenPositions();

    for (const pos of openPos) {
      const quote = quotes[pos.symbol];
      const inst = instruments[pos.symbol];
      if (!quote || quote.isStale || !inst) continue;

      // Mark current price
      const markPrice = pos.side === 'BUY' ? quote.bid : quote.ask;
      pos.currentPrice = markPrice;

      // Unrealized P&L
      const grossUnrealized = pos.side === 'BUY'
        ? (markPrice - pos.entryPrice) * pos.quantity
        : (pos.entryPrice - markPrice) * pos.quantity;
      pos.unrealizedPnL = Number(grossUnrealized.toFixed(2));

      // Check Stop-Loss
      if (pos.stopLoss !== undefined && pos.stopLoss > 0) {
        const slHit = pos.side === 'BUY' ? quote.low24h <= pos.stopLoss || markPrice <= pos.stopLoss : quote.high24h >= pos.stopLoss || markPrice >= pos.stopLoss;
        if (slHit) {
          const res = this.closePosition(pos.id, quote, inst, 'STOP_LOSS');
          triggeredEvents.push(`[SL TRIGGERED] ${pos.symbol} closed at Stop Loss ($${pos.stopLoss})`);
          continue;
        }
      }

      // Check Take-Profit
      if (pos.takeProfit !== undefined && pos.takeProfit > 0) {
        const tpHit = pos.side === 'BUY' ? quote.high24h >= pos.takeProfit || markPrice >= pos.takeProfit : quote.low24h <= pos.takeProfit || markPrice <= pos.takeProfit;
        if (tpHit) {
          const res = this.closePosition(pos.id, quote, inst, 'TAKE_PROFIT');
          triggeredEvents.push(`[TP TRIGGERED] ${pos.symbol} closed at Take Profit ($${pos.takeProfit})`);
          continue;
        }
      }
    }

    this.recalculateAccount();
    return { triggeredEvents };
  }

  /**
   * Recalculate margins, equity, and margin levels
   */
  private recalculateAccount(): void {
    const openPos = this.getOpenPositions();
    const totalUnrealized = openPos.reduce((sum, p) => sum + p.unrealizedPnL, 0);
    const totalUsedMargin = openPos.reduce((sum, p) => sum + p.margin, 0);

    this.account.totalUnrealizedPnL = Number(totalUnrealized.toFixed(2));
    this.account.usedMargin = Number(totalUsedMargin.toFixed(2));
    this.account.virtualEquity = Number((this.account.virtualBalance + totalUnrealized).toFixed(2));
    this.account.freeMargin = Number(Math.max(0, this.account.virtualEquity - this.account.usedMargin).toFixed(2));

    if (this.account.usedMargin > 0) {
      this.account.marginLevel = Number(((this.account.virtualEquity / this.account.usedMargin) * 100).toFixed(1));
    } else {
      this.account.marginLevel = 999.0;
    }
    this.account.updatedAt = Date.now();
  }
}
