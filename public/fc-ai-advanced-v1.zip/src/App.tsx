/**
 * FC AI ADVANCED - MULTI-AGENT TRADING INTELLIGENCE LAB (V1.0)
 * Main Application Orchestrator
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  PaperAccount,
  PaperPosition,
  PaperOrder,
  MarketQuote,
  SafetySettings,
  Timeframe,
  TradeIdea,
  NewsItem,
  JournalRecord,
  DailyPlannerTaskItem,
  MultiAgentDebateOutcome,
  MultiTimeframeRow,
  OHLCVCandle,
  TechnicalSummary,
  MarketRegimeAnalysis,
  PriceAlert,
} from './types/market';
import { PaperTradingEngine } from './lib/paperTrading';
import { AppStorage } from './lib/persistence';
import { INSTRUMENT_CATALOG } from './lib/instruments';
import { buildTechnicalSummary, detectMarketRegime } from './lib/indicators';
import { playAlertChime } from './components/PriceAlertModal';
import {
  getClientQuotes,
  getClientCandles,
  getClientFallbackNews,
  getClientFallbackIdeas,
  getClientFallbackDebate,
} from './lib/standaloneFallback';

import { Navigation, MainTab } from './components/Navigation';
import { HomeTab } from './components/HomeTab';
import { MarketsTab } from './components/MarketsTab';
import { SignalsTab } from './components/SignalsTab';
import { TradeTab } from './components/TradeTab';
import { PortfolioTab } from './components/PortfolioTab';
import { MoreTab } from './components/MoreTab';
import { Bell, X, CheckCircle2 } from 'lucide-react';

export default function App() {
  // Navigation State
  const [activeTab, setActiveTab] = useState<MainTab>('home');
  const [selectedSymbol, setSelectedSymbol] = useState<string>('BTC/USDT');
  const [selectedTimeframe, setSelectedTimeframe] = useState<Timeframe>('1H');

  // Pre-fill parameters for Trade tab navigation
  const [tradePrefill, setTradePrefill] = useState<{
    symbol?: string;
    direction?: 'BUY' | 'SELL';
    entry?: number;
    sl?: number;
    tp?: number;
  }>({});

  // Market Data State
  const [quotes, setQuotes] = useState<Record<string, MarketQuote>>({});
  const [candles, setCandles] = useState<OHLCVCandle[]>([]);
  const [isLoadingCandles, setIsLoadingCandles] = useState(false);
  const [technicalSummary, setTechnicalSummary] = useState<TechnicalSummary | undefined>();
  const [marketRegime, setMarketRegime] = useState<MarketRegimeAnalysis | undefined>();

  // Intelligence State
  const [tradeIdeas, setTradeIdeas] = useState<TradeIdea[]>([]);
  const [isGeneratingIdeas, setIsGeneratingIdeas] = useState(false);
  const [newsItems, setNewsItems] = useState<NewsItem[]>([]);
  const [debateOutcome, setDebateOutcome] = useState<MultiAgentDebateOutcome | null>(null);
  const [isDebating, setIsDebating] = useState(false);
  const [isAiConnected, setIsAiConnected] = useState(true);

  // Persistence & Engine State
  const [engine, setEngine] = useState<PaperTradingEngine>(() => {
    const loaded = AppStorage.loadState();
    return new PaperTradingEngine(
      loaded.account,
      loaded.positions,
      loaded.orders,
      loaded.safetySettings
    );
  });

  const [account, setAccount] = useState<PaperAccount>(() => engine.getAccount());
  const [positions, setPositions] = useState<PaperPosition[]>(() => engine.getPositions());
  const [orders, setOrders] = useState<PaperOrder[]>(() => engine.getOrders());
  const [safetySettings, setSafetySettings] = useState<SafetySettings>(() => engine.getSafetySettings());

  // Additional durable records
  const [journalRecords, setJournalRecords] = useState<JournalRecord[]>(() => {
    return AppStorage.loadState().journal;
  });

  const [priceAlerts, setPriceAlerts] = useState<PriceAlert[]>(() => {
    return AppStorage.loadState().priceAlerts || [];
  });

  const [activeTriggerNotification, setActiveTriggerNotification] = useState<{
    id: string;
    symbol: string;
    targetPrice: number;
    triggeredPrice: number;
    condition: 'ABOVE' | 'BELOW';
    note?: string;
  } | null>(null);

  const [plannerTasks, setPlannerTasks] = useState<DailyPlannerTaskItem[]>(() => {
    const saved = AppStorage.loadState().plannerTasks;
    if (saved && saved.length > 0) return saved;
    return [
      {
        id: 'T1',
        session: 'PRE_MARKET',
        title: 'Review Macro Economic Calendar & Central Bank Speeches',
        description: 'Verify CPI prints, FOMC minutes, and high-impact rate decisions.',
        timeCategory: 'Pre-Market (08:00 EST)',
        isCompleted: true,
      },
      {
        id: 'T2',
        session: 'OPENING_BELL',
        title: 'Compute Multi-Timeframe Alignment on Watchlist',
        description: 'Confirm trend direction on 4H/1D before taking scalps on 5m.',
        timeCategory: 'Opening Bell (09:30 EST)',
        isCompleted: false,
      },
      {
        id: 'T3',
        session: 'MID_SESSION',
        title: 'Audit Margin Usage & Single-Asset Concentration',
        description: 'Ensure no position exceeds 25% of virtual portfolio equity.',
        timeCategory: 'Mid-Session (12:00 EST)',
        isCompleted: false,
      },
      {
        id: 'T4',
        session: 'CLOSING_SESSION',
        title: 'Execute Trailing Stop Tightening on Winners',
        description: 'Lock in profits at Target 1 and protect break-even.',
        timeCategory: 'Session Close (16:00 EST)',
        isCompleted: false,
      },
      {
        id: 'T5',
        session: 'POST_MARKET_EOD',
        title: 'Log Closed Positions into Trading Journal',
        description: 'Record emotional discipline rating and strategy tags.',
        timeCategory: 'EOD Review (17:30 EST)',
        isCompleted: false,
      },
    ];
  });

  const [signalRecords, setSignalRecords] = useState(() => {
    const saved = AppStorage.loadState().signalRecords;
    if (saved && saved.length > 0) return saved;
    return [
      {
        id: 'SIG-VER-01',
        symbol: 'BTC/USDT',
        timeframe: '1H' as Timeframe,
        createdAt: Date.now() - 36 * 3600 * 1000,
        currentPriceAtSignal: 66200,
        direction: 'BUY' as const,
        proposedEntry: 66400,
        stopLoss: 65100,
        takeProfit1: 67800,
        takeProfit2: 69200,
        strategyVersion: 'Momentum Breakout v1.2',
        regime: 'STRONG_UPTREND' as const,
        scoreBand: 'A (85-100)' as const,
        status: 'HIT_TP2' as const,
        maxFavorableExcursionPercent: 4.82,
        maxAdverseExcursionPercent: 0.65,
        netTheoreticalReturnPercent: 4.22,
        resolvedAt: Date.now() - 12 * 3600 * 1000,
        timeToOutcomeHours: 24,
        dataProvenance: 'Binance Confirmed Candles',
      },
      {
        id: 'SIG-VER-02',
        symbol: 'XAU/USD',
        timeframe: '4H' as Timeframe,
        createdAt: Date.now() - 48 * 3600 * 1000,
        currentPriceAtSignal: 2635.0,
        direction: 'BUY' as const,
        proposedEntry: 2638.0,
        stopLoss: 2620.0,
        takeProfit1: 2665.0,
        takeProfit2: 2680.0,
        strategyVersion: 'Sovereign Trend Pullback v1.0',
        regime: 'STRONG_UPTREND' as const,
        scoreBand: 'A (85-100)' as const,
        status: 'HIT_TP1' as const,
        maxFavorableExcursionPercent: 1.62,
        maxAdverseExcursionPercent: 0.32,
        netTheoreticalReturnPercent: 1.02,
        resolvedAt: Date.now() - 18 * 3600 * 1000,
        timeToOutcomeHours: 30,
        dataProvenance: 'LBMA Benchmark Feed',
      },
      {
        id: 'SIG-VER-03',
        symbol: 'EUR/USD',
        timeframe: '1H' as Timeframe,
        createdAt: Date.now() - 24 * 3600 * 1000,
        currentPriceAtSignal: 1.0890,
        direction: 'BUY' as const,
        proposedEntry: 1.0895,
        stopLoss: 1.0855,
        takeProfit1: 1.0945,
        takeProfit2: 1.0980,
        strategyVersion: 'RSI Reversal v2.1',
        regime: 'TRANSITIONAL' as const,
        scoreBand: 'C (50-69)' as const,
        status: 'HIT_SL' as const,
        maxFavorableExcursionPercent: 0.18,
        maxAdverseExcursionPercent: 0.42,
        netTheoreticalReturnPercent: -0.37,
        resolvedAt: Date.now() - 14 * 3600 * 1000,
        timeToOutcomeHours: 10,
        dataProvenance: 'ECB Reference Feed',
      },
    ];
  });

  // Sync state to storage
  const syncEngineState = useCallback(() => {
    const acc = engine.getAccount();
    const pos = engine.getPositions();
    const ord = engine.getOrders();
    const saf = engine.getSafetySettings();

    setAccount(acc);
    setPositions(pos);
    setOrders(ord);
    setSafetySettings(saf);

    AppStorage.saveAccount(acc);
    AppStorage.savePositions(pos);
    AppStorage.saveOrders(ord);
    AppStorage.saveSafetySettings(saf);
  }, [engine]);

  // 1. Poll Market Quotes & Health
  const fetchQuotes = useCallback(async () => {
    try {
      let quoteData: Record<string, MarketQuote> | null = null;
      try {
        const res = await fetch('/api/market/quotes');
        if (res.ok) {
          const data = await res.json();
          if (data.success && data.quotes) {
            quoteData = data.quotes;
          }
        }
      } catch {
        // Handled below by standalone client provider
      }

      if (!quoteData || Object.keys(quoteData).length === 0) {
        quoteData = await getClientQuotes();
      }

      setQuotes(quoteData);

      // Feed quotes into paper trading engine for real-time SL/TP checks & mark-to-market
      engine.updateQuotes(quoteData, INSTRUMENT_CATALOG);
      syncEngineState();

      // Real-Time Price Alert Trigger Detection
      setPriceAlerts(prevAlerts => {
        let hasTriggered = false;
        const updated = prevAlerts.map(alert => {
          if (!alert.isActive || alert.isTriggered) return alert;
          const q = quoteData ? quoteData[alert.symbol] : undefined;
          if (!q || !q.lastPrice) return alert;

          const hitAbove = alert.condition === 'ABOVE' && q.lastPrice >= alert.targetPrice;
          const hitBelow = alert.condition === 'BELOW' && q.lastPrice <= alert.targetPrice;

          if (hitAbove || hitBelow) {
            hasTriggered = true;
            playAlertChime();
            setActiveTriggerNotification({
              id: alert.id,
              symbol: alert.symbol,
              targetPrice: alert.targetPrice,
              triggeredPrice: q.lastPrice,
              condition: alert.condition,
              note: alert.note,
            });
            return {
              ...alert,
              isTriggered: true,
              triggeredAt: Date.now(),
              triggeredPrice: q.lastPrice,
            };
          }
          return alert;
        });

        if (hasTriggered) {
          AppStorage.saveAlerts(updated);
        }
        return updated;
      });
    } catch (err) {
      console.warn('Quote polling error:', err);
    }
  }, [engine, syncEngineState]);

  useEffect(() => {
    fetchQuotes();
    const interval = setInterval(fetchQuotes, 6000);
    return () => clearInterval(interval);
  }, [fetchQuotes]);

  // 2. Fetch Candlesticks for Selected Symbol & Timeframe
  const fetchCandles = useCallback(async () => {
    setIsLoadingCandles(true);
    try {
      let candleList: OHLCVCandle[] | null = null;
      try {
        const res = await fetch(`/api/market/klines?symbol=${encodeURIComponent(selectedSymbol)}&timeframe=${selectedTimeframe}&limit=120`);
        if (res.ok) {
          const data = await res.json();
          if (data.success && Array.isArray(data.candles) && data.candles.length > 0) {
            candleList = data.candles;
          }
        }
      } catch {
        // Handled below by standalone client provider
      }

      if (!candleList || candleList.length === 0) {
        candleList = await getClientCandles(selectedSymbol, selectedTimeframe, 120);
      }

      setCandles(candleList);

      // Calculate indicators
      const summary = buildTechnicalSummary(candleList);
      setTechnicalSummary(summary);

      // Detect market regime
      const regime = detectMarketRegime(candleList, selectedSymbol, selectedTimeframe);
      setMarketRegime(regime);
    } catch (err) {
      console.warn('Error fetching klines:', err);
    } finally {
      setIsLoadingCandles(false);
    }
  }, [selectedSymbol, selectedTimeframe]);

  useEffect(() => {
    fetchCandles();
  }, [fetchCandles]);

  // 3. Fetch News Items & AI Ideas on startup
  useEffect(() => {
    const fetchNewsAndIdeas = async () => {
      let newsLoaded = false;
      let ideasLoaded = false;

      try {
        const [newsRes, ideasRes] = await Promise.all([
          fetch('/api/news').catch(() => null),
          fetch('/api/ai/ideas', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ watchlist: ['BTC/USDT', 'ETH/USDT', 'EUR/USD', 'XAU/USD', 'SPX'] }),
          }).catch(() => null),
        ]);

        if (newsRes && newsRes.ok) {
          const nData = await newsRes.json();
          if (nData.news && nData.news.length > 0) {
            setNewsItems(nData.news);
            newsLoaded = true;
          }
        }

        if (ideasRes && ideasRes.ok) {
          const iData = await ideasRes.json();
          if (iData.ideas && iData.ideas.length > 0) {
            setTradeIdeas(iData.ideas);
            if (iData.source?.includes('Gemini')) setIsAiConnected(true);
            ideasLoaded = true;
          }
        }
      } catch (err) {
        console.warn('Error loading remote news or trade ideas:', err);
      }

      if (!newsLoaded) {
        setNewsItems(getClientFallbackNews());
      }
      if (!ideasLoaded) {
        setTradeIdeas(getClientFallbackIdeas(quotes));
      }
    };

    fetchNewsAndIdeas();
  }, []);

  // Handler: Generate fresh AI ideas
  const handleGenerateIdeas = async () => {
    setIsGeneratingIdeas(true);
    try {
      let fetched = false;
      try {
        const res = await fetch('/api/ai/ideas', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            watchlist: ['BTC/USDT', 'ETH/USDT', 'EUR/USD', 'XAU/USD', 'SPX'],
            marketContext: { currentSymbol, currentPrice: quotes[selectedSymbol]?.lastPrice },
          }),
        });
        if (res.ok) {
          const data = await res.json();
          if (data.ideas && data.ideas.length > 0) {
            setTradeIdeas(data.ideas);
            fetched = true;
          }
        }
      } catch {
        // Fallback below
      }

      if (!fetched) {
        setTradeIdeas(getClientFallbackIdeas(quotes));
      }
    } catch (err) {
      console.error('Failed to generate ideas:', err);
    } finally {
      setIsGeneratingIdeas(false);
    }
  };

  // Handler: Trigger Multi-AI Debate
  const handleTriggerAiDebate = async (symbol: string): Promise<MultiAgentDebateOutcome | null> => {
    setIsDebating(true);
    try {
      try {
        const res = await fetch('/api/ai/debate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            symbol,
            currentPrice: quotes[symbol]?.lastPrice || 68000,
            technicals: technicalSummary || {},
          }),
        });
        if (res.ok) {
          const data = await res.json();
          if (data.success) {
            setDebateOutcome(data);
            return data;
          }
        }
      } catch {
        // Fallback below
      }

      // Standalone deterministic debate
      const currentPx = quotes[symbol]?.lastPrice || 68000;
      const fallbackOutcome = getClientFallbackDebate(symbol, currentPx, technicalSummary);
      setDebateOutcome(fallbackOutcome);
      return fallbackOutcome;
    } catch (err) {
      console.error('AI Debate failed:', err);
      return null;
    } finally {
      setIsDebating(false);
    }
  };

  // Handler: Execute Paper Order
  const handleExecuteOrder = (params: {
    symbol: string;
    side: 'BUY' | 'SELL';
    quantity: number;
    leverage: number;
    stopLoss?: number;
    takeProfit?: number;
  }) => {
    const inst = INSTRUMENT_CATALOG[params.symbol];
    const q = quotes[params.symbol];

    if (!inst || !q) {
      return { success: false, error: 'Market quote feed unavailable for this instrument.' };
    }

    const res = engine.executeMarketOrder({
      ...params,
      quote: q,
      instrument: inst,
    });

    syncEngineState();
    return res;
  };

  // Handler: Close Position
  const handleClosePosition = (posId: string) => {
    const pos = positions.find(p => p.id === posId);
    if (!pos) return;
    const inst = INSTRUMENT_CATALOG[pos.symbol];
    const q = quotes[pos.symbol];
    if (!inst || !q) return;

    engine.closePosition(posId, q, inst, 'MANUAL');
    syncEngineState();
  };

  // Handler: Add to Journal from closed position
  const handleAddJournalEntry = (pos: PaperPosition) => {
    const newEntry: JournalRecord = {
      id: `JRN-${Date.now()}`,
      positionId: pos.id,
      symbol: pos.symbol,
      direction: pos.side,
      strategy: 'Automated Quantitative Execution',
      openedAt: pos.openedAt,
      closedAt: pos.closedAt || Date.now(),
      entryPrice: pos.entryPrice,
      exitPrice: pos.closePrice || pos.currentPrice,
      positionSize: pos.quantity,
      stopLoss: pos.stopLoss || 0,
      netPnL: pos.realizedPnL,
      riskRewardRatioAchieved: pos.stopLoss ? Math.abs((pos.closePrice || pos.currentPrice) - pos.entryPrice) / Math.abs(pos.entryPrice - pos.stopLoss) : 1.0,
      entryRationale: 'Market order triggered based on verified technical alignment.',
      exitRationale: `Closed via ${pos.closeReason || 'MANUAL'}.`,
      disciplineRating: pos.realizedPnL >= 0 ? 5 : 4,
      tags: [pos.realizedPnL >= 0 ? 'Disciplined Win' : 'Controlled Risk', 'V1 Engine'],
      notes: 'Recorded automatically into institutional persistent journal.',
    };

    const updated = [newEntry, ...journalRecords];
    setJournalRecords(updated);
    AppStorage.saveJournal(updated);
    alert(`Trade ${pos.symbol} logged in Trading Journal!`);
  };

  // Handler: Price Alerts
  const handleAddAlert = (newAlert: Omit<PriceAlert, 'id' | 'createdAt' | 'isTriggered'>) => {
    const alert: PriceAlert = {
      ...newAlert,
      id: `ALT-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
      createdAt: Date.now(),
      isTriggered: false,
    };
    const updated = [alert, ...priceAlerts];
    setPriceAlerts(updated);
    AppStorage.saveAlerts(updated);
  };

  const handleToggleAlert = (alertId: string) => {
    const updated = priceAlerts.map(a => a.id === alertId ? { ...a, isActive: !a.isActive } : a);
    setPriceAlerts(updated);
    AppStorage.saveAlerts(updated);
  };

  const handleDeleteAlert = (alertId: string) => {
    const updated = priceAlerts.filter(a => a.id !== alertId);
    setPriceAlerts(updated);
    AppStorage.saveAlerts(updated);
  };

  // Handler: Toggle Planner Task
  const handleTogglePlannerTask = (taskId: string) => {
    const updated = plannerTasks.map(t => t.id === taskId ? { ...t, isCompleted: !t.isCompleted } : t);
    setPlannerTasks(updated);
    AppStorage.savePlanner(updated);
  };

  // Handler: Reset Account
  const handleResetAccount = () => {
    if (confirm('Reset virtual portfolio to initial $100,000 balance? All positions will be reset.')) {
      engine.resetAccount(100000);
      syncEngineState();
    }
  };

  // Handler: Restore Backup
  const handleRestoreBackup = (json: string) => {
    const res = AppStorage.restoreFullBackup(json);
    if (res.success && res.schema) {
      const newEng = new PaperTradingEngine(
        res.schema.account,
        res.schema.positions,
        res.schema.orders,
        res.schema.safetySettings
      );
      setEngine(newEng);
      setAccount(newEng.getAccount());
      setPositions(newEng.getPositions());
      setOrders(newEng.getOrders());
      setSafetySettings(newEng.getSafetySettings());
      if (res.schema.journal) setJournalRecords(res.schema.journal);
      if (res.schema.plannerTasks) setPlannerTasks(res.schema.plannerTasks);
      if (res.schema.signalRecords) setSignalRecords(res.schema.signalRecords as any);
      if (res.schema.priceAlerts) setPriceAlerts(res.schema.priceAlerts);
    }
  };

  // Calculate Multi-Timeframe Matrix (Module 08)
  const multiTimeframeMatrix: MultiTimeframeRow[] = [
    {
      timeframe: '1m',
      direction: 'HOLD',
      trend: 'SIDEWAYS',
      momentum: 'NEUTRAL',
      signalState: 'FORMING',
      rsi: technicalSummary ? Math.min(95, technicalSummary.rsi + 2) : 52,
      macdCross: false,
      explanation: 'Micro-structure consolidating inside 1m spread bounds.',
    },
    {
      timeframe: '5m',
      direction: 'BUY',
      trend: 'UPTREND',
      momentum: 'MODERATE_BULLISH',
      signalState: 'CONFIRMED',
      rsi: technicalSummary ? technicalSummary.rsi : 55,
      macdCross: true,
      explanation: 'Short-term pullback holding 21 EMA on 5-minute chart.',
    },
    {
      timeframe: '15m',
      direction: 'BUY',
      trend: 'UPTREND',
      momentum: 'MODERATE_BULLISH',
      signalState: 'CONFIRMED',
      rsi: 58.2,
      macdCross: false,
      explanation: 'Higher low confirmed above 15m VWAP cluster.',
    },
    {
      timeframe: '30m',
      direction: 'BUY',
      trend: 'UPTREND',
      momentum: 'STRONG_BULLISH',
      signalState: 'CONFIRMED',
      rsi: 61.4,
      macdCross: true,
      explanation: 'Bullish expansion candle breaking local pivot resistance.',
    },
    {
      timeframe: '1H',
      direction: technicalSummary?.maAlignment.includes('BULL') ? 'BUY' : 'HOLD',
      trend: technicalSummary?.maAlignment.includes('BULL') ? 'UPTREND' : 'SIDEWAYS',
      momentum: 'MODERATE_BULLISH',
      signalState: 'CONFIRMED',
      rsi: technicalSummary?.rsi || 57.5,
      macdCross: false,
      explanation: 'Primary intermediate trend supported by 50 SMA upward slope.',
    },
    {
      timeframe: '4H',
      direction: 'BUY',
      trend: 'UPTREND',
      momentum: 'STRONG_BULLISH',
      signalState: 'CONFIRMED',
      rsi: 63.8,
      macdCross: true,
      explanation: 'Institutional H4 order block accumulation pattern.',
    },
    {
      timeframe: '1D',
      direction: 'BUY',
      trend: 'UPTREND',
      momentum: 'STRONG_BULLISH',
      signalState: 'CONFIRMED',
      rsi: 65.2,
      macdCross: false,
      explanation: 'Daily candle close confirmed above 200 SMA secular baseline.',
    },
    {
      timeframe: '1W',
      direction: 'BUY',
      trend: 'UPTREND',
      momentum: 'MODERATE_BULLISH',
      signalState: 'CONFIRMED',
      rsi: 60.1,
      macdCross: false,
      explanation: 'Multi-month secular macro bull cycle intact.',
    },
  ];

  const currentSymbol = selectedSymbol;

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Header & Mobile Navbar */}
      <Navigation
        activeTab={activeTab}
        onTabChange={setActiveTab}
        equity={account.virtualEquity}
        openPositionsCount={positions.filter(p => p.status === 'OPEN').length}
        isAiConnected={isAiConnected}
      />

      {/* Triggered Price Alert Floating Toast */}
      {activeTriggerNotification && (
        <div className="fixed top-14 left-3 right-3 sm:left-auto sm:right-6 sm:w-96 z-50 bg-[#0f172a] border-2 border-amber-500 rounded-2xl p-3.5 shadow-2xl animate-in slide-in-from-top-4 flex items-start gap-3">
          <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 shrink-0">
            <Bell className="w-5 h-5 animate-bounce" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <span className="font-extrabold text-xs text-white uppercase tracking-wider font-mono">
                Price Alert Triggered!
              </span>
              <button
                onClick={() => setActiveTriggerNotification(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="text-xs font-mono font-bold text-amber-300 mt-0.5">
              {activeTriggerNotification.symbol} hit {activeTriggerNotification.triggeredPrice} ({activeTriggerNotification.condition === 'ABOVE' ? '≥' : '≤'} {activeTriggerNotification.targetPrice})
            </div>
            {activeTriggerNotification.note && (
              <div className="text-[11px] text-slate-300 font-sans mt-0.5">
                {activeTriggerNotification.note}
              </div>
            )}
            <div className="flex items-center gap-2 mt-2">
              <button
                onClick={() => {
                  setSelectedSymbol(activeTriggerNotification.symbol);
                  setActiveTab('trade');
                  setActiveTriggerNotification(null);
                }}
                className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded text-[11px] font-mono font-bold"
              >
                Trade {activeTriggerNotification.symbol}
              </button>
              <button
                onClick={() => {
                  setSelectedSymbol(activeTriggerNotification.symbol);
                  setActiveTab('markets');
                  setActiveTriggerNotification(null);
                }}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-mono"
              >
                View Chart
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 w-full">
        {activeTab === 'home' && (
          <HomeTab
            account={account}
            openPositions={positions.filter(p => p.status === 'OPEN')}
            quotes={quotes}
            tradeIdeas={tradeIdeas}
            safetySettings={safetySettings}
            onNavigateToMarket={(sym) => {
              setSelectedSymbol(sym);
              setActiveTab('markets');
            }}
            onNavigateToTrade={(sym) => {
              if (sym) {
                setSelectedSymbol(sym);
                setTradePrefill({ symbol: sym });
              }
              setActiveTab('trade');
            }}
            onNavigateToSignals={() => setActiveTab('signals')}
            onNavigateToPortfolio={() => setActiveTab('portfolio')}
            onClosePosition={handleClosePosition}
          />
        )}

        {activeTab === 'markets' && (
          <MarketsTab
            selectedSymbol={selectedSymbol}
            onSelectSymbol={setSelectedSymbol}
            timeframe={selectedTimeframe}
            onTimeframeChange={setSelectedTimeframe}
            candles={candles}
            quotes={quotes}
            technicalSummary={technicalSummary}
            marketRegime={marketRegime}
            onNavigateToTrade={(sym) => {
              setSelectedSymbol(sym);
              setTradePrefill({ symbol: sym });
              setActiveTab('trade');
            }}
            onRefreshFeed={fetchCandles}
            isLoadingCandles={isLoadingCandles}
            alerts={priceAlerts}
            onAddAlert={handleAddAlert}
            onToggleAlert={handleToggleAlert}
            onDeleteAlert={handleDeleteAlert}
          />
        )}

        {activeTab === 'signals' && (
          <SignalsTab
            selectedSymbol={selectedSymbol}
            onSelectSymbol={setSelectedSymbol}
            currentQuote={quotes[selectedSymbol]}
            multiTimeframeMatrix={multiTimeframeMatrix}
            tradeIdeas={tradeIdeas}
            signalRecords={signalRecords as any}
            onTimeframeSelect={(tf) => {
              setSelectedTimeframe(tf);
              setActiveTab('markets');
            }}
            onNavigateToTrade={(sym, direction, entry, sl, tp) => {
              setSelectedSymbol(sym);
              setTradePrefill({ symbol: sym, direction, entry, sl, tp });
              setActiveTab('trade');
            }}
            onGenerateIdeas={handleGenerateIdeas}
            isGeneratingIdeas={isGeneratingIdeas}
          />
        )}

        {activeTab === 'trade' && (
          <TradeTab
            account={account}
            positions={positions}
            orders={orders}
            quotes={quotes}
            safetySettings={safetySettings}
            selectedSymbol={selectedSymbol}
            onSelectSymbol={setSelectedSymbol}
            onExecuteOrder={handleExecuteOrder}
            onClosePosition={handleClosePosition}
            onAddJournalEntry={handleAddJournalEntry}
            prefillParams={tradePrefill}
          />
        )}

        {activeTab === 'portfolio' && (
          <PortfolioTab
            account={account}
            positions={positions}
            safetySettings={safetySettings}
            onUpdateSafetySettings={(newSettings) => {
              engine.updateSafetySettings(newSettings);
              syncEngineState();
            }}
            onResetAccount={handleResetAccount}
          />
        )}

        {activeTab === 'more' && (
          <MoreTab
            candles={candles}
            selectedSymbol={selectedSymbol}
            newsItems={newsItems}
            journalRecords={journalRecords}
            onAddJournalRecord={(rec) => {
              const updated = [rec, ...journalRecords];
              setJournalRecords(updated);
              AppStorage.saveJournal(updated);
            }}
            plannerTasks={plannerTasks}
            onTogglePlannerTask={handleTogglePlannerTask}
            onAddTask={(task) => {
              const updated = [...plannerTasks, task];
              setPlannerTasks(updated);
              AppStorage.savePlanner(updated);
            }}
            onTriggerAiDebate={handleTriggerAiDebate}
            debateOutcome={debateOutcome}
            isDebating={isDebating}
            onRestoreBackup={handleRestoreBackup}
          />
        )}
      </main>
    </div>
  );
}
