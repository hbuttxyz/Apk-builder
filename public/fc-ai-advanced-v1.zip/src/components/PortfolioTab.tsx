/**
 * FC AI ADVANCED - PORTFOLIO RISK MANAGER (MODULE 05)
 * Capital Exposure, Asset Allocation, Multi-Asset Correlation Matrix,
 * 20% Black Swan Stress Testing, Hedging Alternatives, and Quantitative Sizing.
 */

import React, { useState } from 'react';
import {
  PaperAccount,
  PaperPosition,
  SafetySettings,
} from '../types/market';
import { INSTRUMENT_CATALOG } from '../lib/instruments';
import {
  calculatePortfolioRisk,
  calculatePositionSize,
  PositionSizeResult,
} from '../lib/riskEngine';
import {
  PieChart,
  ShieldAlert,
  AlertTriangle,
  Zap,
  TrendingDown,
  Calculator,
  RefreshCw,
  Scale,
  ShieldCheck,
  CheckCircle,
} from 'lucide-react';

interface PortfolioTabProps {
  account: PaperAccount;
  positions: PaperPosition[];
  safetySettings: SafetySettings;
  onUpdateSafetySettings: (settings: Partial<SafetySettings>) => void;
  onResetAccount: () => void;
}

export const PortfolioTab: React.FC<PortfolioTabProps> = ({
  account,
  positions,
  safetySettings,
  onUpdateSafetySettings,
  onResetAccount,
}) => {
  const [activeTab, setActiveTab] = useState<'RISK_AUDIT' | 'STRESS_TEST' | 'SIZING_CALC' | 'LIMITS'>('RISK_AUDIT');

  // Sizing Calculator inputs
  const [calcSymbol, setCalcSymbol] = useState('BTC/USDT');
  const [calcRiskPct, setCalcRiskPct] = useState(2.0);
  const [calcEntryPrice, setCalcEntryPrice] = useState(68000);
  const [calcStopPrice, setCalcStopPrice] = useState(66500);
  const [calcMethodology, setCalcMethodology] = useState<'FIXED_FRACTIONAL' | 'KELLY_CRITERION' | 'ATR_VOLATILITY'>('FIXED_FRACTIONAL');

  const riskReport = calculatePortfolioRisk(positions, account, INSTRUMENT_CATALOG);

  // Compute position size on the fly
  const inst = INSTRUMENT_CATALOG[calcSymbol] || INSTRUMENT_CATALOG['BTC/USDT'];
  const sizingResult: PositionSizeResult = calculatePositionSize({
    accountEquity: account.virtualEquity,
    entryPrice: calcEntryPrice,
    stopLossPrice: calcStopPrice,
    riskPercent: calcRiskPct,
    instrument: inst,
    methodology: calcMethodology,
  });

  return (
    <div className="flex flex-col gap-4 pb-20 pt-2 px-3 max-w-7xl mx-auto">
      {/* Sub Tabs */}
      <div className="flex items-center gap-1 bg-[#0f172a] p-1 rounded-xl border border-[#1e293b] text-xs font-mono">
        <button
          onClick={() => setActiveTab('RISK_AUDIT')}
          className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1 transition-all ${
            activeTab === 'RISK_AUDIT' ? 'bg-blue-600 text-white font-semibold shadow' : 'text-slate-400 hover:text-white'
          }`}
        >
          <PieChart className="w-3.5 h-3.5" />
          <span>Risk Audit</span>
        </button>
        <button
          onClick={() => setActiveTab('STRESS_TEST')}
          className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1 transition-all ${
            activeTab === 'STRESS_TEST' ? 'bg-blue-600 text-white font-semibold shadow' : 'text-slate-400 hover:text-white'
          }`}
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          <span>Stress Shock</span>
        </button>
        <button
          onClick={() => setActiveTab('SIZING_CALC')}
          className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1 transition-all ${
            activeTab === 'SIZING_CALC' ? 'bg-blue-600 text-white font-semibold shadow' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Calculator className="w-3.5 h-3.5" />
          <span>Position Sizer</span>
        </button>
        <button
          onClick={() => setActiveTab('LIMITS')}
          className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1 transition-all ${
            activeTab === 'LIMITS' ? 'bg-blue-600 text-white font-semibold shadow' : 'text-slate-400 hover:text-white'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>Safety Gates</span>
        </button>
      </div>

      {/* VIEW 1: RISK & ALLOCATION AUDIT */}
      {activeTab === 'RISK_AUDIT' && (
        <div className="flex flex-col gap-3">
          {/* Top Equity & Exposure Summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
            <div className="bg-[#0f172a] p-3 rounded-xl border border-[#1e293b]">
              <span className="text-slate-400 text-[10px] block">TOTAL VIRTUAL EQUITY</span>
              <span className="text-lg font-bold text-white font-mono-num">${riskReport.totalEquity.toLocaleString()}</span>
            </div>
            <div className="bg-[#0f172a] p-3 rounded-xl border border-[#1e293b]">
              <span className="text-slate-400 text-[10px] block">NOTIONAL EXPOSURE</span>
              <span className="text-lg font-bold text-blue-400 font-mono-num">${riskReport.totalExposure.toLocaleString()}</span>
            </div>
            <div className="bg-[#0f172a] p-3 rounded-xl border border-[#1e293b]">
              <span className="text-slate-400 text-[10px] block">PORTFOLIO LEVERAGE</span>
              <span className={`text-lg font-bold font-mono-num ${riskReport.portfolioLeverage > 5 ? 'text-amber-400' : 'text-emerald-400'}`}>
                {riskReport.portfolioLeverage.toFixed(1)}x
              </span>
            </div>
            <div className="bg-[#0f172a] p-3 rounded-xl border border-[#1e293b]">
              <span className="text-slate-400 text-[10px] block">MARGIN LEVEL</span>
              <span className={`text-lg font-bold font-mono-num ${riskReport.marginLevel < 150 ? 'text-red-400' : 'text-emerald-400'}`}>
                {riskReport.marginLevel.toFixed(0)}%
              </span>
            </div>
          </div>

          {/* Allocation & Concentration Slices */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Asset Class Allocation */}
            <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-3.5 flex flex-col gap-2">
              <span className="font-bold text-xs text-white font-mono">ASSET CLASS EXPOSURE</span>
              {riskReport.assetClassAllocation.length === 0 ? (
                <div className="text-xs text-slate-500 font-mono py-4 text-center">100% Liquid Virtual Cash Reserves</div>
              ) : (
                <div className="flex flex-col gap-1.5 pt-1">
                  {riskReport.assetClassAllocation.map(item => (
                    <div key={item.label} className="flex flex-col gap-0.5 text-xs font-mono">
                      <div className="flex justify-between text-slate-300">
                        <span className="uppercase font-semibold">{item.label}</span>
                        <span>${item.value.toLocaleString()} ({item.percentage}%)</span>
                      </div>
                      <div className="w-full bg-[#090d16] h-1.5 rounded-full overflow-hidden">
                        <div className="bg-blue-500 h-full rounded-full" style={{ width: `${Math.min(100, item.percentage)}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Position Concentration */}
            <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-3.5 flex flex-col gap-2">
              <span className="font-bold text-xs text-white font-mono">SINGLE-INSTRUMENT CONCENTRATION</span>
              {riskReport.positionConcentration.length === 0 ? (
                <div className="text-xs text-slate-500 font-mono py-4 text-center">No active positions to concentrate</div>
              ) : (
                <div className="flex flex-col gap-1.5 pt-1">
                  {riskReport.positionConcentration.map(item => {
                    const isExceeded = item.percentage > safetySettings.maxExposurePerInstrumentPercent;
                    return (
                      <div key={item.label} className="flex flex-col gap-0.5 text-xs font-mono">
                        <div className="flex justify-between">
                          <span className="font-bold text-white">{item.label}</span>
                          <span className={isExceeded ? 'text-red-400 font-bold' : 'text-slate-300'}>
                            {item.percentage}% {isExceeded ? '(!)' : ''}
                          </span>
                        </div>
                        <div className="w-full bg-[#090d16] h-1.5 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${isExceeded ? 'bg-red-500' : 'bg-emerald-500'}`}
                            style={{ width: `${Math.min(100, item.percentage)}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Correlation Matrix */}
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-3.5 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-white font-mono">MULTI-ASSET CORRELATION MATRIX</span>
              <span className="text-[10px] text-slate-500 font-mono">Portfolio Cross-Sensitivities</span>
            </div>

            {riskReport.correlationMatrix.symbols.length <= 1 ? (
              <div className="text-xs text-slate-500 font-mono py-4 text-center">
                Open 2 or more positions across different asset classes (e.g. BTC and Gold) to compute cross-correlation.
              </div>
            ) : (
              <div className="overflow-x-auto pt-1">
                <table className="w-full text-center text-xs font-mono">
                  <thead>
                    <tr className="text-slate-400 text-[10px]">
                      <th className="text-left py-1">Symbol</th>
                      {riskReport.correlationMatrix.symbols.map(s => (
                        <th key={s} className="py-1 px-2">{s}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1e293b]">
                    {riskReport.correlationMatrix.symbols.map((sym, i) => (
                      <tr key={sym}>
                        <td className="text-left font-bold text-white py-2">{sym}</td>
                        {riskReport.correlationMatrix.matrix[i].map((corr, j) => {
                          const isHigh = Math.abs(corr) > 0.7;
                          const isHedge = corr < 0;
                          return (
                            <td key={j} className="py-2 px-2">
                              <span className={`px-2 py-0.5 rounded font-mono-num font-bold ${
                                isHigh ? 'bg-red-500/20 text-red-400' : isHedge ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-300'
                              }`}>
                                {corr > 0 ? '+' : ''}{corr.toFixed(2)}
                              </span>
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* VIEW 2: 20% BLACK SWAN STRESS SHOCK */}
      {activeTab === 'STRESS_TEST' && (
        <div className="flex flex-col gap-3">
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-4 flex flex-col gap-2">
            <h3 className="font-bold text-sm text-white">Configurable Macro Downturn Scenarios</h3>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              Applies differentiated shocks across your active positions rather than assuming all assets collapse by the exact same magnitude. Crypto carries high beta (-35%), equities absorb -20%, and Gold serves as a safe-haven flight asset (+8%).
            </p>
          </div>

          <div className="flex flex-col gap-2.5">
            {riskReport.stressScenarios.map((sc, idx) => (
              <div
                key={sc.scenarioName}
                className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-3.5 flex flex-col gap-2 shadow-md"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-white">{sc.scenarioName}</span>
                    {sc.marginCallRisk && (
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/30">
                        MARGIN CALL WARNING
                      </span>
                    )}
                  </div>
                  <span className={`font-mono-num font-extrabold text-sm ${sc.simulatedPnLImpact >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {sc.simulatedPnLImpact >= 0 ? '+' : ''}${sc.simulatedPnLImpact.toFixed(2)}
                  </span>
                </div>

                <p className="text-xs text-slate-400 font-sans">
                  {sc.description}
                </p>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-[#090d16] p-2 rounded-lg">
                  <div>
                    <span className="text-slate-500 text-[10px] block">SIMULATED EQUITY</span>
                    <span className="text-white font-bold font-mono-num">${sc.simulatedEquity.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[10px] block">SIMULATED DRAWDOWN</span>
                    <span className="text-red-400 font-bold font-mono-num">{sc.simulatedDrawdownPercent}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Hedging Alternatives */}
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-3.5 flex flex-col gap-2">
            <span className="font-bold text-xs text-white font-mono">PROPOSED HEDGING STRATEGIES</span>
            <div className="flex flex-col gap-2 pt-1">
              {riskReport.hedgingAlternatives.map(h => (
                <div key={h.hedgeStrategy} className="bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b] text-xs flex flex-col gap-1 font-mono">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-blue-400">{h.hedgeStrategy}</span>
                    <span className="text-[10px] text-slate-400">{h.estimatedCost}</span>
                  </div>
                  <p className="text-slate-300 font-sans text-xs">{h.rationale}</p>
                  <span className="text-[10px] text-amber-400/90 font-sans">Limit: {h.limitations}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* VIEW 3: QUANTITATIVE POSITION SIZING CALCULATOR */}
      {activeTab === 'SIZING_CALC' && (
        <div className="flex flex-col gap-3">
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-4 flex flex-col gap-3">
            <h3 className="font-bold text-sm text-white font-mono">Institutional Sizing Models</h3>

            {/* Methodology Picker */}
            <div className="flex items-center gap-1 bg-[#090d16] p-1 rounded-lg border border-[#1e293b] text-xs font-mono">
              {(['FIXED_FRACTIONAL', 'KELLY_CRITERION', 'ATR_VOLATILITY'] as const).map(m => (
                <button
                  key={m}
                  onClick={() => setCalcMethodology(m)}
                  className={`flex-1 py-1.5 rounded text-[11px] font-semibold transition-all ${
                    calcMethodology === m ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {m === 'FIXED_FRACTIONAL' ? 'Fixed Fractional' : m === 'KELLY_CRITERION' ? 'Half-Kelly' : 'ATR Volatility'}
                </button>
              ))}
            </div>

            {/* Inputs Grid */}
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <div className="flex flex-col gap-1">
                <span className="text-slate-400 text-[10px]">Instrument</span>
                <select
                  value={calcSymbol}
                  onChange={(e) => setCalcSymbol(e.target.value)}
                  className="bg-[#090d16] border border-[#1e293b] rounded p-2 text-white font-bold"
                >
                  {Object.keys(INSTRUMENT_CATALOG).map(sym => (
                    <option key={sym} value={sym}>{sym}</option>
                  ))}
                </select>
              </div>

              <div className="flex flex-col gap-1">
                <span className="text-slate-400 text-[10px]">Risk % per Trade</span>
                <input
                  type="number"
                  step="0.1"
                  value={calcRiskPct}
                  onChange={(e) => setCalcRiskPct(parseFloat(e.target.value) || 1)}
                  className="bg-[#090d16] border border-[#1e293b] rounded p-2 text-white font-bold"
                />
              </div>

              <div className="flex flex-col gap-1">
                <span className="text-slate-400 text-[10px]">Planned Entry Price</span>
                <input
                  type="number"
                  step="any"
                  value={calcEntryPrice}
                  onChange={(e) => setCalcEntryPrice(parseFloat(e.target.value) || 1)}
                  className="bg-[#090d16] border border-[#1e293b] rounded p-2 text-white font-bold"
                />
              </div>

              <div className="flex flex-col gap-1">
                <span className="text-slate-400 text-[10px]">Planned Stop Loss</span>
                <input
                  type="number"
                  step="any"
                  value={calcStopPrice}
                  onChange={(e) => setCalcStopPrice(parseFloat(e.target.value) || 1)}
                  className="bg-[#090d16] border border-[#1e293b] rounded p-2 text-white font-bold"
                />
              </div>
            </div>

            {/* Output Calculation Card */}
            <div className="bg-[#090d16] border border-[#1e293b] rounded-xl p-3 flex flex-col gap-2 font-mono text-xs">
              <span className="text-[10px] text-slate-500 uppercase font-bold">Recommended Position Sizing Output</span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                <div>
                  <span className="text-slate-500 text-[10px] block">RECOMMENDED QTY</span>
                  <span className="text-emerald-400 text-base font-extrabold">{sizingResult.recommendedQuantity}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] block">MAX DOLLAR LOSS</span>
                  <span className="text-red-400 text-base font-bold font-mono-num">${sizingResult.maxAllowableLoss.toFixed(2)}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] block">REQUIRED MARGIN</span>
                  <span className="text-blue-400 text-base font-bold font-mono-num">${sizingResult.requiredMargin.toFixed(2)}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] block">EFFECTIVE LEVERAGE</span>
                  <span className="text-white text-base font-bold font-mono-num">{sizingResult.effectiveLeverage.toFixed(2)}x</span>
                </div>
              </div>

              <p className="text-slate-400 text-xs font-sans mt-1 pt-1 border-t border-[#1e293b]">
                {sizingResult.methodologyNotes}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 4: SAFETY GATES & LIMITS */}
      {activeTab === 'LIMITS' && (
        <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-4 flex flex-col gap-3 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
            <span className="font-bold text-sm text-white">SAFETY & EXECUTION POLICY CONTROLS</span>
            <button
              onClick={onResetAccount}
              className="text-red-400 hover:text-red-300 text-[11px] font-semibold"
            >
              Reset Virtual Account
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div className="flex flex-col gap-1">
              <span className="text-slate-400 text-[10px]">MAX RISK PER TRADE (% OF EQUITY)</span>
              <input
                type="number"
                step="0.5"
                min="0.5"
                max="10"
                value={safetySettings.maxRiskPerTradePercent}
                onChange={(e) => onUpdateSafetySettings({ maxRiskPerTradePercent: parseFloat(e.target.value) || 2 })}
                className="bg-[#090d16] border border-[#1e293b] rounded p-2 text-white font-bold"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-slate-400 text-[10px]">MAX DAILY SIMULATED LOSS ($)</span>
              <input
                type="number"
                step="500"
                value={safetySettings.maxDailySimulatedLoss}
                onChange={(e) => onUpdateSafetySettings({ maxDailySimulatedLoss: parseFloat(e.target.value) || 2500 })}
                className="bg-[#090d16] border border-[#1e293b] rounded p-2 text-white font-bold"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-slate-400 text-[10px]">MAX OPEN POSITIONS CONCURRENTLY</span>
              <input
                type="number"
                min="1"
                max="20"
                value={safetySettings.maxOpenPositions}
                onChange={(e) => onUpdateSafetySettings({ maxOpenPositions: parseInt(e.target.value, 10) || 5 })}
                className="bg-[#090d16] border border-[#1e293b] rounded p-2 text-white font-bold"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-slate-400 text-[10px]">MAX SINGLE-INSTRUMENT EXPOSURE (%)</span>
              <input
                type="number"
                min="10"
                max="100"
                value={safetySettings.maxExposurePerInstrumentPercent}
                onChange={(e) => onUpdateSafetySettings({ maxExposurePerInstrumentPercent: parseFloat(e.target.value) || 30 })}
                className="bg-[#090d16] border border-[#1e293b] rounded p-2 text-white font-bold"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-slate-400 text-[10px]">DISCIPLINE COOLDOWN AFTER LOSS (MINUTES)</span>
              <input
                type="number"
                min="0"
                max="60"
                value={safetySettings.cooldownMinutesAfterLoss}
                onChange={(e) => onUpdateSafetySettings({ cooldownMinutesAfterLoss: parseInt(e.target.value, 10) || 0 })}
                className="bg-[#090d16] border border-[#1e293b] rounded p-2 text-white font-bold"
              />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-slate-400 text-[10px]">MIN REQUIRED RISK/REWARD RATIO</span>
              <input
                type="number"
                step="0.1"
                min="1.0"
                value={safetySettings.minRiskRewardRatio}
                onChange={(e) => onUpdateSafetySettings({ minRiskRewardRatio: parseFloat(e.target.value) || 1.5 })}
                className="bg-[#090d16] border border-[#1e293b] rounded p-2 text-white font-bold"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
