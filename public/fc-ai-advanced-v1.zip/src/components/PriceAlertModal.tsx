/**
 * FC AI ADVANCED - PRICE ALERT MODAL (MARKETS TAB)
 * Allows users to configure custom price threshold alerts with directional triggers (>= or <=),
 * audio chimes, visual notifications, and persistent alert management.
 */

import React, { useState, useEffect } from 'react';
import { PriceAlert, MarketQuote } from '../types/market';
import { INSTRUMENT_CATALOG } from '../lib/instruments';
import {
  Bell,
  X,
  Plus,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Volume2,
  TrendingUp,
  TrendingDown,
  Clock,
  Power,
} from 'lucide-react';

interface PriceAlertModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedSymbol: string;
  currentQuote?: MarketQuote;
  alerts: PriceAlert[];
  onAddAlert: (alert: Omit<PriceAlert, 'id' | 'createdAt' | 'isTriggered'>) => void;
  onToggleAlert: (alertId: string) => void;
  onDeleteAlert: (alertId: string) => void;
}

// Web Audio API chime generator
export function playAlertChime() {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const now = ctx.currentTime;

    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(880, now); // A5
    osc1.frequency.exponentialRampToValueAtTime(1174.66, now + 0.12); // D6

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(440, now);
    osc2.frequency.exponentialRampToValueAtTime(587.33, now + 0.12);

    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.5);
    osc2.stop(now + 0.5);
  } catch (err) {
    console.warn('Audio chime playback failed:', err);
  }
}

export const PriceAlertModal: React.FC<PriceAlertModalProps> = ({
  isOpen,
  onClose,
  selectedSymbol,
  currentQuote,
  alerts,
  onAddAlert,
  onToggleAlert,
  onDeleteAlert,
}) => {
  const currentInst = INSTRUMENT_CATALOG[selectedSymbol] || INSTRUMENT_CATALOG['BTC/USDT'];
  const currentPrice = currentQuote?.lastPrice || 0;

  const [targetPrice, setTargetPrice] = useState<string>('');
  const [condition, setCondition] = useState<'ABOVE' | 'BELOW'>('ABOVE');
  const [note, setNote] = useState<string>('');
  const [filterSymbol, setFilterSymbol] = useState<string>(selectedSymbol);

  // Initialize target price when modal opens or symbol changes
  useEffect(() => {
    if (currentPrice > 0 && !targetPrice) {
      // Default to 1% above current price
      const defaultTarget = currentPrice * 1.01;
      setTargetPrice(defaultTarget.toFixed(currentInst.pricePrecision));
      setCondition('ABOVE');
    }
    setFilterSymbol(selectedSymbol);
  }, [selectedSymbol, currentPrice]);

  // Adjust condition automatically when target price is typed
  const handleTargetChange = (val: string) => {
    setTargetPrice(val);
    const num = parseFloat(val);
    if (!isNaN(num) && currentPrice > 0) {
      if (num > currentPrice) {
        setCondition('ABOVE');
      } else if (num < currentPrice) {
        setCondition('BELOW');
      }
    }
  };

  // Quick percentage presets
  const applyPreset = (percentDelta: number) => {
    if (currentPrice <= 0) return;
    const newPrice = currentPrice * (1 + percentDelta / 100);
    setTargetPrice(newPrice.toFixed(currentInst.pricePrecision));
    setCondition(percentDelta >= 0 ? 'ABOVE' : 'BELOW');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(targetPrice);
    if (isNaN(num) || num <= 0) {
      alert('Please enter a valid positive target price.');
      return;
    }

    onAddAlert({
      symbol: selectedSymbol,
      targetPrice: Number(num.toFixed(currentInst.pricePrecision)),
      condition,
      note: note.trim() || undefined,
      isActive: true,
    });

    // Play feedback chime
    playAlertChime();

    // Reset inputs
    setNote('');
  };

  // Filter alerts for display
  const symbolAlerts = filterSymbol === 'ALL'
    ? alerts
    : alerts.filter(a => a.symbol === filterSymbol);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-lg bg-[#0f172a] border border-[#1e293b] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#090d16] border-b border-[#1e293b]">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-blue-500/20 text-blue-400 border border-blue-500/30">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Price Alerts & Notification Triggers</h3>
              <div className="text-[10px] font-mono text-slate-400">
                {selectedSymbol} • Current Price: <strong className="text-white font-mono-num font-bold">{currentPrice > 0 ? currentPrice.toFixed(currentInst.pricePrecision) : '---'}</strong>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={playAlertChime}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
              title="Test Alert Chime"
            >
              <Volume2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-4 overflow-y-auto flex flex-col gap-4">
          {/* Create Alert Form */}
          <form onSubmit={handleSubmit} className="bg-[#090d16] border border-[#1e293b] rounded-xl p-3.5 flex flex-col gap-3 font-mono text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white uppercase text-[11px] tracking-wide flex items-center gap-1.5">
                <Plus className="w-3.5 h-3.5 text-blue-400" />
                <span>Create New Alert for {selectedSymbol}</span>
              </span>
              <span className="text-[10px] text-slate-400">Real-time Tick Evaluation</span>
            </div>

            {/* Target Price Input */}
            <div className="flex flex-col gap-1">
              <label className="text-slate-400 text-[10px]">TARGET TRIGGER PRICE ({currentInst.quoteCurrency})</label>
              <div className="relative">
                <input
                  type="number"
                  step="any"
                  placeholder="e.g. 69500"
                  value={targetPrice}
                  onChange={(e) => handleTargetChange(e.target.value)}
                  className="w-full bg-[#0f172a] border border-[#1e293b] rounded-lg px-3 py-2 text-white font-bold text-sm focus:outline-none focus:border-blue-500 font-mono-num"
                  required
                />
              </div>
            </div>

            {/* Quick Percentage Presets */}
            <div className="flex items-center gap-1 flex-wrap text-[10px]">
              <span className="text-slate-500 mr-1">Presets:</span>
              <button
                type="button"
                onClick={() => applyPreset(-5)}
                className="px-2 py-0.5 rounded bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20"
              >
                -5%
              </button>
              <button
                type="button"
                onClick={() => applyPreset(-2)}
                className="px-2 py-0.5 rounded bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20"
              >
                -2%
              </button>
              <button
                type="button"
                onClick={() => applyPreset(-1)}
                className="px-2 py-0.5 rounded bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20"
              >
                -1%
              </button>
              <button
                type="button"
                onClick={() => applyPreset(1)}
                className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/20"
              >
                +1%
              </button>
              <button
                type="button"
                onClick={() => applyPreset(2)}
                className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/20"
              >
                +2%
              </button>
              <button
                type="button"
                onClick={() => applyPreset(5)}
                className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/20"
              >
                +5%
              </button>
            </div>

            {/* Condition Choice */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => setCondition('ABOVE')}
                className={`py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 border transition-all ${
                  condition === 'ABOVE'
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50 font-bold'
                    : 'bg-[#0f172a] text-slate-400 border-[#1e293b] hover:text-white'
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Rises Above (≥)</span>
              </button>

              <button
                type="button"
                onClick={() => setCondition('BELOW')}
                className={`py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 border transition-all ${
                  condition === 'BELOW'
                    ? 'bg-red-500/20 text-red-400 border-red-500/50 font-bold'
                    : 'bg-[#0f172a] text-slate-400 border-[#1e293b] hover:text-white'
                }`}
              >
                <TrendingDown className="w-3.5 h-3.5" />
                <span>Drops Below (≤)</span>
              </button>
            </div>

            {/* Alert Note */}
            <div className="flex flex-col gap-1">
              <label className="text-slate-400 text-[10px]">NOTE / RATIONALE (OPTIONAL)</label>
              <input
                type="text"
                placeholder="e.g. Resistance breakout, take profit level"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="w-full bg-[#0f172a] border border-[#1e293b] rounded-lg px-3 py-1.5 text-white text-xs focus:outline-none focus:border-blue-500 font-sans"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-bold font-mono text-xs shadow-md transition-all flex items-center justify-center gap-1.5"
            >
              <Bell className="w-3.5 h-3.5" />
              <span>Set Price Alert</span>
            </button>
          </form>

          {/* Active & Triggered Alerts Section */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-xs text-white font-mono">YOUR PRICE ALERTS</span>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">
                  {symbolAlerts.length}
                </span>
              </div>

              {/* Filter */}
              <div className="flex items-center gap-1 text-[10px] font-mono">
                <button
                  type="button"
                  onClick={() => setFilterSymbol(selectedSymbol)}
                  className={`px-2 py-0.5 rounded ${filterSymbol === selectedSymbol ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
                >
                  {selectedSymbol}
                </button>
                <button
                  type="button"
                  onClick={() => setFilterSymbol('ALL')}
                  className={`px-2 py-0.5 rounded ${filterSymbol === 'ALL' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
                >
                  All Pairs
                </button>
              </div>
            </div>

            {symbolAlerts.length === 0 ? (
              <div className="bg-[#090d16] border border-[#1e293b] rounded-xl p-6 text-center text-xs text-slate-500 font-mono flex flex-col items-center gap-1.5">
                <Bell className="w-6 h-6 text-slate-600" />
                <span>No price alerts configured for {filterSymbol === 'ALL' ? 'any instrument' : selectedSymbol}.</span>
              </div>
            ) : (
              <div className="flex flex-col gap-1.5 max-h-56 overflow-y-auto">
                {symbolAlerts.map(alert => {
                  const isAbove = alert.condition === 'ABOVE';
                  return (
                    <div
                      key={alert.id}
                      className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 text-xs font-mono transition-all ${
                        alert.isTriggered
                          ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                          : alert.isActive
                          ? 'bg-[#090d16] border-[#1e293b] text-slate-200'
                          : 'bg-[#090d16]/50 border-[#1e293b]/50 text-slate-500'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className={`p-1 rounded ${
                          alert.isTriggered
                            ? 'bg-amber-500/20 text-amber-400'
                            : isAbove
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : 'bg-red-500/20 text-red-400'
                        }`}>
                          {alert.isTriggered ? (
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          ) : isAbove ? (
                            <TrendingUp className="w-3.5 h-3.5" />
                          ) : (
                            <TrendingDown className="w-3.5 h-3.5" />
                          )}
                        </div>

                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-white">{alert.symbol}</span>
                            <span className={`text-[10px] font-bold ${isAbove ? 'text-emerald-400' : 'text-red-400'}`}>
                              {isAbove ? '≥' : '≤'} {alert.targetPrice}
                            </span>
                            {alert.isTriggered && (
                              <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-400 font-bold">
                                TRIGGERED
                              </span>
                            )}
                          </div>
                          {alert.note && (
                            <div className="text-[11px] text-slate-400 font-sans">
                              {alert.note}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-1">
                        {!alert.isTriggered && (
                          <button
                            type="button"
                            onClick={() => onToggleAlert(alert.id)}
                            className={`p-1.5 rounded transition-colors ${
                              alert.isActive
                                ? 'text-emerald-400 hover:bg-emerald-500/10'
                                : 'text-slate-500 hover:text-slate-300'
                            }`}
                            title={alert.isActive ? 'Pause Alert' : 'Activate Alert'}
                          >
                            <Power className="w-3.5 h-3.5" />
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => onDeleteAlert(alert.id)}
                          className="p-1.5 text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded transition-colors"
                          title="Delete Alert"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
