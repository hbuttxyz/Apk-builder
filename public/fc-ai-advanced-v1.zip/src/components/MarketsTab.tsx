/**
 * FC AI ADVANCED - MARKETS TERMINAL (MODULES 02 & 11)
 * Interactive Candlestick Chart, Attributable Bid/Ask Quotes,
 * Automated Technical Analyst (Module 02), and Market Regime Detector (Module 11).
 */

import React, { useState } from 'react';
import {
  Instrument,
  MarketQuote,
  OHLCVCandle,
  Timeframe,
  AssetClass,
  TechnicalSummary,
  MarketRegimeAnalysis,
  PriceAlert,
} from '../types/market';
import { INSTRUMENT_CATALOG } from '../lib/instruments';
import { CandlestickChart } from './CandlestickChart';
import { PriceAlertModal } from './PriceAlertModal';
import {
  Search,
  SlidersHorizontal,
  TrendingUp,
  TrendingDown,
  Compass,
  Layers,
  ArrowRight,
  Shield,
  Gauge,
  Activity,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Bell,
} from 'lucide-react';

interface MarketsTabProps {
  selectedSymbol: string;
  onSelectSymbol: (symbol: string) => void;
  timeframe: Timeframe;
  onTimeframeChange: (tf: Timeframe) => void;
  candles: OHLCVCandle[];
  quotes: Record<string, MarketQuote>;
  technicalSummary?: TechnicalSummary;
  marketRegime?: MarketRegimeAnalysis;
  onNavigateToTrade: (symbol: string) => void;
  onRefreshFeed: () => void;
  isLoadingCandles: boolean;
  alerts?: PriceAlert[];
  onAddAlert?: (alert: Omit<PriceAlert, 'id' | 'createdAt' | 'isTriggered'>) => void;
  onToggleAlert?: (alertId: string) => void;
  onDeleteAlert?: (alertId: string) => void;
}

export const MarketsTab: React.FC<MarketsTabProps> = ({
  selectedSymbol,
  onSelectSymbol,
  timeframe,
  onTimeframeChange,
  candles,
  quotes,
  technicalSummary,
  marketRegime,
  onNavigateToTrade,
  onRefreshFeed,
  isLoadingCandles,
  alerts = [],
  onAddAlert = () => {},
  onToggleAlert = () => {},
  onDeleteAlert = () => {},
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAssetClass, setSelectedAssetClass] = useState<AssetClass | 'all'>('all');
  const [activeSubTab, setActiveSubTab] = useState<'ANALYSIS' | 'REGIME' | 'ORDER_BOOK'>('ANALYSIS');
  const [isAlertModalOpen, setIsAlertModalOpen] = useState(false);

  const activeAlertsForSymbolCount = alerts.filter(a => a.symbol === selectedSymbol && a.isActive && !a.isTriggered).length;

  const currentInstrument = INSTRUMENT_CATALOG[selectedSymbol] || INSTRUMENT_CATALOG['BTC/USDT'];
  const currentQuote = quotes[selectedSymbol];

  // Filter instruments
  const instrumentList = Object.values(INSTRUMENT_CATALOG).filter(inst => {
    const matchesSearch =
      inst.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inst.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedAssetClass === 'all' || inst.assetClass === selectedAssetClass;
    return matchesSearch && matchesCategory;
  });

  // Calculate Technical Analyst Action (Module 02)
  const getTechnicalAction = (): { action: 'BUY' | 'SELL' | 'HOLD' | 'NO_TRADE'; reason: string; color: string } => {
    if (!technicalSummary) {
      return { action: 'NO_TRADE', reason: 'Awaiting candle indicator confirmation', color: 'text-slate-400' };
    }
    const { rsi, macd, maAlignment, adx } = technicalSummary;

    if (maAlignment === 'STRONG_BULL' && macd.trend === 'BULLISH' && rsi < 68) {
      return {
        action: 'BUY',
        reason: 'Confirmed bullish moving average alignment with positive MACD histogram expansion and healthy RSI headroom.',
        color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
      };
    }
    if (maAlignment === 'STRONG_BEAR' && macd.trend === 'BEARISH' && rsi > 32) {
      return {
        action: 'SELL',
        reason: 'Confirmed bearish moving average stack below declining 50 SMA with negative momentum acceleration.',
        color: 'text-red-400 bg-red-500/10 border-red-500/30',
      };
    }
    if (adx.strength === 'WEAK_CHOPPY') {
      return {
        action: 'HOLD',
        reason: `ADX reading (${adx.adx}) indicates choppy compression. Await boundary resolution before directional commitment.`,
        color: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
      };
    }
    return {
      action: 'NO_TRADE',
      reason: 'Mixed directional signals across oscillators and trend indicators.',
      color: 'text-slate-300 bg-slate-800 border-slate-700',
    };
  };

  const techVerdict = getTechnicalAction();

  // Bid / Ask spread calculations
  const bid = currentQuote?.bid || currentQuote?.lastPrice || 0;
  const ask = currentQuote?.ask || currentQuote?.lastPrice || 0;
  const spread = Math.max(0, ask - bid);
  const spreadBps = currentQuote?.lastPrice ? (spread / currentQuote.lastPrice) * 10000 : 0;

  return (
    <div className="flex flex-col gap-4 pb-20 pt-2 px-3 max-w-7xl mx-auto">
      {/* Search and Asset Class Selector */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search pairs (e.g. BTC, EUR, Gold, SPX)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-[#0f172a] border border-[#1e293b] rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono"
            />
          </div>
          <button
            onClick={() => onNavigateToTrade(selectedSymbol)}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-blue-500/20"
          >
            <span>Trade</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5 text-[11px] font-mono">
          {(['all', 'crypto', 'forex', 'metals', 'indices', 'stocks'] as const).map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedAssetClass(cat)}
              className={`px-3 py-1 rounded-lg capitalize whitespace-nowrap transition-all ${
                selectedAssetClass === cat
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'bg-[#0f172a] text-slate-400 border border-[#1e293b] hover:text-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Horizontal Quick-Select Carousel */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
          {instrumentList.map(inst => {
            const isSelected = inst.symbol === selectedSymbol;
            const q = quotes[inst.symbol];
            return (
              <button
                key={inst.symbol}
                onClick={() => onSelectSymbol(inst.symbol)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-blue-600/20 border-blue-500 text-white shadow-sm'
                    : 'bg-[#0f172a] border-[#1e293b] text-slate-400 hover:text-white'
                }`}
              >
                <span className="font-bold">{inst.symbol}</span>
                {q && (
                  <span className={`text-[10px] font-mono ${q.changePercent24h >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {q.changePercent24h >= 0 ? '+' : ''}{q.changePercent24h.toFixed(1)}%
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Attributable Quote & Spread Card */}
      <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-3 flex flex-col gap-2 shadow-md">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#1e293b] pb-2">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-white">{currentInstrument.name}</h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                {currentInstrument.exchangeOrProvider}
              </span>
            </div>
            <div className="text-[10px] text-slate-400 font-mono">
              Trading Hours: {currentInstrument.tradingHours} | Tick: {currentInstrument.tickSize}
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <button
              type="button"
              onClick={() => setIsAlertModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-[#090d16] hover:bg-slate-800 text-blue-400 border border-blue-500/30 text-xs font-mono font-semibold transition-all hover:border-blue-400 shadow-sm"
              title="Set Price Alert for this instrument"
            >
              <Bell className="w-3.5 h-3.5" />
              <span>Set Alert</span>
              {activeAlertsForSymbolCount > 0 && (
                <span className="w-4 h-4 rounded-full bg-blue-600 text-white text-[9px] font-bold flex items-center justify-center">
                  {activeAlertsForSymbolCount}
                </span>
              )}
            </button>
            <span className="flex items-center gap-1 px-2 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              {currentQuote?.status || 'LIVE'}
            </span>
          </div>
        </div>

        {/* Pricing & Spread Breakdown */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
          <div className="bg-[#090d16] p-2 rounded-lg border border-[#1e293b]">
            <span className="text-slate-500 text-[10px] block">EXECUTABLE BID</span>
            <span className="text-white font-bold font-mono-num">{bid.toFixed(currentInstrument.pricePrecision)}</span>
          </div>
          <div className="bg-[#090d16] p-2 rounded-lg border border-[#1e293b]">
            <span className="text-slate-500 text-[10px] block">EXECUTABLE ASK</span>
            <span className="text-white font-bold font-mono-num">{ask.toFixed(currentInstrument.pricePrecision)}</span>
          </div>
          <div className="bg-[#090d16] p-2 rounded-lg border border-[#1e293b]">
            <span className="text-slate-500 text-[10px] block">BID/ASK SPREAD</span>
            <span className="text-blue-400 font-bold font-mono-num">
              {spread.toFixed(currentInstrument.pricePrecision)} ({spreadBps.toFixed(1)} bps)
            </span>
          </div>
          <div className="bg-[#090d16] p-2 rounded-lg border border-[#1e293b]">
            <span className="text-slate-500 text-[10px] block">24H RANGE</span>
            <span className="text-slate-300 font-bold font-mono-num text-[11px]">
              {currentQuote ? `${currentQuote.low24h} - ${currentQuote.high24h}` : '---'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Interactive Candlestick Chart */}
      <CandlestickChart
        candles={candles}
        symbol={selectedSymbol}
        timeframe={timeframe}
        onTimeframeChange={onTimeframeChange}
        technicalSummary={technicalSummary}
        pricePrecision={currentInstrument.pricePrecision}
        onRefresh={onRefreshFeed}
        isLoading={isLoadingCandles}
      />

      {/* Sub Tabs: Automated Technical Analyst (Mod 02) & Market Regime (Mod 11) */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center gap-1 bg-[#0f172a] p-1 rounded-xl border border-[#1e293b] text-xs font-mono">
          <button
            onClick={() => setActiveSubTab('ANALYSIS')}
            className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
              activeSubTab === 'ANALYSIS' ? 'bg-blue-600 text-white font-semibold shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Gauge className="w-3.5 h-3.5" />
            <span>Technical Analyst (Mod 02)</span>
          </button>
          <button
            onClick={() => setActiveSubTab('REGIME')}
            className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
              activeSubTab === 'REGIME' ? 'bg-blue-600 text-white font-semibold shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Market Regime (Mod 11)</span>
          </button>
        </div>

        {activeSubTab === 'ANALYSIS' && technicalSummary && (
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-4 flex flex-col gap-3 shadow-md">
            {/* Technical Verdict Banner */}
            <div className={`p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-2 ${techVerdict.color}`}>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs uppercase font-mono font-bold tracking-wider">Action Verdict:</span>
                  <span className="text-base font-extrabold tracking-tight">{techVerdict.action}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/30 border border-white/10">
                    Closed-Candle Confirmed
                  </span>
                </div>
                <p className="text-xs mt-1 text-slate-300 leading-relaxed font-sans">
                  {techVerdict.reason}
                </p>
              </div>
              <button
                onClick={() => onNavigateToTrade(selectedSymbol)}
                className="px-4 py-2 bg-white text-slate-950 font-bold text-xs rounded-lg hover:bg-slate-200 transition-colors shrink-0"
              >
                Execute {techVerdict.action}
              </button>
            </div>

            {/* Indicator Details Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
              <div className="bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b]">
                <span className="text-slate-500 text-[10px] block">RSI (14)</span>
                <span className={`font-bold font-mono-num ${
                  technicalSummary.rsi >= 70 ? 'text-red-400' : technicalSummary.rsi <= 30 ? 'text-emerald-400' : 'text-slate-200'
                }`}>
                  {technicalSummary.rsi.toFixed(1)} ({technicalSummary.rsiState})
                </span>
              </div>
              <div className="bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b]">
                <span className="text-slate-500 text-[10px] block">MACD (12, 26, 9)</span>
                <span className={`font-bold font-mono-num ${technicalSummary.macd.trend.includes('BULL') ? 'text-emerald-400' : 'text-red-400'}`}>
                  {technicalSummary.macd.histogram.toFixed(4)} ({technicalSummary.macd.trend})
                </span>
              </div>
              <div className="bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b]">
                <span className="text-slate-500 text-[10px] block">MA ALIGNMENT</span>
                <span className="font-bold text-slate-200">
                  {technicalSummary.maAlignment.replace('_', ' ')}
                </span>
              </div>
              <div className="bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b]">
                <span className="text-slate-500 text-[10px] block">TREND STRENGTH (ADX)</span>
                <span className="font-bold text-slate-200">
                  {technicalSummary.adx.adx.toFixed(1)} ({technicalSummary.adx.strength})
                </span>
              </div>
              <div className="bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b]">
                <span className="text-slate-500 text-[10px] block">ATR VOLATILITY</span>
                <span className="font-bold text-slate-200">
                  {technicalSummary.atr.toFixed(currentInstrument.pricePrecision)}
                </span>
              </div>
              <div className="bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b]">
                <span className="text-slate-500 text-[10px] block">STOCHASTIC (14, 3, 3)</span>
                <span className="font-bold text-slate-200 font-mono-num">
                  %K: {technicalSummary.stochastic.k} | %D: {technicalSummary.stochastic.d}
                </span>
              </div>
              <div className="bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b] col-span-2">
                <span className="text-slate-500 text-[10px] block">CANDLESTICK STRUCTURE</span>
                <span className="font-bold text-purple-300">
                  {technicalSummary.priceActionPattern || 'Standard Candle'}
                </span>
              </div>
            </div>

            {/* Support and Resistance Horizontal Zones */}
            <div className="flex flex-col gap-1.5 pt-1">
              <span className="text-xs text-slate-400 font-mono">SUPPORT & RESISTANCE CLUSTERS</span>
              <div className="flex flex-wrap gap-2 text-xs font-mono">
                {technicalSummary.supportLevels.map((sup, idx) => (
                  <span key={idx} className="px-2 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    S{idx + 1}: {sup.toFixed(currentInstrument.pricePrecision)}
                  </span>
                ))}
                {technicalSummary.resistanceLevels.map((res, idx) => (
                  <span key={idx} className="px-2 py-1 rounded bg-red-500/10 text-red-400 border border-red-500/20">
                    R{idx + 1}: {res.toFixed(currentInstrument.pricePrecision)}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeSubTab === 'REGIME' && marketRegime && (
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-4 flex flex-col gap-3 shadow-md">
            <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-mono block">Detected Regime</span>
                <span className="text-base font-extrabold text-blue-400 tracking-wide">
                  {marketRegime.regime.replace('_', ' ')}
                </span>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-slate-400 uppercase font-mono block">Confidence Score</span>
                <span className="text-base font-bold text-emerald-400 font-mono-num">
                  {marketRegime.confidenceScore}%
                </span>
              </div>
            </div>

            {/* Evidence items */}
            <div className="flex flex-col gap-1.5">
              <span className="text-xs text-slate-400 font-mono">QUANTITATIVE EVIDENCE</span>
              <ul className="flex flex-col gap-1 text-xs text-slate-300">
                {marketRegime.evidence.map((ev, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="text-blue-400 mt-0.5">•</span>
                    <span>{ev}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Recommendations */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono pt-1">
              <div className="bg-emerald-500/10 border border-emerald-500/20 p-2.5 rounded-lg">
                <span className="text-emerald-400 font-bold block mb-0.5">RECOMMENDED STRATEGY</span>
                <span className="text-slate-200">{marketRegime.recommendedStrategy}</span>
              </div>
              <div className="bg-red-500/10 border border-red-500/20 p-2.5 rounded-lg">
                <span className="text-red-400 font-bold block mb-0.5">UNFAVORABLE STRATEGY</span>
                <span className="text-slate-200">{marketRegime.unfavorableStrategy}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Price Alert Modal */}
      <PriceAlertModal
        isOpen={isAlertModalOpen}
        onClose={() => setIsAlertModalOpen(false)}
        selectedSymbol={selectedSymbol}
        currentQuote={currentQuote}
        alerts={alerts}
        onAddAlert={onAddAlert}
        onToggleAlert={onToggleAlert}
        onDeleteAlert={onDeleteAlert}
      />
    </div>
  );
};
