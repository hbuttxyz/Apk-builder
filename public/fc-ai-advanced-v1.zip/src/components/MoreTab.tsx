/**
 * FC AI ADVANCED - ADVANCED INTELLIGENCE & RESEARCH SUITE (MORE TAB)
 * Houses:
 * - Module 04: Quantitative Strategy Backtester
 * - Module 03: News-to-Trading Intelligence
 * - Module 06: Trading Journal Intelligence
 * - Module 07: Daily Automated Trading Planner
 * - Module 09: Multi-AI Debate Engine
 * - Requirement 11: Independent Quality Gatekeeper Audit Suite
 * - Data Persistence: JSON Backup & Atomic Restore
 */

import React, { useState } from 'react';
import {
  OHLCVCandle,
  BacktestParameters,
  BacktestResult,
  NewsItem,
  JournalRecord,
  DailyPlannerTaskItem,
  MultiAgentDebateOutcome,
  PaperPosition,
} from '../types/market';
import { runBacktest } from '../lib/backtester';
import { runGatekeeperAudit, GatekeeperAuditReport } from '../lib/gatekeeper';
import { AppStorage } from '../lib/persistence';
import { INSTRUMENT_CATALOG } from '../lib/instruments';
import {
  LineChart,
  Newspaper,
  BookOpen,
  CalendarCheck2,
  Users,
  ShieldCheck,
  Download,
  Upload,
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ChevronRight,
  ExternalLink,
  Sparkles,
  FileCode,
  Archive,
} from 'lucide-react';

interface MoreTabProps {
  candles: OHLCVCandle[];
  selectedSymbol: string;
  newsItems: NewsItem[];
  journalRecords: JournalRecord[];
  onAddJournalRecord: (record: JournalRecord) => void;
  plannerTasks: DailyPlannerTaskItem[];
  onTogglePlannerTask: (taskId: string) => void;
  onAddTask: (task: DailyPlannerTaskItem) => void;
  onTriggerAiDebate: (symbol: string) => Promise<MultiAgentDebateOutcome | null>;
  debateOutcome?: MultiAgentDebateOutcome | null;
  isDebating: boolean;
  onRestoreBackup: (json: string) => void;
}

export const MoreTab: React.FC<MoreTabProps> = ({
  candles,
  selectedSymbol,
  newsItems,
  journalRecords,
  onAddJournalRecord,
  plannerTasks,
  onTogglePlannerTask,
  onAddTask,
  onTriggerAiDebate,
  debateOutcome,
  isDebating,
  onRestoreBackup,
}) => {
  const [activeModule, setActiveModule] = useState<
    'BACKTEST' | 'NEWS' | 'JOURNAL' | 'PLANNER' | 'DEBATE' | 'GATEKEEPER' | 'SETTINGS'
  >('DEBATE');

  // Backtester state
  const [bktStrategy, setBktStrategy] = useState<BacktestParameters['strategyName']>('SMA_CROSSOVER');
  const [bktFast, setBktFast] = useState(10);
  const [bktSlow, setBktSlow] = useState(30);
  const [bktSL, setBktSL] = useState(2.5);
  const [bktTP, setBktTP] = useState(5.0);
  const [bktResult, setBktResult] = useState<BacktestResult | null>(null);

  // Gatekeeper state
  const [gatekeeperReport, setGatekeeperReport] = useState<GatekeeperAuditReport | null>(null);
  const [isRunningAudit, setIsRunningAudit] = useState(false);

  // Journal Entry Form State
  const [newJournalStrategy, setNewJournalStrategy] = useState('Trend Pullback');
  const [newJournalEntryNotes, setNewJournalEntryNotes] = useState('');
  const [newJournalTag, setNewJournalTag] = useState('Followed Plan');

  // Backup file upload state
  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Execute Backtest
  const handleRunBacktest = () => {
    try {
      const res = runBacktest(candles, {
        strategyName: bktStrategy,
        symbol: selectedSymbol,
        timeframe: '1H',
        initialCapital: 10000,
        fastPeriod: bktFast,
        slowPeriod: bktSlow,
        stopLossPercent: bktSL,
        takeProfitPercent: bktTP,
        slippageBps: 2,
        feeBps: 6,
        inSampleRatio: 0.7,
      });
      setBktResult(res);
    } catch (err: any) {
      alert(`Backtest error: ${err.message}`);
    }
  };

  // Run Gatekeeper Test Suite
  const handleRunGatekeeper = async () => {
    setIsRunningAudit(true);
    const report = await runGatekeeperAudit();
    setGatekeeperReport(report);
    setIsRunningAudit(false);
  };

  // Export JSON Backup
  const handleExportBackup = () => {
    const json = AppStorage.exportFullBackup();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `FC_AI_ADVANCED_BACKUP_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Handle Import Backup
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = AppStorage.restoreFullBackup(content);
      if (res.success) {
        setImportStatus(res.message);
        onRestoreBackup(content);
      } else {
        setImportStatus(`Import Error: ${res.message}`);
      }
    };
    reader.readAsText(file);
  };

  // Journal Analytics (Module 06)
  const recentTrades = journalRecords.slice(0, 20);
  const losingTrades = recentTrades.filter(t => t.netPnL < 0);
  const revengeTrades = recentTrades.filter(t => t.tags.includes('Revenge Trade'));
  const earlyExits = recentTrades.filter(t => t.tags.includes('Early Exit'));

  const personalizedRules = [
    'Rule 1: Mandate strict 3-minute cooldown after any loss to eliminate revenge trading impulses.',
    'Rule 2: Never shift stop loss further into negative territory once position is filled.',
    'Rule 3: Ensure minimum 1.5:1 Risk/Reward before placing order on 1H or 4H timeframe.',
  ];

  return (
    <div className="flex flex-col gap-4 pb-20 pt-2 px-3 max-w-7xl mx-auto">
      {/* Module Navigation Carousel */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1 text-xs font-mono">
        {[
          { key: 'DEBATE', label: 'Multi-AI Debate (Mod 09)', icon: Users },
          { key: 'BACKTEST', label: 'Backtester (Mod 04)', icon: LineChart },
          { key: 'NEWS', label: 'News Intel (Mod 03)', icon: Newspaper },
          { key: 'JOURNAL', label: 'Trade Journal (Mod 06)', icon: BookOpen },
          { key: 'PLANNER', label: 'Daily Planner (Mod 07)', icon: CalendarCheck2 },
          { key: 'GATEKEEPER', label: 'Gatekeeper Audit (Req 11)', icon: ShieldCheck },
          { key: 'SETTINGS', label: 'Data & Backup', icon: Download },
        ].map(mod => {
          const Icon = mod.icon;
          const isActive = activeModule === mod.key;
          return (
            <button
              key={mod.key}
              onClick={() => setActiveModule(mod.key as any)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl whitespace-nowrap transition-all border ${
                isActive
                  ? 'bg-blue-600 text-white font-bold border-blue-500 shadow-md'
                  : 'bg-[#0f172a] text-slate-400 border-[#1e293b] hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{mod.label}</span>
            </button>
          );
        })}
      </div>

      {/* ------------------------------------------------------------- */}
      {/* MODULE 09: MULTI-AI DEBATE ENGINE */}
      {/* ------------------------------------------------------------- */}
      {activeModule === 'DEBATE' && (
        <div className="flex flex-col gap-3">
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-4 flex flex-col gap-3 shadow-md">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#1e293b] pb-2">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-extrabold text-base text-white">Multi-Agent Trading Debate</h3>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                    Module 09
                  </span>
                </div>
                <p className="text-xs text-slate-400 font-sans mt-0.5">
                  5 autonomous analytical agents (Technical, Fundamental, Risk, Counterargument, Coordinator) evaluate {selectedSymbol}.
                </p>
              </div>

              <button
                onClick={() => onTriggerAiDebate(selectedSymbol)}
                disabled={isDebating}
                className={`px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold font-mono text-xs rounded-xl shadow-lg shadow-purple-500/20 flex items-center gap-1.5 transition-all ${
                  isDebating ? 'opacity-60 cursor-not-allowed' : ''
                }`}
              >
                <Sparkles className={`w-3.5 h-3.5 ${isDebating ? 'animate-spin' : ''}`} />
                <span>{isDebating ? 'Agents Debating...' : 'Trigger Model Debate'}</span>
              </button>
            </div>

            {debateOutcome ? (
              <div className="flex flex-col gap-3 pt-1">
                {/* Consensus Verdict Box */}
                <div className="bg-[#090d16] border border-purple-500/30 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-mono text-slate-400 uppercase block">Consensus Coordinator Decision:</span>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-lg font-extrabold text-purple-400 tracking-wide font-mono">
                        {debateOutcome.consensusDecision}
                      </span>
                      <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                        Score: {debateOutcome.consensusScore}/100
                      </span>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                        debateOutcome.overallRiskLevel === 'LOW' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
                      }`}>
                        Risk: {debateOutcome.overallRiskLevel}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 font-sans mt-1">
                      {debateOutcome.suggestedAction}
                    </p>
                  </div>
                </div>

                {/* 5 Agents Rationale */}
                <div className="grid grid-cols-1 gap-2.5">
                  {debateOutcome.agents.map((ag) => {
                    const isBull = ag.bias === 'BULLISH';
                    const isBear = ag.bias === 'BEARISH';
                    return (
                      <div
                        key={ag.agentRole}
                        className="bg-[#090d16] border border-[#1e293b] rounded-xl p-3 flex flex-col gap-1.5"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs text-white">{ag.agentName}</span>
                            <span className={`text-[10px] font-mono font-bold px-2 py-0.2 rounded ${
                              isBull ? 'bg-emerald-500/20 text-emerald-400' : isBear ? 'bg-red-500/20 text-red-400' : 'bg-slate-800 text-slate-300'
                            }`}>
                              {ag.bias}
                            </span>
                          </div>
                          <span className="text-[10px] font-mono text-slate-400">{ag.sourceModel}</span>
                        </div>

                        <div className="text-xs text-slate-200 font-medium font-sans">
                          "{ag.headline}"
                        </div>

                        {/* Evidence Bullets */}
                        <ul className="text-xs text-slate-400 list-disc list-inside flex flex-col gap-0.5 font-sans">
                          {ag.evidence.map((ev, i) => (
                            <li key={i}>{ev}</li>
                          ))}
                        </ul>

                        {ag.disagreementsOrCaveats.length > 0 && (
                          <div className="text-[11px] text-amber-400/90 font-mono pt-1 border-t border-[#1e293b]">
                            Caveat: {ag.disagreementsOrCaveats.join(' • ')}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="p-8 text-center text-xs text-slate-500 font-mono flex flex-col items-center gap-2">
                <Users className="w-8 h-8 text-slate-600" />
                <span>Tap "Trigger Model Debate" to orchestrate full 5-agent quantitative debate for {selectedSymbol}.</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* MODULE 04: QUANTITATIVE STRATEGY BACKTESTER */}
      {/* ------------------------------------------------------------- */}
      {activeModule === 'BACKTEST' && (
        <div className="flex flex-col gap-3">
          {/* Parameter Configuration Card */}
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-4 flex flex-col gap-3 shadow-md">
            <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
              <span className="font-bold text-sm text-white font-mono">QUANTITATIVE BACKTEST PARAMETERS</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">
                Closed-Candle Execution
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
              <div className="flex flex-col gap-1 col-span-2">
                <span className="text-slate-400 text-[10px]">STRATEGY TYPE</span>
                <select
                  value={bktStrategy}
                  onChange={(e) => setBktStrategy(e.target.value as any)}
                  className="bg-[#090d16] border border-[#1e293b] rounded p-2 text-white font-bold"
                >
                  <option value="SMA_CROSSOVER">SMA Golden/Death Cross</option>
                  <option value="EMA_CROSSOVER">EMA Fast/Slow Momentum Cross</option>
                  <option value="RSI_MEAN_REVERSION">RSI Mean Reversion (30/70)</option>
                  <option value="MACD_CROSSOVER">MACD Signal Line Cross</option>
                  <option value="BOLLINGER_REVERSION">Bollinger Band Outer Fades</option>
                  <option value="DONCHIAN_BREAKOUT">Donchian Channel Breakout</option>
                  <option value="TREND_FOLLOWING">Triple Moving Average Trend Following</option>
                </select>
              </div>

              <div className="flex flex-col gap-1">
                <span className="text-slate-400 text-[10px]">Fast Period</span>
                <input
                  type="number"
                  value={bktFast}
                  onChange={(e) => setBktFast(parseInt(e.target.value, 10) || 5)}
                  className="bg-[#090d16] border border-[#1e293b] rounded p-2 text-white font-bold"
                />
              </div>

              <div className="flex flex-col gap-1">
                <span className="text-slate-400 text-[10px]">Slow Period</span>
                <input
                  type="number"
                  value={bktSlow}
                  onChange={(e) => setBktSlow(parseInt(e.target.value, 10) || 20)}
                  className="bg-[#090d16] border border-[#1e293b] rounded p-2 text-white font-bold"
                />
              </div>

              <div className="flex flex-col gap-1">
                <span className="text-slate-400 text-[10px]">Stop Loss %</span>
                <input
                  type="number"
                  step="0.5"
                  value={bktSL}
                  onChange={(e) => setBktSL(parseFloat(e.target.value) || 2)}
                  className="bg-[#090d16] border border-[#1e293b] rounded p-2 text-white font-bold"
                />
              </div>

              <div className="flex flex-col gap-1">
                <span className="text-slate-400 text-[10px]">Take Profit %</span>
                <input
                  type="number"
                  step="0.5"
                  value={bktTP}
                  onChange={(e) => setBktTP(parseFloat(e.target.value) || 4)}
                  className="bg-[#090d16] border border-[#1e293b] rounded p-2 text-white font-bold"
                />
              </div>
            </div>

            <button
              onClick={handleRunBacktest}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold font-mono text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5 transition-colors"
            >
              <Play className="w-3.5 h-3.5 fill-white" />
              <span>Execute Closed-Candle Backtest ({candles.length} Candles)</span>
            </button>
          </div>

          {/* Backtest Results */}
          {bktResult && (
            <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-4 flex flex-col gap-3 shadow-md">
              <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
                <div>
                  <span className="text-sm font-bold text-white font-mono">{bktResult.strategyName}</span>
                  <div className="text-[10px] text-slate-400 font-mono">
                    {bktResult.startDate} → {bktResult.endDate} ({bktResult.candleCount} candles)
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase font-mono block">Total Net Return</span>
                  <span className={`text-base font-extrabold font-mono-num ${bktResult.totalNetPnL >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {bktResult.totalReturnPercent >= 0 ? '+' : ''}{bktResult.totalReturnPercent}% (${bktResult.totalNetPnL.toFixed(2)})
                  </span>
                </div>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                <div className="bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b]">
                  <span className="text-slate-500 text-[10px] block">WIN RATE</span>
                  <span className="text-white font-bold font-mono-num">{bktResult.winRate}%</span>
                  <span className="text-[9px] text-slate-500 block">({bktResult.winningTrades}W / {bktResult.losingTrades}L)</span>
                </div>
                <div className="bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b]">
                  <span className="text-slate-500 text-[10px] block">PROFIT FACTOR</span>
                  <span className="text-blue-400 font-bold font-mono-num">{bktResult.profitFactor.toFixed(2)}</span>
                </div>
                <div className="bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b]">
                  <span className="text-slate-500 text-[10px] block">MAX DRAWDOWN</span>
                  <span className="text-red-400 font-bold font-mono-num">{bktResult.maxDrawdownPercent}%</span>
                </div>
                <div className="bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b]">
                  <span className="text-slate-500 text-[10px] block">SHARPE RATIO</span>
                  <span className="text-white font-bold font-mono-num">{bktResult.sharpeRatio.toFixed(2)}</span>
                </div>
                <div className="bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b]">
                  <span className="text-slate-500 text-[10px] block">EXPECTANCY</span>
                  <span className="text-slate-200 font-bold font-mono-num">${bktResult.expectancy.toFixed(2)} / trade</span>
                </div>
                <div className="bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b]">
                  <span className="text-slate-500 text-[10px] block">MARKET EXPOSURE</span>
                  <span className="text-slate-200 font-bold font-mono-num">{bktResult.marketExposurePercent}%</span>
                </div>
                <div className="bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b]">
                  <span className="text-slate-500 text-[10px] block">OUT-OF-SAMPLE WIN RATE</span>
                  <span className="text-purple-400 font-bold font-mono-num">{bktResult.outOfSampleWinRate}%</span>
                </div>
                <div className="bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b]">
                  <span className="text-slate-500 text-[10px] block">OUT-OF-SAMPLE RETURN</span>
                  <span className="text-purple-400 font-bold font-mono-num">{bktResult.outOfSampleReturnPercent.toFixed(1)}%</span>
                </div>
              </div>

              {/* Trade-by-trade audit table */}
              <div className="flex flex-col gap-1 pt-1">
                <span className="text-xs font-bold text-slate-300 font-mono">TRADE-BY-TRADE AUDIT LEDGER ({bktResult.trades.length} TRADES)</span>
                <div className="max-h-60 overflow-y-auto border border-[#1e293b] rounded-lg">
                  <table className="w-full text-left text-[11px] font-mono">
                    <thead className="bg-[#090d16] text-slate-400 text-[10px] uppercase sticky top-0">
                      <tr>
                        <th className="px-2 py-1.5">#</th>
                        <th className="px-2 py-1.5">Side</th>
                        <th className="px-2 py-1.5">In</th>
                        <th className="px-2 py-1.5">Out</th>
                        <th className="px-2 py-1.5">Net P&L</th>
                        <th className="px-2 py-1.5">Reason</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#1e293b]">
                      {bktResult.trades.map((t) => (
                        <tr key={t.tradeNumber} className="hover:bg-[#162038]">
                          <td className="px-2 py-1.5 text-slate-500">{t.tradeNumber}</td>
                          <td className="px-2 py-1.5 font-bold">
                            <span className={t.side === 'BUY' ? 'text-emerald-400' : 'text-red-400'}>{t.side}</span>
                          </td>
                          <td className="px-2 py-1.5 text-slate-300">${t.entryPrice}</td>
                          <td className="px-2 py-1.5 text-slate-300">${t.exitPrice}</td>
                          <td className={`px-2 py-1.5 font-bold ${t.netPnL >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                            {t.netPnL >= 0 ? '+' : ''}${t.netPnL.toFixed(2)}
                          </td>
                          <td className="px-2 py-1.5 text-slate-400 text-[10px]">{t.exitReason}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* MODULE 03: NEWS-TO-TRADING INTELLIGENCE */}
      {/* ------------------------------------------------------------- */}
      {activeModule === 'NEWS' && (
        <div className="flex flex-col gap-3">
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-3.5 flex flex-col gap-1">
            <h3 className="font-bold text-sm text-white font-mono">Attributable Financial News Intelligence</h3>
            <p className="text-xs text-slate-400 font-sans">
              Filtered market drivers with original source verification, macroeconomic impact ratings, and scenario branches.
            </p>
          </div>

          <div className="flex flex-col gap-2.5">
            {newsItems.map(item => (
              <div
                key={item.id}
                className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-3.5 flex flex-col gap-2 shadow-md"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-500/20 text-blue-300">
                      {item.source}
                    </span>
                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                      item.sentiment === 'BULLISH' ? 'bg-emerald-500/20 text-emerald-400' : item.sentiment === 'BEARISH' ? 'bg-red-500/20 text-red-400' : 'bg-slate-800 text-slate-300'
                    }`}>
                      {item.sentiment}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">
                    {new Date(item.timestampMs).toLocaleTimeString()}
                  </span>
                </div>

                <h4 className="font-bold text-xs text-white leading-snug">{item.title}</h4>
                <p className="text-xs text-slate-300 font-sans leading-relaxed">{item.summary}</p>

                {/* Scenarios */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b]">
                  <div className="text-emerald-400">
                    <strong>Bullish Branch:</strong> {item.bullishScenario}
                  </div>
                  <div className="text-red-400">
                    <strong>Bearish Branch:</strong> {item.bearishScenario}
                  </div>
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono pt-1">
                  <span>Note: {item.timelineNote}</span>
                  <a
                    href={item.url}
                    target="_blank"
                    rel="noreferrer"
                    className="text-blue-400 hover:text-blue-300 flex items-center gap-1"
                  >
                    <span>Original Source</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* MODULE 06: TRADING JOURNAL INTELLIGENCE */}
      {/* ------------------------------------------------------------- */}
      {activeModule === 'JOURNAL' && (
        <div className="flex flex-col gap-3">
          {/* Discipline Rules Card */}
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-4 flex flex-col gap-2 shadow-md">
            <span className="text-xs font-mono font-bold text-purple-400 uppercase tracking-wider">
              Observed Behavioral Intelligence (Last {recentTrades.length} Trades)
            </span>
            <div className="grid grid-cols-3 gap-2 text-xs font-mono bg-[#090d16] p-2 rounded-lg">
              <div>
                <span className="text-slate-500 text-[10px] block">TOTAL LOGGED</span>
                <span className="text-white font-bold">{journalRecords.length} trades</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">REVENGE PATTERNS</span>
                <span className={`font-bold ${revengeTrades.length > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                  {revengeTrades.length} detected
                </span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">EARLY EXITS</span>
                <span className="text-amber-400 font-bold">{earlyExits.length} recorded</span>
              </div>
            </div>

            <div className="flex flex-col gap-1 pt-1">
              <span className="text-[11px] font-mono text-slate-400 font-bold">Personalized Actionable Discipline Rules:</span>
              <ul className="text-xs text-slate-200 flex flex-col gap-1 font-sans">
                {personalizedRules.map((r, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="text-blue-400">•</span>
                    <span>{r}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Journal Entries List */}
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl overflow-hidden shadow-md">
            <div className="p-3 border-b border-[#1e293b] flex items-center justify-between">
              <span className="font-bold text-xs text-white font-mono">SAVED JOURNAL RECORDS</span>
              <span className="text-[10px] text-slate-500 font-mono">Durable Trade Notes</span>
            </div>

            {journalRecords.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500 font-mono">
                No trades logged yet. Click "Log in Journal" from Trade History to add trade reflections.
              </div>
            ) : (
              <div className="divide-y divide-[#1e293b] max-h-96 overflow-y-auto">
                {journalRecords.map(rec => (
                  <div key={rec.id} className="p-3.5 flex flex-col gap-1.5 hover:bg-[#162038]/50 text-xs font-mono">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm">{rec.symbol}</span>
                        <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                          rec.direction === 'BUY' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                        }`}>
                          {rec.direction}
                        </span>
                        <span className="text-slate-400">{rec.strategy}</span>
                      </div>
                      <span className={`font-mono-num font-bold ${rec.netPnL >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                        {rec.netPnL >= 0 ? '+' : ''}${rec.netPnL.toFixed(2)}
                      </span>
                    </div>

                    <div className="text-xs text-slate-300 font-sans">
                      <strong>Rationale:</strong> {rec.entryRationale}
                    </div>

                    <div className="flex flex-wrap gap-1 pt-1">
                      {rec.tags.map(tag => (
                        <span key={tag} className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 border border-slate-700">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* MODULE 07: DAILY AUTOMATED TRADING PLANNER */}
      {/* ------------------------------------------------------------- */}
      {activeModule === 'PLANNER' && (
        <div className="flex flex-col gap-3">
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-3.5 flex flex-col gap-1">
            <h3 className="font-bold text-sm text-white font-mono">Market Session Checklist & Routine</h3>
            <p className="text-xs text-slate-400 font-sans">
              Structured session workflows recognizing global market hours (London, NY, Tokyo, Crypto 24/7). Click tasks to mark progress.
            </p>
          </div>

          <div className="flex flex-col gap-2">
            {plannerTasks.map(task => (
              <div
                key={task.id}
                onClick={() => onTogglePlannerTask(task.id)}
                className={`p-3 rounded-xl border flex items-center justify-between gap-3 cursor-pointer transition-all ${
                  task.isCompleted
                    ? 'bg-[#0f172a]/60 border-emerald-500/30 text-slate-400'
                    : 'bg-[#0f172a] border-[#1e293b] hover:border-blue-500/40 text-slate-200'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  <div className={`mt-0.5 w-4 h-4 rounded flex items-center justify-center border ${
                    task.isCompleted ? 'bg-emerald-600 border-emerald-500 text-white' : 'border-slate-600 bg-[#090d16]'
                  }`}>
                    {task.isCompleted && <CheckCircle2 className="w-3.5 h-3.5" />}
                  </div>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-bold font-mono ${task.isCompleted ? 'line-through text-slate-500' : 'text-white'}`}>
                        {task.title}
                      </span>
                      <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">
                        {task.timeCategory}
                      </span>
                    </div>
                    <span className="text-xs text-slate-400 font-sans mt-0.5">{task.description}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* REQUIREMENT 11: QUALITY GATEKEEPER AUDIT SUITE */}
      {/* ------------------------------------------------------------- */}
      {activeModule === 'GATEKEEPER' && (
        <div className="flex flex-col gap-3">
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-4 flex flex-col gap-3 shadow-md">
            <div className="flex items-center justify-between border-b border-[#1e293b] pb-2">
              <div>
                <h3 className="font-bold text-sm text-white font-mono">Independent Quality Gatekeeper Suite</h3>
                <span className="text-xs text-slate-400 font-sans">
                  Automated validation verifying Trading, Backtesting, Data Feeds, and Risk engines.
                </span>
              </div>
              <button
                onClick={handleRunGatekeeper}
                disabled={isRunningAudit}
                className={`px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-mono font-bold text-xs rounded-xl shadow flex items-center gap-1.5 ${
                  isRunningAudit ? 'opacity-50' : ''
                }`}
              >
                <RotateCcw className={`w-3.5 h-3.5 ${isRunningAudit ? 'animate-spin' : ''}`} />
                <span>{isRunningAudit ? 'Executing...' : 'Run Audit'}</span>
              </button>
            </div>

            {gatekeeperReport ? (
              <div className="flex flex-col gap-3 pt-1">
                <div className="grid grid-cols-3 gap-2 text-xs font-mono bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b]">
                  <div>
                    <span className="text-slate-500 text-[10px] block">TOTAL TESTS</span>
                    <span className="text-white font-bold">{gatekeeperReport.totalTests}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[10px] block">PASSED</span>
                    <span className="text-emerald-400 font-bold">{gatekeeperReport.passedTests}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[10px] block">STATUS</span>
                    <span className="text-emerald-400 font-bold">{gatekeeperReport.overallRating}</span>
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  {gatekeeperReport.results.map(r => (
                    <div
                      key={r.id}
                      className="bg-[#090d16] border border-[#1e293b] rounded-lg p-2.5 flex flex-col gap-1 text-xs font-mono"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-slate-500 text-[10px]">{r.id}</span>
                          <span className="font-bold text-white">{r.name}</span>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          r.status === 'PASS' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-red-500/20 text-red-400'
                        }`}>
                          {r.status} ({r.executionTimeMs}ms)
                        </span>
                      </div>
                      <span className="text-slate-400 font-sans text-xs">{r.details}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="p-8 text-center text-xs text-slate-500 font-mono flex flex-col items-center gap-2">
                <ShieldCheck className="w-8 h-8 text-slate-600" />
                <span>Tap "Run Audit" to execute the full 11-category quality gatekeeper test suite.</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* SETTINGS & JSON BACKUP PERSISTENCE */}
      {/* ------------------------------------------------------------- */}
      {activeModule === 'SETTINGS' && (
        <div className="flex flex-col gap-3">
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-4 flex flex-col gap-3 shadow-md font-mono text-xs">
            <h3 className="font-bold text-sm text-white">PERSISTENCE & INSTITUTIONAL BACKUP</h3>
            <p className="text-slate-400 font-sans">
              Export and restore your accounts, orders, positions, signals, and journal entries in validated JSON format with cryptographic checksums.
            </p>

            {/* Complete Package Downloads (ZIP & Standalone HTML) */}
            <div className="pt-3 border-t border-[#1e293b] flex flex-col gap-2">
              <span className="font-bold text-white text-xs tracking-wider">COMPLETE PACKAGE DOWNLOADS</span>
              <p className="text-slate-400 font-sans text-[11px]">
                Download the complete executable project source code in a ZIP archive, or download the single-file standalone HTML version that runs offline anywhere.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {/* Project ZIP */}
                <div className="bg-[#090d16] p-3 rounded-xl border border-blue-500/30 flex flex-col justify-between gap-2">
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-blue-400 flex items-center gap-1.5">
                        <Archive className="w-4 h-4" />
                        <span>Project Source Code (.ZIP)</span>
                      </span>
                      <span className="text-[10px] text-slate-400">~128 KB</span>
                    </div>
                    <span className="text-slate-400 text-[10px] font-sans block mt-1">
                      Full repository package: server.ts, React 19 app, all 12 analytical modules, indicators, backtester, and tests.
                    </span>
                  </div>
                  <a
                    href="/api/download/zip"
                    download="fc-ai-advanced-v1.zip"
                    className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-bold flex items-center justify-center gap-1.5 shadow"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Project.zip</span>
                  </a>
                </div>

                {/* Standalone HTML */}
                <div className="bg-[#090d16] p-3 rounded-xl border border-purple-500/30 flex flex-col justify-between gap-2">
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-purple-400 flex items-center gap-1.5">
                        <FileCode className="w-4 h-4" />
                        <span>Standalone Single HTML</span>
                      </span>
                      <span className="text-[10px] text-slate-400">Single File</span>
                    </div>
                    <span className="text-slate-400 text-[10px] font-sans block mt-1">
                      Self-contained offline file with complete terminal, canvas charts, quantitative calculators, and paper engine. Double-click to run!
                    </span>
                  </div>
                  <a
                    href="/api/download/standalone-html"
                    download="fc-ai-advanced-standalone.html"
                    className="w-full py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-lg font-bold flex items-center justify-center gap-1.5 shadow"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Standalone.html</span>
                  </a>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="bg-[#090d16] p-3 rounded-xl border border-[#1e293b] flex flex-col gap-2">
                <span className="font-bold text-white">EXPORT TRADING DATABASE (JSON)</span>
                <span className="text-slate-500 text-[10px] font-sans">
                  Saves entire database snapshot v1.0.0 (accounts, orders, alerts, journal) to local JSON.
                </span>
                <button
                  onClick={handleExportBackup}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg font-bold flex items-center justify-center gap-1.5"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Backup.json</span>
                </button>
              </div>

              <div className="bg-[#090d16] p-3 rounded-xl border border-[#1e293b] flex flex-col gap-2">
                <span className="font-bold text-white">RESTORE TRADING DATABASE</span>
                <span className="text-slate-500 text-[10px] font-sans">
                  Validates schema, checksum, and restores state atomically.
                </span>
                <label className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg font-bold flex items-center justify-center gap-1.5 cursor-pointer">
                  <Upload className="w-4 h-4" />
                  <span>Select JSON File</span>
                  <input type="file" accept=".json" onChange={handleFileUpload} className="hidden" />
                </label>
              </div>
            </div>

            {importStatus && (
              <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg text-blue-300">
                {importStatus}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
