/**
 * FC AI ADVANCED - INTERACTIVE CANVAS CANDLESTICK & INDICATOR CHART
 * High performance canvas chart with crosshairs, zoom/pan, multi-timeframe switching,
 * overlays (EMA, SMA, Bollinger Bands, S&R), and sub-charts (Volume, RSI, MACD).
 */

import React, { useRef, useEffect, useState, useMemo } from 'react';
import { OHLCVCandle, Timeframe, TechnicalSummary } from '../types/market';
import {
  calculateSMA,
  calculateEMA,
  calculateRSI,
  calculateMACD,
  calculateBollingerBands,
} from '../lib/indicators';
import { ZoomIn, ZoomOut, Layers, RefreshCw } from 'lucide-react';

interface CandlestickChartProps {
  candles: OHLCVCandle[];
  symbol: string;
  timeframe: Timeframe;
  onTimeframeChange: (tf: Timeframe) => void;
  technicalSummary?: TechnicalSummary;
  pricePrecision?: number;
  onRefresh?: () => void;
  isLoading?: boolean;
}

export const CandlestickChart: React.FC<CandlestickChartProps> = ({
  candles,
  symbol,
  timeframe,
  onTimeframeChange,
  technicalSummary,
  pricePrecision = 2,
  onRefresh,
  isLoading = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Viewport window state (indexes in candles array)
  const [visibleCount, setVisibleCount] = useState<number>(45);
  const [scrollOffset, setScrollOffset] = useState<number>(0); // 0 = latest

  // Overlay toggles
  const [showEMA, setShowEMA] = useState(true);
  const [showBB, setShowBB] = useState(false);
  const [showSR, setShowSR] = useState(true);
  const [subChart, setSubChart] = useState<'VOLUME' | 'RSI' | 'MACD'>('VOLUME');

  // Crosshair state
  const [crosshair, setCrosshair] = useState<{ x: number; y: number; candleIndex: number } | null>(null);

  // Timeframes list
  const timeframes: Timeframe[] = ['1m', '5m', '15m', '30m', '1H', '4H', '1D', '1W'];

  // Calculate indicator overlays over the whole dataset
  const indicatorSeries = useMemo(() => {
    if (candles.length === 0) return null;
    const closes = candles.map(c => c.close);
    return {
      ema9: calculateEMA(closes, 9),
      ema21: calculateEMA(closes, 21),
      sma50: calculateSMA(closes, Math.min(50, closes.length)),
      bb: calculateBollingerBands(closes, 20, 2),
      rsi: calculateRSI(closes, 14),
      macd: calculateMACD(closes, 12, 26, 9),
    };
  }, [candles]);

  // Handle Zoom
  const handleZoom = (direction: 'in' | 'out') => {
    setVisibleCount(prev => {
      const next = direction === 'in' ? Math.max(15, prev - 8) : Math.min(candles.length, prev + 8);
      return next;
    });
  };

  // Drag / Pan interaction
  const isDraggingRef = useRef(false);
  const dragStartRef = useRef<{ x: number; offset: number }>({ x: 0, offset: 0 });

  const handlePointerDown = (e: React.PointerEvent) => {
    isDraggingRef.current = true;
    dragStartRef.current = { x: e.clientX, offset: scrollOffset };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!canvasRef.current || candles.length === 0) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (isDraggingRef.current) {
      const deltaX = e.clientX - dragStartRef.current.x;
      const barWidth = rect.width / visibleCount;
      const barsMoved = Math.round(deltaX / barWidth);
      const maxOffset = Math.max(0, candles.length - visibleCount);
      const newOffset = Math.max(0, Math.min(maxOffset, dragStartRef.current.offset + barsMoved));
      setScrollOffset(newOffset);
    } else {
      // Find hovered candle
      const chartWidth = rect.width - 60; // right margin for price scale
      if (x >= 0 && x <= chartWidth) {
        const barWidth = chartWidth / visibleCount;
        const relativeIdx = Math.floor(x / barWidth);
        const startIndex = Math.max(0, candles.length - visibleCount - scrollOffset);
        const candleIdx = Math.min(candles.length - 1, startIndex + relativeIdx);
        setCrosshair({ x, y, candleIndex: candleIdx });
      } else {
        setCrosshair(null);
      }
    }
  };

  const handlePointerUp = () => {
    isDraggingRef.current = false;
  };

  const handlePointerLeave = () => {
    isDraggingRef.current = false;
    setCrosshair(null);
  };

  // Render Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || candles.length === 0) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);

    // Clear
    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, width, height);

    // Layout
    const priceScaleWidth = 64;
    const mainChartHeight = subChart === 'VOLUME' ? height * 0.76 : height * 0.70;
    const subChartHeight = height - mainChartHeight - 24; // 24px bottom time axis
    const chartWidth = width - priceScaleWidth;

    // Window slice
    const startIndex = Math.max(0, candles.length - visibleCount - scrollOffset);
    const endIndex = Math.min(candles.length, startIndex + visibleCount);
    const visibleCandles = candles.slice(startIndex, endIndex);

    if (visibleCandles.length === 0) return;

    // Determine Min & Max price in visible range
    let minPrice = Infinity;
    let maxPrice = -Infinity;
    let maxVolume = 0;

    for (const c of visibleCandles) {
      if (c.low < minPrice) minPrice = c.low;
      if (c.high > maxPrice) maxPrice = c.high;
      if (c.volume > maxVolume) maxVolume = c.volume;
    }

    // Include Bollinger Bands in price bounds if toggled
    if (showBB && indicatorSeries?.bb) {
      for (let i = startIndex; i < endIndex; i++) {
        const item = indicatorSeries.bb[i];
        if (item?.upper && item.upper > maxPrice) maxPrice = item.upper;
        if (item?.lower && item.lower < minPrice) minPrice = item.lower;
      }
    }

    // Add padding (4%)
    const priceRange = maxPrice - minPrice || 1;
    minPrice -= priceRange * 0.04;
    maxPrice += priceRange * 0.04;
    const paddedRange = maxPrice - minPrice;

    // Helper coordinate converters
    const getX = (indexWithinVisible: number) => {
      const barWidth = chartWidth / visibleCandles.length;
      return indexWithinVisible * barWidth + barWidth / 2;
    };

    const getY = (price: number) => {
      return mainChartHeight - ((price - minPrice) / paddedRange) * mainChartHeight;
    };

    // Draw Price Grid lines (horizontal)
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    ctx.fillStyle = '#64748b';
    ctx.font = '10px ui-monospace, SFMono-Regular, monospace';
    ctx.textAlign = 'left';

    const gridSteps = 5;
    for (let i = 0; i <= gridSteps; i++) {
      const p = minPrice + (paddedRange / gridSteps) * i;
      const y = getY(p);

      ctx.beginPath();
      ctx.setLineDash([2, 4]);
      ctx.moveTo(0, y);
      ctx.lineTo(chartWidth, y);
      ctx.stroke();

      // Price label on right scale
      ctx.setLineDash([]);
      ctx.fillText(p.toFixed(pricePrecision), chartWidth + 6, y + 3);
    }

    // Draw Vertical Time Grid lines
    const timeStep = Math.max(1, Math.floor(visibleCandles.length / 5));
    for (let i = 0; i < visibleCandles.length; i += timeStep) {
      const x = getX(i);
      ctx.beginPath();
      ctx.setLineDash([2, 4]);
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height - 20);
      ctx.stroke();

      // Timestamp label
      const d = new Date(visibleCandles[i].timestamp);
      const timeStr = timeframe === '1D' || timeframe === '1W'
        ? `${d.getMonth() + 1}/${d.getDate()}`
        : `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;

      ctx.setLineDash([]);
      ctx.textAlign = 'center';
      ctx.fillText(timeStr, x, height - 6);
    }

    // Draw Support & Resistance levels if toggled
    if (showSR && technicalSummary) {
      // Supports in emerald
      technicalSummary.supportLevels.forEach(lvl => {
        if (lvl >= minPrice && lvl <= maxPrice) {
          const y = getY(lvl);
          ctx.strokeStyle = 'rgba(16, 185, 129, 0.45)';
          ctx.setLineDash([4, 4]);
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(chartWidth, y);
          ctx.stroke();
          ctx.fillStyle = '#10b981';
          ctx.textAlign = 'right';
          ctx.fillText(`Sup ${lvl.toFixed(pricePrecision)}`, chartWidth - 8, y - 4);
        }
      });
      // Resistances in crimson
      technicalSummary.resistanceLevels.forEach(lvl => {
        if (lvl >= minPrice && lvl <= maxPrice) {
          const y = getY(lvl);
          ctx.strokeStyle = 'rgba(239, 68, 68, 0.45)';
          ctx.setLineDash([4, 4]);
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(chartWidth, y);
          ctx.stroke();
          ctx.fillStyle = '#ef4444';
          ctx.textAlign = 'right';
          ctx.fillText(`Res ${lvl.toFixed(pricePrecision)}`, chartWidth - 8, y - 4);
        }
      });
      ctx.setLineDash([]);
    }

    // Draw Bollinger Bands if enabled
    if (showBB && indicatorSeries?.bb) {
      ctx.strokeStyle = 'rgba(59, 130, 246, 0.4)';
      ctx.fillStyle = 'rgba(59, 130, 246, 0.05)';
      ctx.lineWidth = 1;

      // Draw band shade
      ctx.beginPath();
      for (let i = 0; i < visibleCandles.length; i++) {
        const fullIdx = startIndex + i;
        const bb = indicatorSeries.bb[fullIdx];
        if (bb?.upper) {
          const x = getX(i);
          const yUpper = getY(bb.upper);
          if (i === 0) ctx.moveTo(x, yUpper);
          else ctx.lineTo(x, yUpper);
        }
      }
      for (let i = visibleCandles.length - 1; i >= 0; i--) {
        const fullIdx = startIndex + i;
        const bb = indicatorSeries.bb[fullIdx];
        if (bb?.lower) {
          const x = getX(i);
          const yLower = getY(bb.lower);
          ctx.lineTo(x, yLower);
        }
      }
      ctx.closePath();
      ctx.fill();

      // Middle line (SMA 20)
      ctx.strokeStyle = 'rgba(59, 130, 246, 0.7)';
      ctx.beginPath();
      for (let i = 0; i < visibleCandles.length; i++) {
        const fullIdx = startIndex + i;
        const bb = indicatorSeries.bb[fullIdx];
        if (bb?.middle) {
          const x = getX(i);
          const y = getY(bb.middle);
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
      }
      ctx.stroke();
    }

    // Draw EMA 9 (Amber) and EMA 21 (Violet)
    if (showEMA && indicatorSeries) {
      // EMA 9
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      let started = false;
      for (let i = 0; i < visibleCandles.length; i++) {
        const val = indicatorSeries.ema9[startIndex + i];
        if (val !== null) {
          const x = getX(i);
          const y = getY(val);
          if (!started) {
            ctx.moveTo(x, y);
            started = true;
          } else {
            ctx.lineTo(x, y);
          }
        }
      }
      ctx.stroke();

      // EMA 21
      ctx.strokeStyle = '#8b5cf6';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      started = false;
      for (let i = 0; i < visibleCandles.length; i++) {
        const val = indicatorSeries.ema21[startIndex + i];
        if (val !== null) {
          const x = getX(i);
          const y = getY(val);
          if (!started) {
            ctx.moveTo(x, y);
            started = true;
          } else {
            ctx.lineTo(x, y);
          }
        }
      }
      ctx.stroke();
    }

    // Draw Candlesticks
    const barWidth = chartWidth / visibleCandles.length;
    const bodyWidth = Math.max(2, barWidth * 0.72);

    for (let i = 0; i < visibleCandles.length; i++) {
      const c = visibleCandles[i];
      const x = getX(i);
      const isBull = c.close >= c.open;
      const color = isBull ? '#10b981' : '#ef4444';

      const yOpen = getY(c.open);
      const yClose = getY(c.close);
      const yHigh = getY(c.high);
      const yLow = getY(c.low);

      // Wick
      ctx.strokeStyle = color;
      ctx.lineWidth = Math.max(1, bodyWidth > 8 ? 1.5 : 1);
      ctx.beginPath();
      ctx.moveTo(x, yHigh);
      ctx.lineTo(x, yLow);
      ctx.stroke();

      // Body
      const bodyTop = Math.min(yOpen, yClose);
      const bodyHeight = Math.max(1.5, Math.abs(yClose - yOpen));
      ctx.fillStyle = color;
      ctx.fillRect(x - bodyWidth / 2, bodyTop, bodyWidth, bodyHeight);
    }

    // -------------------------------------------------------------
    // Draw Sub-chart (Volume / RSI / MACD)
    // -------------------------------------------------------------
    const subChartTop = mainChartHeight + 4;
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, subChartTop);
    ctx.lineTo(width, subChartTop);
    ctx.stroke();

    if (subChart === 'VOLUME') {
      const maxVol = maxVolume || 1;
      for (let i = 0; i < visibleCandles.length; i++) {
        const c = visibleCandles[i];
        const x = getX(i);
        const barH = (c.volume / maxVol) * subChartHeight * 0.9;
        const y = subChartTop + subChartHeight - barH;
        ctx.fillStyle = c.close >= c.open ? 'rgba(16, 185, 129, 0.4)' : 'rgba(239, 68, 68, 0.4)';
        ctx.fillRect(x - bodyWidth / 2, y, bodyWidth, barH);
      }
      ctx.fillStyle = '#64748b';
      ctx.textAlign = 'left';
      ctx.fillText(`VOL (max: ${Math.round(maxVol).toLocaleString()})`, 8, subChartTop + 14);
    } else if (subChart === 'RSI' && indicatorSeries?.rsi) {
      // 70 & 30 Reference lines
      const getRsiY = (val: number) => subChartTop + subChartHeight - (val / 100) * subChartHeight;
      const y70 = getRsiY(70);
      const y30 = getRsiY(30);

      ctx.strokeStyle = 'rgba(239, 68, 68, 0.35)';
      ctx.setLineDash([2, 4]);
      ctx.beginPath();
      ctx.moveTo(0, y70);
      ctx.lineTo(chartWidth, y70);
      ctx.stroke();

      ctx.strokeStyle = 'rgba(16, 185, 129, 0.35)';
      ctx.beginPath();
      ctx.moveTo(0, y30);
      ctx.lineTo(chartWidth, y30);
      ctx.stroke();
      ctx.setLineDash([]);

      // RSI Curve
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      let started = false;
      for (let i = 0; i < visibleCandles.length; i++) {
        const val = indicatorSeries.rsi[startIndex + i];
        if (val !== null) {
          const x = getX(i);
          const y = getRsiY(val);
          if (!started) {
            ctx.moveTo(x, y);
            started = true;
          } else {
            ctx.lineTo(x, y);
          }
        }
      }
      ctx.stroke();

      const latestRsi = indicatorSeries.rsi[endIndex - 1] ?? 50;
      ctx.fillStyle = '#38bdf8';
      ctx.textAlign = 'left';
      ctx.fillText(`RSI(14): ${latestRsi.toFixed(1)}`, 8, subChartTop + 14);
    } else if (subChart === 'MACD' && indicatorSeries?.macd) {
      // Zero line
      const zeroY = subChartTop + subChartHeight / 2;
      ctx.strokeStyle = '#334155';
      ctx.beginPath();
      ctx.moveTo(0, zeroY);
      ctx.lineTo(chartWidth, zeroY);
      ctx.stroke();

      // MACD Histogram & Lines
      for (let i = 0; i < visibleCandles.length; i++) {
        const pt = indicatorSeries.macd[startIndex + i];
        if (pt?.histogram !== null) {
          const x = getX(i);
          const histH = Math.min(subChartHeight / 2, (pt.histogram / (priceRange * 0.05 || 1)) * (subChartHeight / 2));
          ctx.fillStyle = pt.histogram >= 0 ? '#10b981' : '#ef4444';
          ctx.fillRect(x - bodyWidth / 3, pt.histogram >= 0 ? zeroY - histH : zeroY, bodyWidth * 0.66, Math.abs(histH));
        }
      }
      ctx.fillStyle = '#f59e0b';
      ctx.textAlign = 'left';
      ctx.fillText(`MACD (12, 26, 9)`, 8, subChartTop + 14);
    }

    // -------------------------------------------------------------
    // Draw Crosshair & Floating Tooltip
    // -------------------------------------------------------------
    if (crosshair && crosshair.candleIndex >= 0 && crosshair.candleIndex < candles.length) {
      const activeCandle = candles[crosshair.candleIndex];
      const cx = crosshair.x;
      const cy = crosshair.y;

      ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);

      // Vertical line
      ctx.beginPath();
      ctx.moveTo(cx, 0);
      ctx.lineTo(cx, height - 20);
      ctx.stroke();

      // Horizontal line
      ctx.beginPath();
      ctx.moveTo(0, cy);
      ctx.lineTo(chartWidth, cy);
      ctx.stroke();
      ctx.setLineDash([]);

      // Tooltip price at cy
      const priceAtY = maxPrice - (cy / mainChartHeight) * paddedRange;
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(chartWidth + 2, cy - 9, priceScaleWidth - 4, 18);
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'left';
      ctx.fillText(priceAtY.toFixed(pricePrecision), chartWidth + 5, cy + 4);

      // OHLCV Header Box
      ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
      ctx.fillRect(6, 6, 280, 22);
      ctx.fillStyle = '#94a3b8';
      ctx.textAlign = 'left';
      const ohlcText = `O:${activeCandle.open} H:${activeCandle.high} L:${activeCandle.low} C:${activeCandle.close}`;
      ctx.fillText(ohlcText, 12, 21);
    }
  }, [
    candles,
    visibleCount,
    scrollOffset,
    showEMA,
    showBB,
    showSR,
    subChart,
    crosshair,
    indicatorSeries,
    timeframe,
    pricePrecision,
    technicalSummary,
  ]);

  const latestCandle = candles[candles.length - 1];
  const prevCandle = candles[candles.length - 2];
  const priceChange = latestCandle && prevCandle ? latestCandle.close - prevCandle.close : 0;
  const priceChangePct = prevCandle && prevCandle.close ? (priceChange / prevCandle.close) * 100 : 0;

  return (
    <div className="flex flex-col w-full bg-[#090d16] border border-[#1e293b] rounded-xl overflow-hidden shadow-2xl">
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between px-3 py-2.5 bg-[#0f172a] border-b border-[#1e293b] gap-2">
        <div className="flex items-center gap-2">
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-white text-base tracking-wide">{symbol}</span>
              <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                {timeframe}
              </span>
            </div>
            {latestCandle && (
              <div className="flex items-center gap-2 text-xs font-mono-num">
                <span className="text-white font-semibold text-sm">
                  {latestCandle.close.toFixed(pricePrecision)}
                </span>
                <span className={priceChange >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                  {priceChange >= 0 ? '+' : ''}{priceChange.toFixed(pricePrecision)} ({priceChangePct >= 0 ? '+' : ''}{priceChangePct.toFixed(2)}%)
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Timeframe selector bar */}
        <div className="flex items-center gap-1 bg-[#090d16] p-0.5 rounded-lg border border-[#1e293b]">
          {timeframes.map(tf => (
            <button
              key={tf}
              onClick={() => onTimeframeChange(tf)}
              className={`px-2 py-1 text-xs font-mono font-medium rounded transition-all ${
                timeframe === tf
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>

        {/* Chart Controls & Indicator toggles */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setShowEMA(!showEMA)}
            className={`px-2 py-1 text-[11px] font-mono rounded border transition-colors ${
              showEMA ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'text-slate-400 border-[#1e293b] hover:bg-slate-800'
            }`}
            title="Toggle EMA 9 & EMA 21"
          >
            EMA
          </button>
          <button
            onClick={() => setShowBB(!showBB)}
            className={`px-2 py-1 text-[11px] font-mono rounded border transition-colors ${
              showBB ? 'bg-blue-500/20 text-blue-300 border-blue-500/40' : 'text-slate-400 border-[#1e293b] hover:bg-slate-800'
            }`}
            title="Toggle Bollinger Bands"
          >
            BB
          </button>
          <button
            onClick={() => setShowSR(!showSR)}
            className={`px-2 py-1 text-[11px] font-mono rounded border transition-colors ${
              showSR ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'text-slate-400 border-[#1e293b] hover:bg-slate-800'
            }`}
            title="Toggle Support / Resistance"
          >
            S/R
          </button>
          <div className="h-4 w-[1px] bg-[#1e293b] mx-0.5" />
          <button
            onClick={() => handleZoom('in')}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => handleZoom('out')}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          {onRefresh && (
            <button
              onClick={onRefresh}
              disabled={isLoading}
              className={`p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded ${isLoading ? 'animate-spin text-blue-400' : ''}`}
              title="Refresh Market Feed"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Canvas container */}
      <div
        ref={containerRef}
        className="relative w-full h-[360px] sm:h-[420px] select-none cursor-crosshair touch-none"
      >
        <canvas
          ref={canvasRef}
          className="w-full h-full block"
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerLeave}
        />

        {/* Sub-chart toggle pill in bottom corner */}
        <div className="absolute bottom-6 left-2 flex items-center bg-[#090d16]/80 backdrop-blur border border-[#1e293b] rounded-md p-0.5 text-[10px] font-mono">
          {(['VOLUME', 'RSI', 'MACD'] as const).map(mode => (
            <button
              key={mode}
              onClick={() => setSubChart(mode)}
              className={`px-2 py-0.5 rounded ${subChart === mode ? 'bg-blue-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
