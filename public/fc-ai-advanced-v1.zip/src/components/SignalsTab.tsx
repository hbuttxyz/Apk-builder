/**
 * FC AI ADVANCED - SIGNALS INTELLIGENCE (MODULES 01, 08, 10)
 * Multi-Timeframe Consensus Engine (Module 08), Ranked AI Trading Ideas (Module 01),
 * and Permanent Signal Verification Tracker (Module 10).
 */

import React, { useState } from 'react';
import {
  TradeIdea,
  MultiTimeframeRow,
  SignalOutcomeRecord,
  Timeframe,
  MarketQuote,
} from '../types/market';
import { INSTRUMENT_CATALOG } from '../lib/instruments';
import {
  Activity,
  Layers,
  Sparkles,
  CheckCircle,
  XCircle,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Filter,
  BarChart2,
  RefreshCw,
  ExternalLink,
} from 'lucide-react';

interface SignalsTabProps {
  selectedSymbol: string;
  onSelectSymbol: (symbol: string) => void;
  currentQuote?: MarketQuote;
  multiTimeframeMatrix: MultiTimeframeRow[];
  tradeIdeas: TradeIdea[];
  signalRecords: SignalOutcomeRecord[];
  onTimeframeSelect: (tf: Timeframe) => void;
  onNavigateToTrade: (symbol: string, direction?: 'BUY' | 'SELL', entry?: number, sl?: number, tp?: number) => void;
  onGenerateIdeas: () => void;
  isGeneratingIdeas: boolean;
}

export const SignalsTab: React.FC<SignalsTabProps> = ({
  selectedSymbol,
  onSelectSymbol,
  currentQuote,
  multiTimeframeMatrix,
  tradeIdeas,
  signalRecords,
  onTimeframeSelect,
  onNavigateToTrade,
  onGenerateIdeas,
  isGeneratingIdeas,
}) => {
  const [activeView, setActiveView] = useState<'IDEAS' | 'MTF_CONSENSUS' | 'VERIFIER'>('MTF_CONSENSUS');
  const [ideasFilter, setIdeasFilter] = useState<'ALL' | 'BULLISH' | 'BEARISH'>('ALL');

  const filteredIdeas = tradeIdeas.filter(idea => {
    if (ideasFilter === 'ALL') return true;
    return idea.direction === ideasFilter;
  });

  // Calculate MTF alignment metrics
  const bullCount = multiTimeframeMatrix.filter(r => r.direction === 'BUY').length;
  const bearCount = multiTimeframeMatrix.filter(r => r.direction === 'SELL').length;
  const totalCount = multiTimeframeMatrix.length || 1;
  const agreementScore = Math.round((Math.max(bullCount, bearCount) / totalCount) * 100);
  const dominantDirection = bullCount > bearCount ? 'BULLISH' : bearCount > bullCount ? 'BEARISH' : 'CONFLICTED';

  // Verifier stats (Module 10)
  const resolvedSignals = signalRecords.filter(s => s.status !== 'PENDING_ENTRY' && s.status !== 'ACTIVE');
  const winSignals = signalRecords.filter(s => s.status === 'HIT_TP1' || s.status === 'HIT_TP2');
  const signalWinRate = resolvedSignals.length > 0 ? (winSignals.length / resolvedSignals.length) * 100 : 0;
  const avgMFE = signalRecords.length > 0 ? signalRecords.reduce((sum, s) => sum + s.maxFavorableExcursionPercent, 0) / signalRecords.length : 0;
  const avgMAE = signalRecords.length > 0 ? signalRecords.reduce((sum, s) => sum + s.maxAdverseExcursionPercent, 0) / signalRecords.length : 0;

  return (
    <div className="flex flex-col gap-4 pb-20 pt-2 px-3 max-w-7xl mx-auto">
      {/* Top Selector Strip */}
      <div className="flex items-center gap-1 bg-[#0f172a] p-1 rounded-xl border border-[#1e293b] text-xs font-mono">
        <button
          onClick={() => setActiveView('MTF_CONSENSUS')}
          className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1 transition-all ${
            activeView === 'MTF_CONSENSUS' ? 'bg-blue-600 text-white font-semibold shadow' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>MTF Consensus (Mod 08)</span>
        </button>
        <button
          onClick={() => setActiveView('IDEAS')}
          className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1 transition-all ${
            activeView === 'IDEAS' ? 'bg-blue-600 text-white font-semibold shadow' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Trading Ideas (Mod 01)</span>
        </button>
        <button
          onClick={() => setActiveView('VERIFIER')}
          className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1 transition-all ${
            activeView === 'VERIFIER' ? 'bg-blue-600 text-white font-semibold shadow' : 'text-slate-400 hover:text-white'
          }`}
        >
          <BarChart2 className="w-3.5 h-3.5" />
          <span>Outcome Verifier (Mod 10)</span>
        </button>
      </div>

      {/* VIEW 1: MODULE 08 - MULTI-TIMEFRAME CONSENSUS MATRIX */}
      {activeView === 'MTF_CONSENSUS' && (
        <div className="flex flex-col gap-3">
          {/* Header Summary Card */}
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-4 flex flex-col gap-2.5 shadow-md">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#1e293b] pb-2">
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-white text-base">{selectedSymbol}</span>
                <span className="text-xs font-mono text-slate-400">
                  Current Reference Price:{' '}
                  <strong className="text-white font-mono-num font-bold">
                    {currentQuote ? currentQuote.lastPrice : '---'}
                  </strong>
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs font-mono">
                <span className="text-slate-400">Agreement Score:</span>
                <span className="font-bold text-blue-400">{agreementScore}%</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  dominantDirection === 'BULLISH' ? 'bg-emerald-500/20 text-emerald-400' : dominantDirection === 'BEARISH' ? 'bg-red-500/20 text-red-400' : 'bg-slate-700 text-slate-300'
                }`}>
                  {dominantDirection}
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              Evaluates cross-timeframe agreement from 1-minute to 1-week candle closures. Lower timeframes provide early entry timing, while higher timeframes (4H, 1D, 1W) dictate institutional macro trend regime. Tap any timeframe row to inspect its chart.
            </p>
          </div>

          {/* Matrix Table */}
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl overflow-hidden shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-[#090d16] text-slate-400 text-[10px] uppercase border-b border-[#1e293b]">
                  <tr>
                    <th className="px-3 py-2.5">Timeframe</th>
                    <th className="px-3 py-2.5">Direction</th>
                    <th className="px-3 py-2.5">Trend</th>
                    <th className="px-3 py-2.5">Momentum</th>
                    <th className="px-3 py-2.5">Signal State</th>
                    <th className="px-3 py-2.5">RSI</th>
                    <th className="px-3 py-2.5 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1e293b]">
                  {multiTimeframeMatrix.map((row) => {
                    const isBuy = row.direction === 'BUY';
                    const isSell = row.direction === 'SELL';

                    return (
                      <tr
                        key={row.timeframe}
                        className="hover:bg-[#162038] transition-colors cursor-pointer"
                        onClick={() => onTimeframeSelect(row.timeframe)}
                      >
                        <td className="px-3 py-3 font-bold text-white flex items-center gap-1.5">
                          <span className="text-blue-400 font-mono">{row.timeframe}</span>
                        </td>
                        <td className="px-3 py-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            isBuy ? 'bg-emerald-500/20 text-emerald-400' : isSell ? 'bg-red-500/20 text-red-400' : 'bg-slate-800 text-slate-300'
                          }`}>
                            {row.direction}
                          </span>
                        </td>
                        <td className="px-3 py-3">
                          <span className={row.trend === 'UPTREND' ? 'text-emerald-400' : row.trend === 'DOWNTREND' ? 'text-red-400' : 'text-slate-400'}>
                            {row.trend}
                          </span>
                        </td>
                        <td className="px-3 py-3 text-slate-300">
                          {row.momentum.replace('_', ' ')}
                        </td>
                        <td className="px-3 py-3">
                          <span className={`text-[10px] px-1.5 py-0.2 rounded border ${
                            row.signalState === 'CONFIRMED'
                              ? 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                              : 'bg-slate-800 text-slate-400 border-slate-700'
                          }`}>
                            {row.signalState}
                          </span>
                        </td>
                        <td className="px-3 py-3 font-mono-num font-semibold text-slate-200">
                          {row.rsi.toFixed(1)}
                        </td>
                        <td className="px-3 py-3 text-right">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onNavigateToTrade(selectedSymbol, isBuy ? 'BUY' : 'SELL');
                            }}
                            className="px-2 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded text-[10px] font-bold"
                          >
                            Trade
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: MODULE 01 - RANKED AI TRADING IDEAS */}
      {activeView === 'IDEAS' && (
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            {/* Filter pills */}
            <div className="flex items-center gap-1 bg-[#0f172a] p-1 rounded-lg border border-[#1e293b] text-xs font-mono">
              {(['ALL', 'BULLISH', 'BEARISH'] as const).map(f => (
                <button
                  key={f}
                  onClick={() => setIdeasFilter(f)}
                  className={`px-3 py-1 rounded capitalize ${
                    ideasFilter === f ? 'bg-blue-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>

            <button
              onClick={onGenerateIdeas}
              disabled={isGeneratingIdeas}
              className={`px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-bold font-mono flex items-center gap-1.5 shadow ${
                isGeneratingIdeas ? 'opacity-60 cursor-not-allowed' : ''
              }`}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isGeneratingIdeas ? 'animate-spin' : ''}`} />
              <span>{isGeneratingIdeas ? 'Evaluating...' : 'Scan Setups'}</span>
            </button>
          </div>

          <div className="flex flex-col gap-3">
            {filteredIdeas.map((idea, idx) => {
              const isBull = idea.direction === 'BULLISH';
              return (
                <div
                  key={idea.id}
                  className="bg-[#0f172a] border border-[#1e293b] hover:border-purple-500/30 rounded-xl p-4 flex flex-col gap-3 shadow-md"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-slate-500">#{idx + 1}</span>
                      <span className="font-extrabold text-base text-white">{idea.symbol}</span>
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                        isBull ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-red-500/20 text-red-400 border border-red-500/30'
                      }`}>
                        {idea.direction}
                      </span>
                      <span className="text-xs font-mono text-blue-400">{idea.timeframe}</span>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] font-mono text-purple-400 block font-semibold">Rank Score</span>
                      <span className="text-sm font-extrabold text-white font-mono-num">{idea.rankScore}/100</span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed font-sans">
                    {idea.explanation}
                  </p>

                  {/* Quantitative Execution Zone */}
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 bg-[#090d16] p-2.5 rounded-lg border border-[#1e293b] text-xs font-mono">
                    <div>
                      <span className="text-slate-500 text-[10px] block">ENTRY ZONE</span>
                      <span className="text-white font-bold">{idea.entryZone.min} - {idea.entryZone.max}</span>
                    </div>
                    <div>
                      <span className="text-red-400 text-[10px] block">STOP LOSS</span>
                      <span className="text-red-300 font-bold">{idea.stopLoss}</span>
                    </div>
                    <div>
                      <span className="text-emerald-400 text-[10px] block">TARGET 1 / 2 / 3</span>
                      <span className="text-emerald-300 font-bold">{idea.target1} / {idea.target2}</span>
                    </div>
                    <div>
                      <span className="text-blue-400 text-[10px] block">RISK / REWARD</span>
                      <span className="text-blue-300 font-bold">{idea.riskRewardRatio.toFixed(2)}:1</span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] block">FRESHNESS</span>
                      <span className="text-slate-300 text-[10px]">Attributable</span>
                    </div>
                  </div>

                  {/* Fundamentals & Invalidation */}
                  <div className="flex flex-col gap-1 text-xs text-slate-400 font-mono bg-[#090d16]/50 p-2 rounded">
                    <div>
                      <strong className="text-slate-300">Drivers:</strong> {idea.fundamentalDrivers.join(' • ')}
                    </div>
                    <div className="text-amber-400/90">
                      <strong>Invalidation Condition:</strong> {idea.invalidationCondition}
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      onClick={() => onSelectSymbol(idea.symbol)}
                      className="px-3 py-1.5 bg-[#090d16] hover:bg-slate-800 text-slate-300 border border-[#1e293b] rounded-lg text-xs font-mono font-medium"
                    >
                      View Chart
                    </button>
                    <button
                      onClick={() => onNavigateToTrade(
                        idea.symbol,
                        idea.direction === 'BULLISH' ? 'BUY' : 'SELL',
                        idea.entryZone.min,
                        idea.stopLoss,
                        idea.target1
                      )}
                      className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold font-mono shadow"
                    >
                      Preload in Order Pad
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW 3: MODULE 10 - PERMANENT SIGNAL OUTCOME VERIFIER */}
      {activeView === 'VERIFIER' && (
        <div className="flex flex-col gap-3">
          {/* Objective Metrics Summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
            <div className="bg-[#0f172a] p-3 rounded-xl border border-[#1e293b]">
              <span className="text-slate-400 text-[10px] block">SIGNALS TRACKED</span>
              <span className="text-lg font-bold text-white font-mono-num">{signalRecords.length}</span>
            </div>
            <div className="bg-[#0f172a] p-3 rounded-xl border border-[#1e293b]">
              <span className="text-slate-400 text-[10px] block">OBJECTIVE WIN RATE</span>
              <span className="text-lg font-bold text-emerald-400 font-mono-num">
                {signalWinRate.toFixed(1)}%
              </span>
            </div>
            <div className="bg-[#0f172a] p-3 rounded-xl border border-[#1e293b]">
              <span className="text-slate-400 text-[10px] block">AVG MAX FAVORABLE (MFE)</span>
              <span className="text-lg font-bold text-blue-400 font-mono-num">+{avgMFE.toFixed(2)}%</span>
            </div>
            <div className="bg-[#0f172a] p-3 rounded-xl border border-[#1e293b]">
              <span className="text-slate-400 text-[10px] block">AVG ADVERSE (MAE)</span>
              <span className="text-lg font-bold text-red-400 font-mono-num">-{avgMAE.toFixed(2)}%</span>
            </div>
          </div>

          {/* Signals Ledger */}
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl overflow-hidden shadow-md">
            <div className="p-3 border-b border-[#1e293b] flex items-center justify-between">
              <span className="font-bold text-xs text-white font-mono">PERMANENT OUTCOME AUDIT TRAIL</span>
              <span className="text-[10px] text-slate-500 font-mono">Anti-Survivorship Bias Engine</span>
            </div>

            <div className="divide-y divide-[#1e293b] max-h-[480px] overflow-y-auto">
              {signalRecords.map(rec => {
                const isWon = rec.status === 'HIT_TP1' || rec.status === 'HIT_TP2';
                const isLost = rec.status === 'HIT_SL';

                return (
                  <div key={rec.id} className="p-3 flex flex-col gap-1.5 hover:bg-[#162038]/50 text-xs font-mono">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white">{rec.symbol}</span>
                        <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                          rec.direction === 'BUY' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                        }`}>
                          {rec.direction}
                        </span>
                        <span className="text-slate-400 text-[10px]">{rec.timeframe}</span>
                        <span className="text-slate-500 text-[10px]">{rec.strategyVersion}</span>
                      </div>

                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        isWon ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                        isLost ? 'bg-red-500/20 text-red-400 border border-red-500/30' :
                        'bg-blue-500/20 text-blue-400'
                      }`}>
                        {rec.status.replace('_', ' ')}
                      </span>
                    </div>

                    <div className="grid grid-cols-4 gap-2 text-[11px] text-slate-400 bg-[#090d16] p-2 rounded">
                      <div>
                        <span className="text-slate-500 text-[9px] block">ENTRY</span>
                        <span className="text-slate-200">{rec.proposedEntry}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[9px] block">MFE (Peak gain)</span>
                        <span className="text-emerald-400">+{rec.maxFavorableExcursionPercent.toFixed(2)}%</span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[9px] block">MAE (Max draw)</span>
                        <span className="text-red-400">-{rec.maxAdverseExcursionPercent.toFixed(2)}%</span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[9px] block">NET THEORETICAL</span>
                        <span className={rec.netTheoreticalReturnPercent >= 0 ? 'text-emerald-400 font-bold' : 'text-red-400 font-bold'}>
                          {rec.netTheoreticalReturnPercent >= 0 ? '+' : ''}{rec.netTheoreticalReturnPercent.toFixed(2)}%
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-500">
                      <span>Provenance: {rec.dataProvenance}</span>
                      <span>{new Date(rec.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
