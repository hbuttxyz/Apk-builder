/**
 * FC AI ADVANCED - HOME DASHBOARD
 * Portfolio Equity, Market Health, Top Ranked Setups, Open Positions, and Daily Risk Limits.
 */

import React from 'react';
import {
  PaperAccount,
  PaperPosition,
  TradeIdea,
  MarketQuote,
  SafetySettings,
} from '../types/market';
import { INSTRUMENT_CATALOG } from '../lib/instruments';
import {
  TrendingUp,
  TrendingDown,
  ShieldAlert,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  Layers,
  ChevronRight,
  Clock,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

interface HomeTabProps {
  account: PaperAccount;
  openPositions: PaperPosition[];
  quotes: Record<string, MarketQuote>;
  tradeIdeas: TradeIdea[];
  safetySettings: SafetySettings;
  onNavigateToMarket: (symbol: string) => void;
  onNavigateToTrade: (symbol?: string) => void;
  onNavigateToSignals: () => void;
  onNavigateToPortfolio: () => void;
  onClosePosition: (posId: string) => void;
}

export const HomeTab: React.FC<HomeTabProps> = ({
  account,
  openPositions,
  quotes,
  tradeIdeas,
  safetySettings,
  onNavigateToMarket,
  onNavigateToTrade,
  onNavigateToSignals,
  onNavigateToPortfolio,
  onClosePosition,
}) => {
  const isProfit = account.totalUnrealizedPnL >= 0;
  const todayLoss = -Math.min(0, account.totalRealizedPnL);
  const lossAllowanceRemaining = Math.max(0, safetySettings.maxDailySimulatedLoss - todayLoss);

  // Quick favorite markets
  const favoriteSymbols = ['BTC/USDT', 'ETH/USDT', 'EUR/USD', 'XAU/USD', 'SPX'];

  return (
    <div className="flex flex-col gap-4 pb-20 pt-2 px-3 max-w-7xl mx-auto">
      {/* Portfolio Equity Hero Card */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#0f172a] via-[#111c38] to-[#0a1124] border border-[#1e293b] p-4 shadow-xl">
        <div className="flex items-center justify-between text-xs text-slate-400 font-mono mb-1">
          <span>PORTFOLIO EQUITY</span>
          <span className="flex items-center gap-1 text-blue-400">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
            VIRTUAL USD
          </span>
        </div>

        <div className="flex items-baseline gap-3 my-1">
          <span className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-mono-num">
            ${account.virtualEquity.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
          <span className={`flex items-center text-xs font-semibold px-2 py-0.5 rounded-full ${
            isProfit ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-red-500/20 text-red-400 border border-red-500/30'
          }`}>
            {isProfit ? <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" /> : <ArrowDownRight className="w-3.5 h-3.5 mr-0.5" />}
            {isProfit ? '+' : ''}${account.totalUnrealizedPnL.toFixed(2)}
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-[#1e293b]/80 text-xs font-mono">
          <div>
            <div className="text-slate-400 text-[10px]">BALANCE</div>
            <div className="text-slate-200 font-semibold font-mono-num">${account.virtualBalance.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}</div>
          </div>
          <div>
            <div className="text-slate-400 text-[10px]">FREE MARGIN</div>
            <div className="text-slate-200 font-semibold font-mono-num">${account.freeMargin.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}</div>
          </div>
          <div>
            <div className="text-slate-400 text-[10px]">MARGIN LEVEL</div>
            <div className={`font-semibold font-mono-num ${account.marginLevel < 150 ? 'text-amber-400' : 'text-emerald-400'}`}>
              {account.usedMargin > 0 ? `${account.marginLevel.toFixed(1)}%` : '999%'}
            </div>
          </div>
        </div>
      </div>

      {/* Market Watch Strip */}
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center justify-between text-xs text-slate-400 px-1 font-mono">
          <span>MARKET TICKERS</span>
          <span className="text-[10px] text-slate-500">Live Attributable Feeds</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {favoriteSymbols.map(sym => {
            const q = quotes[sym];
            const inst = INSTRUMENT_CATALOG[sym];
            const isUp = q ? q.changePercent24h >= 0 : true;

            return (
              <div
                key={sym}
                onClick={() => onNavigateToMarket(sym)}
                className="bg-[#0f172a] hover:bg-[#162038] border border-[#1e293b] hover:border-blue-500/40 rounded-xl p-2.5 flex flex-col justify-between transition-all cursor-pointer group shadow-sm"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-xs text-white group-hover:text-blue-400 transition-colors">{sym}</span>
                  <span className="text-[9px] uppercase px-1 py-0.2 rounded bg-slate-800 text-slate-400 font-mono">
                    {inst?.assetClass || 'asset'}
                  </span>
                </div>
                <div className="flex items-baseline justify-between mt-1">
                  <span className="font-mono-num text-xs font-semibold text-slate-200">
                    {q ? q.lastPrice.toFixed(inst?.pricePrecision || 2) : '---'}
                  </span>
                  <span className={`text-[10px] font-mono font-medium flex items-center ${isUp ? 'text-emerald-400' : 'text-red-400'}`}>
                    {isUp ? '+' : ''}{q ? q.changePercent24h.toFixed(2) : '0.00'}%
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Top Ranked AI Trading Ideas (Module 01) */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <h3 className="font-bold text-sm text-white tracking-wide">Top Qualified AI Setups</h3>
            <span className="text-[10px] font-mono bg-purple-500/20 text-purple-300 border border-purple-500/30 px-1.5 py-0.2 rounded">
              Module 01
            </span>
          </div>
          <button
            onClick={onNavigateToSignals}
            className="text-xs text-blue-400 hover:text-blue-300 font-mono flex items-center gap-0.5"
          >
            All Setups <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex flex-col gap-2.5">
          {tradeIdeas.slice(0, 2).map((idea) => {
            const isBull = idea.direction === 'BULLISH';
            const inst = INSTRUMENT_CATALOG[idea.symbol];

            return (
              <div
                key={idea.id}
                className="bg-[#0f172a] border border-[#1e293b] hover:border-purple-500/30 rounded-xl p-3 flex flex-col gap-2 transition-all shadow-md"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-white">{idea.symbol}</span>
                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                      isBull ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-red-500/20 text-red-400 border border-red-500/30'
                    }`}>
                      {idea.direction}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">{idea.timeframe}</span>
                  </div>
                  <div className="text-xs font-mono text-purple-400 font-semibold">
                    Score: {idea.rankScore}/100
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  {idea.explanation}
                </p>

                {/* Entry & Targets Grid */}
                <div className="grid grid-cols-4 gap-1.5 bg-[#090d16] p-2 rounded-lg text-[11px] font-mono border border-[#1e293b]">
                  <div>
                    <span className="text-slate-500 text-[9px] block">ENTRY</span>
                    <span className="text-slate-200 font-semibold">{idea.entryZone.min}</span>
                  </div>
                  <div>
                    <span className="text-red-400 text-[9px] block">STOP LOSS</span>
                    <span className="text-red-300 font-semibold">{idea.stopLoss}</span>
                  </div>
                  <div>
                    <span className="text-emerald-400 text-[9px] block">TARGET 1</span>
                    <span className="text-emerald-300 font-semibold">{idea.target1}</span>
                  </div>
                  <div>
                    <span className="text-blue-400 text-[9px] block">R:R RATIO</span>
                    <span className="text-blue-300 font-semibold">{idea.riskRewardRatio.toFixed(2)}:1</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 text-[11px]">
                  <span className="text-slate-400 text-[10px] flex items-center gap-1 font-mono">
                    <Clock className="w-3 h-3 text-slate-500" />
                    Invalidation: {idea.invalidationCondition}
                  </span>
                  <button
                    onClick={() => onNavigateToTrade(idea.symbol)}
                    className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded-md font-medium text-xs shadow-sm transition-colors"
                  >
                    Load in Trade
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Active Paper Positions (Module 12) */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-1.5">
            <Layers className="w-4 h-4 text-blue-400" />
            <h3 className="font-bold text-sm text-white tracking-wide">Active Positions</h3>
            <span className="text-xs font-mono text-slate-400">({openPositions.length})</span>
          </div>
          <button
            onClick={() => onNavigateToTrade()}
            className="text-xs text-blue-400 hover:text-blue-300 font-mono flex items-center gap-0.5"
          >
            Order Pad <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {openPositions.length === 0 ? (
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-6 text-center text-xs text-slate-400 flex flex-col items-center gap-2">
            <CheckCircle2 className="w-8 h-8 text-slate-600" />
            <span>No open positions currently active.</span>
            <button
              onClick={() => onNavigateToTrade('BTC/USDT')}
              className="mt-1 px-4 py-1.5 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-500 text-xs shadow"
            >
              Open New Paper Order
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {openPositions.map((pos) => {
              const isPosProfit = pos.unrealizedPnL >= 0;
              const inst = INSTRUMENT_CATALOG[pos.symbol];
              const pnlPercent = (pos.unrealizedPnL / pos.margin) * 100;

              return (
                <div
                  key={pos.id}
                  className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-3 flex flex-col gap-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-white">{pos.symbol}</span>
                      <span className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded ${
                        pos.side === 'BUY' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                      }`}>
                        {pos.side} {pos.quantity}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">{pos.leverage}x</span>
                    </div>

                    <div className="text-right">
                      <div className={`font-mono-num text-sm font-bold ${isPosProfit ? 'text-emerald-400' : 'text-red-400'}`}>
                        {isPosProfit ? '+' : ''}${pos.unrealizedPnL.toFixed(2)}
                      </div>
                      <div className={`text-[10px] font-mono ${isPosProfit ? 'text-emerald-500' : 'text-red-500'}`}>
                        ({pnlPercent >= 0 ? '+' : ''}{pnlPercent.toFixed(1)}%)
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-[11px] font-mono text-slate-400 bg-[#090d16] p-2 rounded-lg">
                    <div>
                      <span className="text-slate-500 text-[9px] block">ENTRY</span>
                      <span className="text-slate-200 font-semibold">{pos.entryPrice.toFixed(inst?.pricePrecision || 2)}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[9px] block">CURRENT</span>
                      <span className="text-slate-200 font-semibold">{pos.currentPrice.toFixed(inst?.pricePrecision || 2)}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[9px] block">MARGIN</span>
                      <span className="text-slate-200 font-semibold">${pos.margin.toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <div className="text-[10px] text-slate-500 font-mono">
                      SL: {pos.stopLoss ? pos.stopLoss : 'None'} | TP: {pos.takeProfit ? pos.takeProfit : 'None'}
                    </div>
                    <button
                      onClick={() => onClosePosition(pos.id)}
                      className="px-2.5 py-1 text-xs font-mono font-medium bg-red-600/20 text-red-400 border border-red-500/30 rounded hover:bg-red-600/30 transition-colors"
                    >
                      Close Position
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Daily Risk Management Summary (Requirement 8) */}
      <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-3.5 flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs text-white font-bold">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <span>Daily Risk & Execution Limits</span>
          </div>
          <button
            onClick={onNavigateToPortfolio}
            className="text-[11px] font-mono text-blue-400 hover:text-blue-300"
          >
            Adjust Limits
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-xs font-mono">
          <div className="bg-[#090d16] p-2 rounded-lg border border-[#1e293b]">
            <span className="text-slate-500 text-[10px] block">MAX RISK / TRADE</span>
            <span className="text-slate-200 font-bold">{safetySettings.maxRiskPerTradePercent}% Equity</span>
          </div>
          <div className="bg-[#090d16] p-2 rounded-lg border border-[#1e293b]">
            <span className="text-slate-500 text-[10px] block">DAILY LOSS REMAINING</span>
            <span className="text-emerald-400 font-bold">${lossAllowanceRemaining.toFixed(0)}</span>
          </div>
          <div className="bg-[#090d16] p-2 rounded-lg border border-[#1e293b]">
            <span className="text-slate-500 text-[10px] block">MAX OPEN POSITIONS</span>
            <span className="text-slate-200 font-bold">{openPositions.length} / {safetySettings.maxOpenPositions}</span>
          </div>
          <div className="bg-[#090d16] p-2 rounded-lg border border-[#1e293b]">
            <span className="text-slate-500 text-[10px] block">COOLDOWN ON LOSS</span>
            <span className="text-slate-200 font-bold">{safetySettings.cooldownMinutesAfterLoss} mins</span>
          </div>
        </div>
      </div>
    </div>
  );
};
