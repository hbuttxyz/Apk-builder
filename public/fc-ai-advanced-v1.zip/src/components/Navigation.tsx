/**
 * FC AI ADVANCED - TOP HEADER & MOBILE NAVIGATION
 */

import React from 'react';
import {
  Home,
  TrendingUp,
  Activity,
  ArrowLeftRight,
  PieChart,
  Menu,
  ShieldCheck,
  Zap,
  Download,
  FileCode,
} from 'lucide-react';

export type MainTab = 'home' | 'markets' | 'signals' | 'trade' | 'portfolio' | 'more';

interface NavigationProps {
  activeTab: MainTab;
  onTabChange: (tab: MainTab) => void;
  equity: number;
  openPositionsCount: number;
  isAiConnected: boolean;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onTabChange,
  equity,
  openPositionsCount,
  isAiConnected,
}) => {
  return (
    <>
      {/* Top Header Bar */}
      <header className="sticky top-0 z-40 bg-[#090d16]/95 backdrop-blur-md border-b border-[#1e293b] px-4 py-2.5 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Zap className="w-4 h-4 text-white fill-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-black text-sm tracking-tight text-white">FC AI ADVANCED</span>
              <span className="text-[10px] font-mono font-semibold px-1.5 py-0.2 bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded">
                V1.0
              </span>
            </div>
            <div className="text-[10px] text-slate-400 font-mono flex items-center gap-1.5">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Multi-Agent Trading Lab</span>
              {isAiConnected && (
                <span className="text-purple-400 font-semibold">• Gemini 3.8</span>
              )}
            </div>
          </div>
        </div>

        {/* Action pills: Zip download, standalone HTML & Equity */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Quick Package Downloads */}
          <div className="flex items-center gap-1">
            <a
              href="/api/download/zip"
              download="fc-ai-advanced-v1.zip"
              className="flex items-center gap-1 text-[11px] font-mono px-2 py-1 bg-[#0f172a] hover:bg-slate-800 border border-blue-500/40 hover:border-blue-400 text-blue-300 rounded-md transition-all shadow-sm"
              title="Download Complete Source Code in .ZIP"
            >
              <Download className="w-3.5 h-3.5 text-blue-400" />
              <span className="font-bold">ZIP</span>
            </a>
            <a
              href="/api/download/standalone-html"
              download="fc-ai-advanced-standalone.html"
              className="flex items-center gap-1 text-[11px] font-mono px-2 py-1 bg-[#0f172a] hover:bg-slate-800 border border-purple-500/40 hover:border-purple-400 text-purple-300 rounded-md transition-all shadow-sm"
              title="Download Complete Standalone Single-File HTML"
            >
              <FileCode className="w-3.5 h-3.5 text-purple-400" />
              <span className="font-bold">HTML</span>
            </a>
          </div>

          <div className="hidden md:flex flex-col items-end">
            <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider">Virtual Equity</span>
            <span className="text-sm font-bold text-white font-mono-num">${equity.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>

          <div className="flex items-center gap-1 text-[11px] font-mono px-2 py-1 bg-[#0f172a] border border-[#1e293b] rounded-md text-slate-300">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
            <span className="hidden sm:inline">Paper</span>
            <span className="font-semibold text-white">100k</span>
          </div>
        </div>
      </header>

      {/* Bottom Navigation for Mobile / Tablet */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#090d16]/95 backdrop-blur-md border-t border-[#1e293b] px-2 py-1.5 flex items-center justify-around max-w-7xl mx-auto">
        <button
          onClick={() => onTabChange('home')}
          className={`flex flex-col items-center py-1 px-2.5 rounded-lg transition-all ${
            activeTab === 'home' ? 'text-blue-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Home className="w-4 h-4 mb-0.5" />
          <span className="text-[10px] tracking-tight">Home</span>
        </button>

        <button
          onClick={() => onTabChange('markets')}
          className={`flex flex-col items-center py-1 px-2.5 rounded-lg transition-all ${
            activeTab === 'markets' ? 'text-blue-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <TrendingUp className="w-4 h-4 mb-0.5" />
          <span className="text-[10px] tracking-tight">Markets</span>
        </button>

        <button
          onClick={() => onTabChange('signals')}
          className={`flex flex-col items-center py-1 px-2.5 rounded-lg transition-all ${
            activeTab === 'signals' ? 'text-blue-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Activity className="w-4 h-4 mb-0.5" />
          <span className="text-[10px] tracking-tight">Signals</span>
        </button>

        <button
          onClick={() => onTabChange('trade')}
          className={`relative flex flex-col items-center py-1 px-2.5 rounded-lg transition-all ${
            activeTab === 'trade' ? 'text-blue-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <ArrowLeftRight className="w-4 h-4 mb-0.5" />
          <span className="text-[10px] tracking-tight">Trade</span>
          {openPositionsCount > 0 && (
            <span className="absolute top-0 right-1.5 w-4 h-4 rounded-full bg-blue-600 text-[9px] font-bold text-white flex items-center justify-center">
              {openPositionsCount}
            </span>
          )}
        </button>

        <button
          onClick={() => onTabChange('portfolio')}
          className={`flex flex-col items-center py-1 px-2.5 rounded-lg transition-all ${
            activeTab === 'portfolio' ? 'text-blue-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <PieChart className="w-4 h-4 mb-0.5" />
          <span className="text-[10px] tracking-tight">Portfolio</span>
        </button>

        <button
          onClick={() => onTabChange('more')}
          className={`flex flex-col items-center py-1 px-2.5 rounded-lg transition-all ${
            activeTab === 'more' ? 'text-blue-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Menu className="w-4 h-4 mb-0.5" />
          <span className="text-[10px] tracking-tight">More</span>
        </button>
      </nav>
    </>
  );
};
