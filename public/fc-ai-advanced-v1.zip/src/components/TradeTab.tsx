/**
 * FC AI ADVANCED - REAL-PRICE PAPER TRADING ENGINE (MODULE 12)
 * Institutional Order Execution, Live Margin & Risk Calculator, Open Positions,
 * Pending Orders, and Auditable Trade History.
 */

import React, { useState, useEffect } from 'react';
import {
  PaperAccount,
  PaperPosition,
  PaperOrder,
  MarketQuote,
  SafetySettings,
  OrderSide,
  OrderType,
} from '../types/market';
import { INSTRUMENT_CATALOG } from '../lib/instruments';
import {
  ArrowUpRight,
  ArrowDownRight,
  AlertTriangle,
  CheckCircle2,
  Layers,
  History,
  ShieldAlert,
  Sliders,
  DollarSign,
  Percent,
  BookOpen,
} from 'lucide-react';

interface TradeTabProps {
  account: PaperAccount;
  positions: PaperPosition[];
  orders: PaperOrder[];
  quotes: Record<string, MarketQuote>;
  safetySettings: SafetySettings;
  selectedSymbol: string;
  onSelectSymbol: (symbol: string) => void;
  onExecuteOrder: (params: {
    symbol: string;
    side: OrderSide;
    quantity: number;
    leverage: number;
    stopLoss?: number;
    takeProfit?: number;
  }) => { success: boolean; error?: string; auditMessage?: string };
  onClosePosition: (positionId: string) => void;
  onAddJournalEntry: (pos: PaperPosition) => void;
  prefillParams?: {
    symbol?: string;
    direction?: 'BUY' | 'SELL';
    entry?: number;
    sl?: number;
    tp?: number;
  };
}

export const TradeTab: React.FC<TradeTabProps> = ({
  account,
  positions,
  orders,
  quotes,
  safetySettings,
  selectedSymbol,
  onSelectSymbol,
  onExecuteOrder,
  onClosePosition,
  onAddJournalEntry,
  prefillParams,
}) => {
  const [side, setSide] = useState<OrderSide>('BUY');
  const [orderType, setOrderType] = useState<OrderType>('MARKET');
  const [quantity, setQuantity] = useState<number>(0.1);
  const [leverage, setLeverage] = useState<number>(10);
  const [stopLoss, setStopLoss] = useState<string>('');
  const [takeProfit, setTakeProfit] = useState<string>('');
  const [activeSubView, setActiveSubView] = useState<'NEW_ORDER' | 'OPEN_POSITIONS' | 'HISTORY'>('NEW_ORDER');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const currentInstrument = INSTRUMENT_CATALOG[selectedSymbol] || INSTRUMENT_CATALOG['BTC/USDT'];
  const currentQuote = quotes[selectedSymbol];

  // Sync prefill params if passed
  useEffect(() => {
    if (prefillParams?.symbol && prefillParams.symbol !== selectedSymbol) {
      onSelectSymbol(prefillParams.symbol);
    }
    if (prefillParams?.direction) {
      setSide(prefillParams.direction);
    }
    if (prefillParams?.sl) {
      setStopLoss(prefillParams.sl.toString());
    }
    if (prefillParams?.tp) {
      setTakeProfit(prefillParams.tp.toString());
    }
  }, [prefillParams]);

  // Adjust default quantity when instrument changes
  useEffect(() => {
    if (currentInstrument.assetClass === 'crypto') {
      setQuantity(currentInstrument.symbol.includes('BTC') ? 0.05 : 0.5);
      setLeverage(10);
    } else if (currentInstrument.assetClass === 'forex') {
      setQuantity(0.1); // 0.1 mini lot
      setLeverage(50);
    } else if (currentInstrument.assetClass === 'metals') {
      setQuantity(currentInstrument.symbol.includes('XAU') ? 1.0 : 10.0);
      setLeverage(20);
    } else {
      setQuantity(5);
      setLeverage(5);
    }
  }, [selectedSymbol]);

  // Pricing
  const execPrice = side === 'BUY'
    ? (currentQuote?.ask || currentQuote?.lastPrice || 0)
    : (currentQuote?.bid || currentQuote?.lastPrice || 0);

  const notionalValue = quantity * execPrice;
  const requiredMargin = notionalValue / leverage;
  const estFee = notionalValue * currentInstrument.takerFeeRate;

  // Stop loss & R:R calculations
  const parsedSL = parseFloat(stopLoss) || undefined;
  const parsedTP = parseFloat(takeProfit) || undefined;

  let dollarRiskAtSL = 0;
  let riskPercentOfEquity = 0;
  let dollarProfitAtTP = 0;
  let calculatedRR = 0;

  if (parsedSL && execPrice > 0) {
    const slDist = Math.abs(execPrice - parsedSL);
    dollarRiskAtSL = slDist * quantity;
    riskPercentOfEquity = account.virtualEquity > 0 ? (dollarRiskAtSL / account.virtualEquity) * 100 : 0;

    if (parsedTP) {
      const tpDist = Math.abs(parsedTP - execPrice);
      dollarProfitAtTP = tpDist * quantity;
      calculatedRR = slDist > 0 ? dollarProfitAtTP / slDist : 0;
    }
  }

  const handleOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    const res = onExecuteOrder({
      symbol: selectedSymbol,
      side,
      quantity,
      leverage,
      stopLoss: parsedSL,
      takeProfit: parsedTP,
    });

    if (res.success) {
      setFeedback({ type: 'success', message: res.auditMessage || 'Order executed successfully!' });
      // Switch to open positions
      setTimeout(() => setActiveSubView('OPEN_POSITIONS'), 800);
    } else {
      setFeedback({ type: 'error', message: res.error || 'Execution blocked by safety controls.' });
    }
  };

  const openPositions = positions.filter(p => p.status === 'OPEN');
  const closedPositions = positions.filter(p => p.status === 'CLOSED');

  return (
    <div className="flex flex-col gap-4 pb-20 pt-2 px-3 max-w-7xl mx-auto">
      {/* Sub Tabs */}
      <div className="flex items-center gap-1 bg-[#0f172a] p-1 rounded-xl border border-[#1e293b] text-xs font-mono">
        <button
          onClick={() => setActiveSubView('NEW_ORDER')}
          className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1 transition-all ${
            activeSubView === 'NEW_ORDER' ? 'bg-blue-600 text-white font-semibold shadow' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Order Pad</span>
        </button>
        <button
          onClick={() => setActiveSubView('OPEN_POSITIONS')}
          className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
            activeSubView === 'OPEN_POSITIONS' ? 'bg-blue-600 text-white font-semibold shadow' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Open ({openPositions.length})</span>
        </button>
        <button
          onClick={() => setActiveSubView('HISTORY')}
          className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1 transition-all ${
            activeSubView === 'HISTORY' ? 'bg-blue-600 text-white font-semibold shadow' : 'text-slate-400 hover:text-white'
          }`}
        >
          <History className="w-3.5 h-3.5" />
          <span>History ({closedPositions.length})</span>
        </button>
      </div>

      {/* FEEDBACK BANNER */}
      {feedback && (
        <div className={`p-3 rounded-xl border text-xs font-mono flex items-start gap-2 ${
          feedback.type === 'success'
            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
            : 'bg-red-500/10 border-red-500/30 text-red-300'
        }`}>
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
          )}
          <div className="flex-1 font-sans leading-relaxed">{feedback.message}</div>
        </div>
      )}

      {/* VIEW 1: ORDER ENTRY PAD */}
      {activeSubView === 'NEW_ORDER' && (
        <form onSubmit={handleOrderSubmit} className="flex flex-col gap-3">
          {/* Instrument & Pricing Card */}
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-3 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <select
                  value={selectedSymbol}
                  onChange={(e) => onSelectSymbol(e.target.value)}
                  className="bg-[#090d16] border border-[#1e293b] rounded-lg px-2.5 py-1 text-sm font-bold text-white font-mono focus:outline-none focus:border-blue-500"
                >
                  {Object.keys(INSTRUMENT_CATALOG).map(sym => (
                    <option key={sym} value={sym}>{sym}</option>
                  ))}
                </select>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                  {currentInstrument.assetClass.toUpperCase()}
                </span>
              </div>

              <div className="text-right">
                <span className="text-[10px] text-slate-500 font-mono block">Attributable Rate</span>
                <span className="text-sm font-extrabold text-white font-mono-num">
                  {execPrice > 0 ? execPrice.toFixed(currentInstrument.pricePrecision) : '---'}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-1 border-t border-[#1e293b]">
              <span>Bid: <strong className="text-slate-200">{currentQuote?.bid ?? '---'}</strong></span>
              <span>Ask: <strong className="text-slate-200">{currentQuote?.ask ?? '---'}</strong></span>
              <span>Provider: <strong className="text-blue-400">{currentQuote?.provider || 'Live'}</strong></span>
            </div>
          </div>

          {/* BUY / SELL Direction Buttons */}
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setSide('BUY')}
              className={`py-3 rounded-xl font-bold font-mono text-sm transition-all flex flex-col items-center justify-center gap-0.5 ${
                side === 'BUY'
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30 ring-2 ring-emerald-400'
                  : 'bg-[#0f172a] text-slate-400 border border-[#1e293b] hover:text-white'
              }`}
            >
              <div className="flex items-center gap-1">
                <ArrowUpRight className="w-4 h-4" />
                <span>BUY / LONG</span>
              </div>
              <span className="text-[10px] font-mono opacity-80">
                Ask: {currentQuote ? currentQuote.ask.toFixed(currentInstrument.pricePrecision) : '---'}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setSide('SELL')}
              className={`py-3 rounded-xl font-bold font-mono text-sm transition-all flex flex-col items-center justify-center gap-0.5 ${
                side === 'SELL'
                  ? 'bg-red-600 text-white shadow-lg shadow-red-600/30 ring-2 ring-red-400'
                  : 'bg-[#0f172a] text-slate-400 border border-[#1e293b] hover:text-white'
              }`}
            >
              <div className="flex items-center gap-1">
                <ArrowDownRight className="w-4 h-4" />
                <span>SELL / SHORT</span>
              </div>
              <span className="text-[10px] font-mono opacity-80">
                Bid: {currentQuote ? currentQuote.bid.toFixed(currentInstrument.pricePrecision) : '---'}
              </span>
            </button>
          </div>

          {/* Quantity & Leverage Controls */}
          <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-3.5 flex flex-col gap-3">
            {/* Quantity */}
            <div className="flex flex-col gap-1">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">Order Quantity ({currentInstrument.baseSymbol})</span>
                <span className="text-slate-500 text-[10px]">Min: {currentInstrument.minQuantity}</span>
              </div>
              <div className="relative">
                <input
                  type="number"
                  step={Math.pow(10, -currentInstrument.quantityPrecision)}
                  min={currentInstrument.minQuantity}
                  value={quantity}
                  onChange={(e) => setQuantity(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#090d16] border border-[#1e293b] rounded-lg px-3 py-2 text-white font-mono font-bold text-sm focus:outline-none focus:border-blue-500"
                  required
                />
              </div>
            </div>

            {/* Leverage Slider */}
            <div className="flex flex-col gap-1">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">Leverage Multiplier</span>
                <span className="text-blue-400 font-bold">{leverage}x (Max {currentInstrument.maxLeverage}x)</span>
              </div>
              <input
                type="range"
                min={1}
                max={currentInstrument.maxLeverage}
                value={leverage}
                onChange={(e) => setLeverage(parseInt(e.target.value, 10))}
                className="w-full accent-blue-500 cursor-pointer"
              />
            </div>

            {/* Stop Loss & Take Profit Inputs */}
            <div className="grid grid-cols-2 gap-2 pt-1 border-t border-[#1e293b]">
              <div className="flex flex-col gap-1">
                <span className="text-[11px] text-red-400 font-mono font-medium">STOP LOSS (Optional)</span>
                <input
                  type="number"
                  step="any"
                  placeholder="Price"
                  value={stopLoss}
                  onChange={(e) => setStopLoss(e.target.value)}
                  className="bg-[#090d16] border border-[#1e293b] rounded-lg px-2.5 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-red-500"
                />
              </div>

              <div className="flex flex-col gap-1">
                <span className="text-[11px] text-emerald-400 font-mono font-medium">TAKE PROFIT (Optional)</span>
                <input
                  type="number"
                  step="any"
                  placeholder="Price"
                  value={takeProfit}
                  onChange={(e) => setTakeProfit(e.target.value)}
                  className="bg-[#090d16] border border-[#1e293b] rounded-lg px-2.5 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Dynamic Margin & Risk Accounting Calculator */}
          <div className="bg-[#090d16] border border-[#1e293b] rounded-xl p-3 flex flex-col gap-1.5 text-xs font-mono">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Pre-Trade Risk & Margin Audit</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
              <div>
                <span className="text-slate-500 text-[10px] block">NOTIONAL VALUE</span>
                <span className="text-white font-semibold font-mono-num">${notionalValue.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">REQUIRED MARGIN</span>
                <span className="text-blue-400 font-bold font-mono-num">${requiredMargin.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">ESTIMATED FEE</span>
                <span className="text-slate-300 font-mono-num">${estFee.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">DOLLAR RISK (SL)</span>
                <span className={riskPercentOfEquity > safetySettings.maxRiskPerTradePercent ? 'text-red-400 font-bold' : 'text-slate-300'}>
                  {parsedSL ? `$${dollarRiskAtSL.toFixed(2)} (${riskPercentOfEquity.toFixed(1)}%)` : 'Unbounded'}
                </span>
              </div>
            </div>

            {parsedSL && parsedTP && (
              <div className="mt-1 pt-1 border-t border-[#1e293b] flex items-center justify-between text-[11px]">
                <span className="text-slate-400">Calculated Risk/Reward:</span>
                <span className={`font-bold ${calculatedRR >= safetySettings.minRiskRewardRatio ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {calculatedRR.toFixed(2)}:1 {calculatedRR < safetySettings.minRiskRewardRatio ? '(Below min target)' : '✓'}
                </span>
              </div>
            )}
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className={`w-full py-3.5 rounded-xl font-bold font-mono text-sm text-white shadow-xl transition-all ${
              side === 'BUY'
                ? 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/25'
                : 'bg-red-600 hover:bg-red-500 shadow-red-600/25'
            }`}
          >
            Submit Virtual {side} Order ({quantity} {selectedSymbol})
          </button>
        </form>
      )}

      {/* VIEW 2: OPEN POSITIONS */}
      {activeSubView === 'OPEN_POSITIONS' && (
        <div className="flex flex-col gap-2.5">
          {openPositions.length === 0 ? (
            <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-8 text-center text-xs text-slate-400 flex flex-col items-center gap-2">
              <Layers className="w-8 h-8 text-slate-600" />
              <span>No open positions in your virtual portfolio.</span>
              <button
                onClick={() => setActiveSubView('NEW_ORDER')}
                className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-bold"
              >
                Open Order Pad
              </button>
            </div>
          ) : (
            openPositions.map((pos) => {
              const isProfit = pos.unrealizedPnL >= 0;
              const inst = INSTRUMENT_CATALOG[pos.symbol];
              const pnlPct = pos.margin > 0 ? (pos.unrealizedPnL / pos.margin) * 100 : 0;

              return (
                <div
                  key={pos.id}
                  className="bg-[#0f172a] border border-[#1e293b] rounded-xl p-3.5 flex flex-col gap-2.5 shadow-md"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-base text-white">{pos.symbol}</span>
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                        pos.side === 'BUY' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                      }`}>
                        {pos.side} {pos.quantity}
                      </span>
                      <span className="text-xs font-mono text-slate-400">{pos.leverage}x</span>
                    </div>

                    <div className="text-right">
                      <div className={`text-base font-extrabold font-mono-num ${isProfit ? 'text-emerald-400' : 'text-red-400'}`}>
                        {isProfit ? '+' : ''}${pos.unrealizedPnL.toFixed(2)}
                      </div>
                      <div className={`text-[11px] font-mono ${isProfit ? 'text-emerald-500' : 'text-red-500'}`}>
                        ({pnlPct >= 0 ? '+' : ''}{pnlPct.toFixed(1)}%)
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs font-mono bg-[#090d16] p-2 rounded-lg">
                    <div>
                      <span className="text-slate-500 text-[10px] block">ENTRY PRICE</span>
                      <span className="text-slate-200 font-bold">{pos.entryPrice.toFixed(inst?.pricePrecision || 2)}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[10px] block">CURRENT PRICE</span>
                      <span className="text-slate-200 font-bold">{pos.currentPrice.toFixed(inst?.pricePrecision || 2)}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[10px] block">MARGIN ALLOCATED</span>
                      <span className="text-blue-400 font-bold">${pos.margin.toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <div className="text-[10px] text-slate-500 font-mono">
                      SL: {pos.stopLoss ?? 'None'} | TP: {pos.takeProfit ?? 'None'}
                    </div>

                    <button
                      onClick={() => onClosePosition(pos.id)}
                      className="px-3 py-1.5 bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/30 rounded-lg text-xs font-bold font-mono transition-colors"
                    >
                      Close Position
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* VIEW 3: TRADE AUDIT HISTORY */}
      {activeSubView === 'HISTORY' && (
        <div className="bg-[#0f172a] border border-[#1e293b] rounded-xl overflow-hidden shadow-md">
          <div className="p-3 border-b border-[#1e293b] flex items-center justify-between">
            <span className="font-bold text-xs text-white font-mono">REALIZED TRANSACTIONS LEDGER</span>
            <span className="text-[10px] text-slate-500 font-mono">Audited Virtual Ledger</span>
          </div>

          {closedPositions.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500 font-mono">
              No closed trades recorded yet.
            </div>
          ) : (
            <div className="divide-y divide-[#1e293b] max-h-[500px] overflow-y-auto">
              {closedPositions.map((pos) => {
                const isWon = pos.realizedPnL >= 0;
                return (
                  <div key={pos.id} className="p-3 flex flex-col gap-1.5 hover:bg-[#162038]/50 text-xs font-mono">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white">{pos.symbol}</span>
                        <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                          pos.side === 'BUY' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                        }`}>
                          {pos.side} {pos.quantity}
                        </span>
                        <span className="text-[10px] text-slate-400">{pos.closeReason}</span>
                      </div>

                      <span className={`font-mono-num font-bold ${isWon ? 'text-emerald-400' : 'text-red-400'}`}>
                        {isWon ? '+' : ''}${pos.realizedPnL.toFixed(2)}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>In: ${pos.entryPrice} → Out: ${pos.closePrice}</span>
                      <span>Fees: ${pos.fees.toFixed(2)}</span>
                    </div>

                    <div className="flex items-center justify-between pt-1 border-t border-[#1e293b]/60">
                      <span className="text-[10px] text-slate-500">
                        {pos.closedAt ? new Date(pos.closedAt).toLocaleTimeString() : ''}
                      </span>
                      <button
                        onClick={() => onAddJournalEntry(pos)}
                        className="flex items-center gap-1 text-[10px] text-blue-400 hover:text-blue-300 font-semibold"
                      >
                        <BookOpen className="w-3 h-3" />
                        <span>Log in Journal (Mod 06)</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
