/**
 * FC AI ADVANCED - CANONICAL DOMAIN TYPES
 * Version: 1.0.0
 * Standard: Institutional Quantitative & Multi-Agent Architecture
 */

export type AssetClass = 'crypto' | 'forex' | 'metals' | 'indices' | 'stocks';

export type Timeframe = '1m' | '5m' | '15m' | '30m' | '1H' | '4H' | '1D' | '1W';

export interface Instrument {
  symbol: string;               // e.g. "BTC/USDT", "EUR/USD", "XAU/USD", "SPX", "AAPL"
  baseSymbol: string;           // "BTC"
  quoteCurrency: string;        // "USDT", "USD"
  name: string;                 // "Bitcoin / Tether"
  assetClass: AssetClass;
  pricePrecision: number;       // decimals e.g. 2 for BTC, 5 for EUR/USD
  quantityPrecision: number;    // e.g. 4 for crypto, 2 for forex
  tickSize: number;             // e.g. 0.01, 0.00001
  contractSize: number;         // e.g. 1 for crypto, 100,000 for standard forex lot
  minQuantity: number;          // e.g. 0.001
  maxLeverage: number;          // e.g. 20 for crypto, 100 for forex
  marginRequirement: number;    // margin fraction e.g. 0.05 for 20x
  takerFeeRate: number;         // e.g. 0.0006 (0.06%)
  makerFeeRate: number;         // e.g. 0.0002 (0.02%)
  slippageBps: number;          // expected slippage in basis points e.g. 3 (0.03%)
  exchangeOrProvider: string;   // e.g. "Binance / Global Crypto", "ECB / Interbank FX"
  tradingHours: string;         // e.g. "24/7", "24/5 (Sun 17:00 - Fri 17:00 EST)", "09:30-16:00 EST"
  isLiveSupported: boolean;     // whether live feed is active
}

export interface OHLCVCandle {
  timestamp: number; // Unix timestamp in ms
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  isConfirmed?: boolean; // closed candle vs forming candle
}

export interface MarketQuote {
  symbol: string;
  bid: number;
  ask: number;
  lastPrice: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  change24h: number;
  changePercent24h: number;
  timestamp: number; // Unix ms
  provider: string;
  isStale: boolean;
  status: 'LIVE' | 'DELAYED' | 'OFFLINE' | 'CLOSED';
}

export type OrderSide = 'BUY' | 'SELL';
export type OrderType = 'MARKET' | 'LIMIT' | 'STOP';
export type OrderStatus = 'PENDING' | 'FILLED' | 'CANCELLED' | 'REJECTED';
export type PositionStatus = 'OPEN' | 'CLOSED';

export interface PaperOrder {
  id: string;
  symbol: string;
  side: OrderSide;
  type: OrderType;
  quantity: number;
  price: number;              // Target price for limit/stop, execution price for market
  stopLoss?: number;
  takeProfit?: number;
  leverage: number;
  status: OrderStatus;
  createdAt: number;
  filledAt?: number;
  reason?: string;
}

export interface PaperPosition {
  id: string;
  symbol: string;
  side: OrderSide;
  quantity: number;
  entryPrice: number;
  currentPrice: number;
  stopLoss?: number;
  takeProfit?: number;
  leverage: number;
  margin: number;
  unrealizedPnL: number;
  realizedPnL: number;
  fees: number;
  status: PositionStatus;
  openedAt: number;
  closedAt?: number;
  closePrice?: number;
  closeReason?: 'MANUAL' | 'STOP_LOSS' | 'TAKE_PROFIT' | 'LIQUIDATION' | 'RISK_LIMIT';
}

export interface PaperAccount {
  accountNumber: string;
  currency: string;
  initialBalance: number;
  virtualBalance: number;
  virtualEquity: number;
  freeMargin: number;
  usedMargin: number;
  marginLevel: number;        // Equity / Used Margin * 100%
  totalRealizedPnL: number;
  totalUnrealizedPnL: number;
  totalFeesPaid: number;
  winCount: number;
  lossCount: number;
  updatedAt: number;
}

export interface SafetySettings {
  maxRiskPerTradePercent: number;    // default 2.0%
  maxDailySimulatedLoss: number;     // default $2,500
  maxOpenPositions: number;          // default 5
  maxExposurePerInstrumentPercent: number; // default 25%
  maxPortfolioLeverage: number;      // default 10x
  minRequiredDataQualityScore: number; // 0-100, default 80
  minRiskRewardRatio: number;        // default 1.5
  cooldownMinutesAfterLoss: number;  // default 5 mins
  lastLossTimestamp?: number;
}

export interface TechnicalSummary {
  rsi: number;
  rsiState: 'OVERSOLD' | 'NEUTRAL' | 'OVERBOUGHT';
  macd: { macd: number; signal: number; histogram: number; trend: 'BULLISH' | 'BEARISH' | 'CROSSOVER_BULL' | 'CROSSOVER_BEAR' };
  sma20: number;
  sma50: number;
  sma200: number;
  ema9: number;
  ema21: number;
  maAlignment: 'STRONG_BULL' | 'MILD_BULL' | 'MILD_BEAR' | 'STRONG_BEAR' | 'MIXED';
  bollingerBands: { upper: number; middle: number; lower: number; bandwidth: number; percentB: number };
  atr: number;
  adx: { adx: number; plusDI: number; minusDI: number; strength: 'TRENDING' | 'STRONG_TREND' | 'WEAK_CHOPPY' };
  stochastic: { k: number; d: number };
  supportLevels: number[];
  resistanceLevels: number[];
  swingHigh?: number;
  swingLow?: number;
  priceActionPattern?: string;
}

export type SignalAction = 'BUY' | 'SELL' | 'HOLD' | 'NO_TRADE';

export interface MultiTimeframeRow {
  timeframe: Timeframe;
  direction: SignalAction;
  trend: 'UPTREND' | 'DOWNTREND' | 'SIDEWAYS';
  momentum: 'STRONG_BULLISH' | 'MODERATE_BULLISH' | 'NEUTRAL' | 'MODERATE_BEARISH' | 'STRONG_BEARISH';
  signalState: 'CONFIRMED' | 'FORMING' | 'IN_VALID' | 'EXHAUSTED';
  rsi: number;
  macdCross: boolean;
  explanation: string;
}

export type MarketRegimeType =
  | 'STRONG_UPTREND'
  | 'STRONG_DOWNTREND'
  | 'RANGE_BOUND'
  | 'HIGH_VOLATILITY'
  | 'LOW_VOLATILITY'
  | 'TRANSITIONAL';

export interface MarketRegimeAnalysis {
  symbol: string;
  timeframe: Timeframe;
  regime: MarketRegimeType;
  confidenceScore: number; // 0 to 100
  adxValue: number;
  atrPercent: number;
  trendSlope: number;
  realizedVolatility: number;
  evidence: string[];
  recommendedStrategy: string;
  unfavorableStrategy: string;
  timestamp: number;
}

export interface TradeIdea {
  id: string;
  symbol: string;
  timeframe: Timeframe;
  direction: 'BULLISH' | 'BEARISH';
  currentPrice: number;
  entryZone: { min: number; max: number };
  stopLoss: number;
  target1: number;
  target2: number;
  target3: number;
  riskRewardRatio: number;
  trendCondition: string;
  momentumCondition: string;
  fundamentalDrivers: string[];
  invalidationCondition: string;
  freshnessTimestamp: number;
  explanation: string;
  rankScore: number;
}

export interface NewsItem {
  id: string;
  title: string;
  summary: string;
  source: string;
  url: string;
  publishedAt: string;
  timestampMs: number;
  categories: string[];
  macroImpact: 'HIGH_VOLATILITY' | 'NEUTRAL' | 'DOVISH' | 'HAWKISH' | 'SECTOR_SPECIFIC';
  sentiment: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  bullishScenario: string;
  bearishScenario: string;
  timelineNote: string;
}

export interface BacktestParameters {
  strategyName: 'SMA_CROSSOVER' | 'EMA_CROSSOVER' | 'RSI_MEAN_REVERSION' | 'MACD_CROSSOVER' | 'BOLLINGER_REVERSION' | 'DONCHIAN_BREAKOUT' | 'TREND_FOLLOWING';
  symbol: string;
  timeframe: Timeframe;
  initialCapital: number;
  fastPeriod: number;
  slowPeriod: number;
  signalPeriod?: number;
  rsiPeriod?: number;
  rsiOversold?: number;
  rsiOverbought?: number;
  stopLossPercent: number;
  takeProfitPercent: number;
  slippageBps: number;
  feeBps: number;
  inSampleRatio: number; // e.g. 0.70 (70% in-sample, 30% out-of-sample)
}

export interface BacktestTrade {
  tradeNumber: number;
  entryTimestamp: number;
  exitTimestamp: number;
  side: OrderSide;
  entryPrice: number;
  exitPrice: number;
  quantity: number;
  grossPnL: number;
  fees: number;
  slippage: number;
  netPnL: number;
  returnPercent: number;
  holdingCandles: number;
  exitReason: 'STOP_LOSS' | 'TAKE_PROFIT' | 'SIGNAL_REVERSAL' | 'END_OF_DATA';
  drawdownDuringTradePercent: number;
  isOutOfSample: boolean;
}

export interface BacktestResult {
  strategyName: string;
  symbol: string;
  timeframe: Timeframe;
  candleCount: number;
  startDate: string;
  endDate: string;
  initialCapital: number;
  endingCapital: number;
  totalNetPnL: number;
  totalReturnPercent: number;
  annualizedReturnPercent: number;
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRate: number;
  profitFactor: number;
  averageWin: number;
  averageLoss: number;
  maxDrawdownPercent: number;
  maxDrawdownAmount: number;
  sharpeRatio: number;
  expectancy: number;
  marketExposurePercent: number;
  inSampleTrades: number;
  outOfSampleTrades: number;
  outOfSampleWinRate: number;
  outOfSampleReturnPercent: number;
  equityCurve: { timestamp: number; equity: number; drawdownPercent: number }[];
  trades: BacktestTrade[];
}

export interface PortfolioStressScenario {
  name: string;
  description: string;
  cryptoShock: number;   // e.g. -0.35 (-35%)
  equitiesShock: number; // e.g. -0.20 (-20%)
  metalsShock: number;   // e.g. +0.08 (+8% gold hedge)
  forexShock: number;    // e.g. -0.04 (-4% EUR drop vs USD)
}

export interface AgentDebatePerspective {
  agentRole: 'AGENT_A_TECHNICAL' | 'AGENT_B_FUNDAMENTAL' | 'AGENT_C_RISK' | 'AGENT_D_COUNTERARGUMENT' | 'AGENT_E_COORDINATOR';
  agentName: string;
  headline: string;
  bias: 'BULLISH' | 'BEARISH' | 'NEUTRAL' | 'ABSTAIN';
  confidenceScore: number; // 0-100
  evidence: string[];
  disagreementsOrCaveats: string[];
  sourceModel: string; // e.g. "gemini-3.8-flash" or "Canonical Quantitative Engine"
  isLLMGenerated: boolean;
}

export interface MultiAgentDebateOutcome {
  symbol: string;
  currentPrice: number;
  timestamp: number;
  agents: AgentDebatePerspective[];
  consensusDecision: SignalAction;
  consensusScore: number; // 0-100
  overallRiskLevel: 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
  suggestedAction: string;
  abstainReasons: string[];
  traceId: string;
}

export interface SignalOutcomeRecord {
  id: string;
  symbol: string;
  timeframe: Timeframe;
  createdAt: number;
  currentPriceAtSignal: number;
  direction: 'BUY' | 'SELL';
  proposedEntry: number;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number;
  strategyVersion: string;
  regime: MarketRegimeType;
  scoreBand: 'A (85-100)' | 'B (70-84)' | 'C (50-69)' | 'D (<50)';
  status: 'PENDING_ENTRY' | 'ACTIVE' | 'HIT_TP1' | 'HIT_TP2' | 'HIT_SL' | 'EXPIRED';
  maxFavorableExcursionPercent: number; // MFE
  maxAdverseExcursionPercent: number;   // MAE
  netTheoreticalReturnPercent: number;
  resolvedAt?: number;
  timeToOutcomeHours?: number;
  dataProvenance: string;
}

export interface JournalRecord {
  id: string;
  positionId?: string;
  symbol: string;
  direction: OrderSide;
  strategy: string;
  openedAt: number;
  closedAt: number;
  entryPrice: number;
  exitPrice: number;
  positionSize: number;
  stopLoss: number;
  netPnL: number;
  riskRewardRatioAchieved: number;
  entryRationale: string;
  exitRationale: string;
  disciplineRating: number; // 1 to 5
  tags: string[]; // e.g. "Followed Rules", "Revenge Trade", "Early Exit", "FOMO"
  notes: string;
}

export interface DailyPlannerTaskItem {
  id: string;
  session: 'PRE_MARKET' | 'OPENING_BELL' | 'MID_SESSION' | 'CLOSING_SESSION' | 'POST_MARKET_EOD';
  title: string;
  description: string;
  timeCategory: string;
  isCompleted: boolean;
  linkedSymbol?: string;
  warningNotice?: string;
}

export interface PriceAlert {
  id: string;
  symbol: string;
  targetPrice: number;
  condition: 'ABOVE' | 'BELOW';
  note?: string;
  createdAt: number;
  isActive: boolean;
  isTriggered: boolean;
  triggeredAt?: number;
  triggeredPrice?: number;
}
